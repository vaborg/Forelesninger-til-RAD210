/* Sekvens II — del II: interaktive visualiseringer (Quarto reveal.js, iframe).
   Én modul per side via runViz(navn). Fysikk verifisert numerisk før innbygging. */
(function(){
  "use strict";
  const F="'DejaVu Sans', Verdana, sans-serif";
  const C={blue:'#2F5FA8',red:'#C0392B',purple:'#5d3a8e',orange:'#b54a16',green:'#10b981',
           amber:'#d99a10',gray:'#6b7280',ink:'#1f2430',mut:'#9aa2ad',line:'#e3e6ea',grid:'#eef1f4'};
  const clamp=(v,a,b)=>v<a?a:(v>b?b:v), TAU=Math.PI*2;
  function fit(cv,w,h){ const dpr=Math.max(1,Math.min(2.5,window.devicePixelRatio||1));
    cv.width=w*dpr; cv.height=h*dpr; cv.style.aspectRatio=w+'/'+h;
    const x=cv.getContext('2d'); x.setTransform(dpr,0,0,dpr,0,0); return x; }
  function T(x,s,px,py,o){ o=o||{}; x.globalAlpha=o.alpha==null?1:o.alpha; x.fillStyle=o.col||C.ink;
    x.font=(o.weight||'normal')+' '+(o.size||14)+'px '+F; x.textAlign=o.align||'left';
    x.textBaseline=o.base||'alphabetic'; x.fillText(s,px,py); x.globalAlpha=1; }
  function L(x,a,b,c,d,col,w,dash){ x.strokeStyle=col; x.lineWidth=w||1; x.setLineDash(dash||[]);
    x.beginPath(); x.moveTo(a,b); x.lineTo(c,d); x.stroke(); x.setLineDash([]); }
  function rr(x,px,py,w,h,r){ x.beginPath(); x.moveTo(px+r,py); x.arcTo(px+w,py,px+w,py+h,r);
    x.arcTo(px+w,py+h,px,py+h,r); x.arcTo(px,py+h,px,py,r); x.arcTo(px,py,px+w,py,r); x.closePath(); }
  const M={};

  // ============================================================
  // 1. EKKO-TOG:  SE / TSE(FSE) / GRASE  (animated)
  // ============================================================
  M.echotrain={ready:false,animated:true,cv:null,x:null,W:960,H:470,mode:'tse',ETL:8,Ny:32,
    esp:1.0,pt:0,block:0,counted:0,filled:0,speed:1,last:null,
    init(root){ this.cv=root.querySelector('#cv-et'); this.x=fit(this.cv,this.W,this.H);
      root.querySelectorAll('[data-etmode]').forEach(b=>b.onclick=()=>{ this.mode=b.dataset.etmode;
        root.querySelectorAll('[data-etmode]').forEach(q=>q.classList.toggle('on',q===b)); this.reset(); });
      this.etl=root.querySelector('#et-etl'); this.etlo=root.querySelector('#et-etlo');
      if(this.etl){ this.etl.oninput=()=>{ this.ETL=+this.etl.value; this.etlo.textContent=this.ETL; this.reset(); }; this.etlo.textContent=this.ETL; }
      const sp=root.querySelector('#et-sp'); if(sp){ sp.oninput=()=>{ this.speed=+sp.value; root.querySelector('#et-spo').textContent=(+sp.value).toFixed(1)+'×'; };
        root.querySelector('#et-spo').textContent=this.speed.toFixed(1)+'×'; }
      this.reset(); },
    reset(){ this.pt=0; this.block=0; this.counted=0; this.filled=0; this.build(); },
    build(){ // echoes for one TR: {t,amp,col,spin}
      const S = this.mode==='se'?1:this.ETL; const grad = this.mode==='grase'?3:1;
      const T2=8.0; const echoes=[]; const gdt=0.22;
      for(let s=1;s<=S;s++){ const base=s*this.esp;
        for(let g=0;g<grad;g++){ const t=base+(g-(grad-1)/2)*gdt;
          const amp=Math.exp(-t/T2)*(g===0?1:0.82);
          echoes.push({t,amp,col:g===0?C.red:C.green,spin:g===0}); } }
      echoes.sort((a,b)=>a.t-b.t); this.echoes=echoes;
      this.linesPerTR=echoes.length; this.TRdur=(S+0.7)*this.esp;
      this.p180=[]; for(let s=1;s<=S;s++) this.p180.push((s-0.5)*this.esp); },
    tick(t){ if(this.last==null)this.last=t; const dt=Math.min(0.05,t-this.last); this.last=t;
      this.pt+=dt*this.speed*1.1;
      while(this.counted<this.echoes.length && this.pt>=this.echoes[this.counted].t){
        if(this.filled<this.Ny) this.filled++; this.counted++; }
      if(this.pt>=this.TRdur){ this.pt=0; this.counted=0; this.block++;
        if(this.filled>=this.Ny){ this.filled=0; this.block=0; } }
      this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H);
      const tx0=48,tx1=595, t2x=tt=>tx0+tt/this.TRdur*(tx1-tx0);
      const rfY=120, sigY=250;
      // headers
      T(x,'Puls',18,rfY-46,{size:12,col:C.mut,weight:'bold'}); 
      // RF axis
      L(x,tx0,rfY,tx1,rfY,'#d3d7dd',1);
      // 90 excite
      L(x,t2x(0),rfY,t2x(0),rfY-46,C.purple,3); T(x,'90°',t2x(0),rfY-52,{size:12,col:C.purple,weight:'bold',align:'center'});
      // 180 refocus
      this.p180.forEach(tp=>{ L(x,t2x(tp),rfY,t2x(tp),rfY-58,C.red,3); T(x,'180°',t2x(tp),rfY-64,{size:11,col:C.red,weight:'bold',align:'center'}); });
      // signal axis + echoes
      L(x,tx0,sigY,tx1,sigY,'#d3d7dd',1); T(x,'Signal',18,sigY-46,{size:12,col:C.mut,weight:'bold'});
      // T2 envelope
      x.strokeStyle='rgba(192,57,43,0.4)'; x.setLineDash([4,3]); x.lineWidth=1.5; x.beginPath();
      for(let i=0;i<=100;i++){ const tt=i/100*this.TRdur; const a=Math.exp(-tt/8.0); const px=t2x(tt), py=sigY-a*60; i?x.lineTo(px,py):x.moveTo(px,py); } x.stroke(); x.setLineDash([]);
      T(x,'T₂-forfall',t2x(this.TRdur)-4,sigY-58,{size:10.5,col:C.red,align:'end'});
      // echoes (draw humps up to playhead faded, all faint)
      this.echoes.forEach((e,i)=>{ const px=t2x(e.t); const done=this.pt>=e.t; const h=e.amp*60;
        x.strokeStyle=e.col; x.globalAlpha=done?1:0.25; x.lineWidth=2; x.beginPath();
        for(let d=-8;d<=8;d++){ const py=sigY-h*Math.exp(-(d*d)/8); d===-8?x.moveTo(px+d*1.4,py):x.lineTo(px+d*1.4,py); } x.stroke(); x.globalAlpha=1; });
      // playhead
      const phx=t2x(this.pt); L(x,phx,rfY-70,phx,sigY+10,C.green,2);
      // time axis
      L(x,tx0,sigY+30,tx1,sigY+30,'#c3c8cf',1); T(x,'tid (én TR / skudd)',tx1,sigY+46,{size:11,col:C.mut,align:'end'});
      // ---- k-space grid ----
      const gx0=650,gy0=60,gw=270,gh=300, lh=gh/this.Ny;
      x.strokeStyle='#c3c8cf'; x.lineWidth=1.5; x.strokeRect(gx0,gy0,gw,gh);
      T(x,'k-rom',gx0+gw/2,gy0-14,{size:14,col:C.blue,weight:'bold',align:'center'});
      const blockStart=this.block*this.linesPerTR;
      for(let i=0;i<this.Ny;i++){ const yy=gy0+i*lh; const on=i<this.filled;
        const inBlock = i>=blockStart && i<blockStart+this.linesPerTR && i<this.filled;
        x.fillStyle= inBlock?C.amber : on?C.blue : '#eef1f4'; x.fillRect(gx0+1,yy+0.5,gw-2,lh-1); }
      T(x,'Fylt: '+Math.round(this.filled/this.Ny*100)+'%',gx0,gy0+gh+22,{size:12.5,col:C.ink,weight:'bold'});
      T(x,this.linesPerTR+' linjer per skudd',gx0,gy0+gh+42,{size:12.5,col:C.amber,weight:'bold'});
      // caption
      const cap={se:'Spinnekko (SE): ett 180°, ett ekko, én k-linje per TR — nøyaktig, men tregt.',
        tse:'Turbo/Fast SE: flere 180°, et ekkotog → '+this.ETL+' k-linjer per TR ('+this.ETL+'× raskere). T₂-forfall langs toget gir uskarphet.',
        grase:'GRASE: gradient-ekko (grønn) mellom hvert spinnekko → enda flere linjer per TR.'}[this.mode];
      T(x,cap,W/2,H-14,{size:13,col:C.ink,align:'center'}); }
  };

  // ============================================================
  // 2. INVERSJON-RECOVERY:  STIR / FLAIR  (static + slider)
  // ============================================================
  M.ir={ready:false,animated:false,cv:null,x:null,W:960,H:470,TI:180,tmax:4600,
    tissues:[{n:'Fett',T1:260,c:C.amber},{n:'Hvit substans',T1:600,c:C.purple},
             {n:'Grå substans',T1:900,c:C.green},{n:'CSF (væske)',T1:4000,c:C.blue}],
    init(root){ this.cv=root.querySelector('#cv-ir'); this.x=fit(this.cv,this.W,this.H);
      this.ti=root.querySelector('#ir-ti'); this.tio=root.querySelector('#ir-tio');
      this.ti.oninput=()=>{ this.TI=+this.ti.value; this.tio.textContent=this.TI+' ms'; this.draw(); };
      this.tio.textContent=this.TI+' ms';
      root.querySelectorAll('[data-irp]').forEach(b=>b.onclick=()=>{ const p=b.dataset.irp;
        this.TI = p==='stir'?180 : p==='flair'?2773 : 500; this.ti.value=this.TI; this.tio.textContent=this.TI+' ms';
        root.querySelectorAll('[data-irp]').forEach(q=>q.classList.toggle('on',q===b)); this.draw(); });
      this.draw(); },
    mz(t,T1){ return 1-2*Math.exp(-t/T1); },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H);
      const px0=60,px1=650,py0=40,py1=330; const t2x=t=>px0+t/this.tmax*(px1-px0);
      const v2y=v=>py0+(1-(v+1)/2)*(py1-py0);   // v in [-1,1]
      // axes
      L(x,px0,v2y(0),px1,v2y(0),'#c3c8cf',1.2);
      L(x,px0,py0,px0,py1,'#c3c8cf',1.2);
      for(const v of [1,0,-1]){ const yy=v2y(v); L(x,px0-4,yy,px0,yy,'#c3c8cf',1); T(x,v.toFixed(0),px0-8,yy+4,{size:11,col:C.mut,align:'end'}); }
      T(x,'M_z / M₀',px0-8,py0-6,{size:11,col:C.mut,align:'end'});
      for(let tk=0;tk<=4;tk++){ const tt=tk/4*this.tmax; const xx=t2x(tt); L(x,xx,py1,xx,py1+4,'#c3c8cf',1); T(x,Math.round(tt),xx,py1+18,{size:11,col:C.mut,align:'center'}); }
      T(x,'tid etter 180° (ms)',px1,py1+18,{size:11,col:C.mut,align:'end'});
      // recovery curves
      for(const ts of this.tissues){ x.strokeStyle=ts.c; x.lineWidth=2.4; x.beginPath();
        for(let i=0;i<=300;i++){ const tt=i/300*this.tmax; const py=v2y(this.mz(tt,ts.T1)); const xx=t2x(tt); i?x.lineTo(xx,py):x.moveTo(xx,py); } x.stroke();
        // null time tick
        const tn=ts.T1*Math.LN2; if(tn<this.tmax){ const xx=t2x(tn); x.fillStyle=ts.c; x.beginPath(); x.arc(xx,v2y(0),3,0,TAU); x.fill(); } }
      // TI marker
      const tix=t2x(this.TI); L(x,tix,py0,tix,py1,C.ink,1.6,[5,3]); T(x,'TI',tix,py0-6,{size:12,col:C.ink,weight:'bold',align:'center'});
      // dots + brightness bar
      const bx=700, bw=210; T(x,'Signal ∝ |M_z(TI)|',bx,py0-6,{size:13,col:C.ink,weight:'bold'});
      this.tissues.forEach((ts,i)=>{ const mzv=this.mz(this.TI,ts.T1); const yy=v2y(mzv);
        x.fillStyle=ts.c; x.beginPath(); x.arc(tix,yy,5,0,TAU); x.fill();
        // brightness swatch
        const by=py0+18+i*54; const bri=clamp(Math.abs(mzv),0,1);
        const g=Math.round(bri*230+10); x.fillStyle='rgb('+g+','+g+','+g+')'; rr(x,bx,by,60,40,6); x.fill();
        x.strokeStyle=ts.c; x.lineWidth=2.5; rr(x,bx,by,60,40,6); x.stroke();
        T(x,ts.n,bx+70,by+16,{size:13,col:ts.c,weight:'bold'});
        const nulled=Math.abs(mzv)<0.06;
        T(x, nulled?'NULLET (svart)':'|M_z| = '+Math.abs(mzv).toFixed(2), bx+70,by+34,{size:12,col:nulled?C.red:C.mut,weight:nulled?'bold':'normal'}); });
      // caption
      T(x,'STIR: kort TI nuller fett.  FLAIR: lang TI nuller CSF.  Nullpunkt: TI = T₁·ln2.',W/2,H-14,{size:13.5,col:C.ink,align:'center'}); }
  };

  // ============================================================
  // 3. ERNST-VINKEL  (static + sliders)
  // ============================================================
  M.ernst={ready:false,animated:false,cv:null,x:null,W:900,H:460,TR:100,T1:1000,
    init(root){ this.cv=root.querySelector('#cv-er'); this.x=fit(this.cv,this.W,this.H);
      const bind=(id,oid,fmt,set)=>{ const el=root.querySelector(id),o=root.querySelector(oid);
        el.oninput=()=>{ o.textContent=fmt(+el.value); set(+el.value); this.draw(); }; o.textContent=fmt(+el.value); };
      bind('#er-tr','#er-tro',v=>v+' ms',v=>this.TR=v);
      bind('#er-t1','#er-t1o',v=>v+' ms',v=>this.T1=v);
      this.draw(); },
    sig(a,E1){ return Math.sin(a)*(1-E1)/(1-E1*Math.cos(a)); },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H);
      const px0=64,px1=840,py0=44,py1=350; const amax=90;
      const E1=Math.exp(-this.TR/this.T1); const aE=Math.acos(E1);
      // find max signal for y-scale
      let smax=1e-6; for(let d=0;d<=amax;d+=0.2){ const s=this.sig(d*Math.PI/180,E1); if(s>smax)smax=s; }
      const a2x=d=>px0+d/amax*(px1-px0), s2y=s=>py1-(s/(smax*1.12))*(py1-py0);
      // axes
      L(x,px0,py1,px1,py1,'#c3c8cf',1.2); L(x,px0,py0,px0,py1,'#c3c8cf',1.2);
      for(let d=0;d<=amax;d+=15){ const xx=a2x(d); L(x,xx,py1,xx,py1+4,'#c3c8cf',1); T(x,d+'°',xx,py1+18,{size:11,col:C.mut,align:'center'}); }
      T(x,'flippvinkel α',px1,py1+18,{size:12,col:C.mut,align:'end'});
      T(x,'signal (relativt)',px0-8,py0-6,{size:12,col:C.mut,align:'end'});
      // curve
      x.strokeStyle=C.blue; x.lineWidth=2.6; x.beginPath();
      for(let d=0;d<=amax;d+=0.4){ const xx=a2x(d), yy=s2y(this.sig(d*Math.PI/180,E1)); d===0?x.moveTo(xx,yy):x.lineTo(xx,yy); } x.stroke();
      // Ernst marker
      const aEd=aE*180/Math.PI; const ex=a2x(aEd), ey=s2y(this.sig(aE,E1));
      L(x,ex,ey,ex,py1,C.red,1.6,[5,3]); x.fillStyle=C.red; x.beginPath(); x.arc(ex,ey,5,0,TAU); x.fill();
      T(x,'Ernst-vinkel',ex,ey-12,{size:13,col:C.red,weight:'bold',align:'center'});
      T(x,'α_E = '+aEd.toFixed(1)+'°',ex,py1-8,{size:13,col:C.red,weight:'bold',align:'center'});
      // formula + params
      T(x,'Spolet gradient-ekko (GRE):  S(α) = M₀ · sin α · (1−E₁)/(1−E₁cos α),   E₁ = e^(−TR/T₁)',px0,H-40,{size:14,col:C.ink,weight:'bold'});
      T(x,'cos α_E = e^(−TR/T₁)   → maksimalt signal for gitt TR og T₁',px0,H-16,{size:13.5,col:C.blue,weight:'bold'});
      T(x,'TR = '+this.TR+' ms · T₁ = '+this.T1+' ms',px1,py0+6,{size:13,col:C.mut,align:'end'}); }
  };

  // ---- bootstrap ----
  window.runViz=function(name){ const m=M[name]; if(!m){ console.error('unknown viz',name); return; }
    try{ m.init(document); m.ready=true; }catch(e){ console.error(e); }
    if(m.animated && m.tick){ (function loop(ts){ m.tick((ts||0)/1000); requestAnimationFrame(loop); })(); }
    window.addEventListener('resize',function(){ if(!m.cv)return; m.x=fit(m.cv,m.W,m.H); if(!m.animated && m.draw) m.draw(); }); };
  window.__seq2b={M};
})();
