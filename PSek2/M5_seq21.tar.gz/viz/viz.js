/* Sekvens II — interaktive visualiseringer for Quarto reveal.js (lastes via iframe).
   Én modul per side via runViz(navn). FFT verifisert numerisk før innbygging. */
(function(){
  "use strict";
  const F="'DejaVu Sans', Verdana, sans-serif";
  const C={blue:'#2F5FA8',red:'#C0392B',purple:'#5d3a8e',orange:'#b54a16',green:'#10b981',
           amber:'#d99a10',ink:'#1f2430',mut:'#9aa2ad',line:'#e3e6ea',grid:'#eef1f4'};
  const clamp=(v,a,b)=>v<a?a:(v>b?b:v), TAU=Math.PI*2;

  // ---------- verified FFT ----------
  function fft(re,im,inv){ const n=re.length;
    for(let i=1,j=0;i<n;i++){ let bit=n>>1; for(;j&bit;bit>>=1) j^=bit; j^=bit;
      if(i<j){ let t=re[i];re[i]=re[j];re[j]=t; t=im[i];im[i]=im[j];im[j]=t; } }
    for(let len=2;len<=n;len<<=1){ const ang=(inv?2:-2)*Math.PI/len, wr=Math.cos(ang), wi=Math.sin(ang);
      for(let i=0;i<n;i+=len){ let cr=1,ci=0;
        for(let k=0;k<len/2;k++){ const a=i+k,b=i+k+len/2;
          const vr=re[b]*cr-im[b]*ci, vi=re[b]*ci+im[b]*cr;
          re[b]=re[a]-vr; im[b]=im[a]-vi; re[a]+=vr; im[a]+=vi;
          const ncr=cr*wr-ci*wi; ci=cr*wi+ci*wr; cr=ncr; } } }
    if(inv){ for(let i=0;i<n;i++){ re[i]/=n; im[i]/=n; } } }
  function fft2(re,im,w,h,inv){ const rr=new Float64Array(w), ri=new Float64Array(w);
    for(let y=0;y<h;y++){ const o=y*w; for(let x=0;x<w;x++){ rr[x]=re[o+x]; ri[x]=im[o+x]; }
      fft(rr,ri,inv); for(let x=0;x<w;x++){ re[o+x]=rr[x]; im[o+x]=ri[x]; } }
    const cr=new Float64Array(h), ci=new Float64Array(h);
    for(let x=0;x<w;x++){ for(let y=0;y<h;y++){ cr[y]=re[y*w+x]; ci[y]=im[y*w+x]; }
      fft(cr,ci,inv); for(let y=0;y<h;y++){ re[y*w+x]=cr[y]; im[y*w+x]=ci[y]; } } }

  // ---------- head phantom ----------
  function phantom(w,h){ const img=new Float64Array(w*h);
    // layered ellipses (normalised coords, later overwrite earlier): cx,cy,a,b,ang,val
    const E=[[0,0,0.80,0.96,0,0.88],[0,0,0.74,0.90,0,0.42],[0,-0.02,0.58,0.72,0,0.55],
      [-0.16,-0.06,0.07,0.20,0.15,0.12],[0.16,-0.06,0.07,0.20,-0.15,0.12],
      [0,0.34,0.30,0.16,0,0.50],[0.26,0.22,0.075,0.075,0,1.0],[-0.05,-0.42,0.22,0.10,0,0.60]];
    for(let py=0;py<h;py++){ const y=(py/(h-1))*2-1;
      for(let px=0;px<w;px++){ const x=(px/(w-1))*2-1; let v=0;
        for(const e of E){ const ca=Math.cos(e[4]),sa=Math.sin(e[4]);
          const dx=x-e[0], dy=y-e[1]; const u=(dx*ca+dy*sa)/e[2], t=(-dx*sa+dy*ca)/e[3];
          if(u*u+t*t<=1) v=e[5]; }
        img[py*w+px]=v; } }
    return img; }

  // ---------- render helpers ----------
  function offscreen(w,h){ const c=document.createElement('canvas'); c.width=w; c.height=h; return c; }
  function grayTo(cvsCtx,data,w,h,gamma){ const id=cvsCtx.createImageData(w,h);
    for(let i=0;i<w*h;i++){ let v=clamp(data[i],0,1); if(gamma&&gamma!==1) v=Math.pow(v,gamma);
      const g=v*255|0; id.data[i*4]=g; id.data[i*4+1]=g; id.data[i*4+2]=g; id.data[i*4+3]=255; }
    return id; }
  function kdisplay(kr,ki,w,h){ const out=new Float64Array(w*h); let mx=1e-9;
    for(let i=0;i<w*h;i++){ out[i]=Math.log(1+Math.hypot(kr[i],ki[i])); if(out[i]>mx)mx=out[i]; }
    const sh=new Float64Array(w*h);
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){ const sx=(x+(w>>1))%w, sy=(y+(h>>1))%h; sh[sy*w+sx]=out[y*w+x]/mx; }
    return sh; }
  function T(x,s,px,py,o){ o=o||{}; x.globalAlpha=o.alpha==null?1:o.alpha; x.fillStyle=o.col||C.ink;
    x.font=(o.weight||'normal')+' '+(o.size||14)+'px '+F; x.textAlign=o.align||'left';
    x.textBaseline=o.base||'alphabetic'; x.fillText(s,px,py); x.globalAlpha=1; }
  function fit(cv,w,h){ const dpr=Math.max(1,Math.min(2.5,window.devicePixelRatio||1));
    cv.width=w*dpr; cv.height=h*dpr; cv.style.aspectRatio=w+'/'+h;
    const x=cv.getContext('2d'); x.setTransform(dpr,0,0,dpr,0,0); return x; }

  const M={};

  // ============================================================
  // 1. K-SPACE EXPLORER  (static, interactive)
  // ============================================================
  M.kexplorer={ready:false,animated:false,cv:null,x:null,W:960,H:470,N:128,mode:'full',
    kmax:64,radius:14,factor:3,
    init(root){ this.cv=root.querySelector('#cv-kx'); this.x=fit(this.cv,this.W,this.H);
      const N=this.N; this.img=phantom(N,N);
      this.Kr=this.img.slice(); this.Ki=new Float64Array(N*N); fft2(this.Kr,this.Ki,N,N,false);
      this.koff=offscreen(N,N); this.kctx=this.koff.getContext('2d');
      this.ioff=offscreen(N,N); this.ictx=this.ioff.getContext('2d');
      this.sl=root.querySelector('#kx-s'); this.slo=root.querySelector('#kx-so');
      root.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>{ this.mode=b.dataset.mode;
        root.querySelectorAll('[data-mode]').forEach(q=>q.classList.toggle('on',q===b)); this.syncSlider(); this.draw(); });
      this.sl.oninput=()=>{ const v=+this.sl.value;
        if(this.mode==='full') this.kmax=v; else if(this.mode==='under') this.factor=v; else this.radius=v;
        this.draw(); };
      this.syncSlider(); this.draw(); },
    syncSlider(){ const s=this.sl,o=this.slo;
      if(this.mode==='full'){ s.min=4; s.max=64; s.step=2; s.value=this.kmax; o.textContent='k_max = '+this.kmax; }
      else if(this.mode==='under'){ s.min=2; s.max=5; s.step=1; s.value=this.factor; o.textContent='R = '+this.factor+'×'; }
      else { s.min=4; s.max=60; s.step=2; s.value=this.radius; o.textContent='radius = '+this.radius; } },
    recon(){ const N=this.N; const kr=this.Kr.slice(), ki=this.Ki.slice();
      const keep=(fx,fy,y)=>{ if(this.mode==='full') return Math.abs(fx)<=this.kmax && Math.abs(fy)<=this.kmax;
        if(this.mode==='low') return fx*fx+fy*fy<=this.radius*this.radius;
        if(this.mode==='high') return fx*fx+fy*fy>=this.radius*this.radius;
        return (y % this.factor)===0; };
      for(let y=0;y<N;y++)for(let x=0;x<N;x++){ const fx=(x<N/2?x:x-N), fy=(y<N/2?y:y-N);
        if(!keep(fx,fy,y)){ kr[y*N+x]=0; ki[y*N+x]=0; } }
      // update slider readout side-effects (kept %, matrix)
      this.kdisp=kdisplay(kr,ki,N,N);
      fft2(kr,ki,N,N,true); const out=new Float64Array(N*N); let mx=1e-9;
      for(let i=0;i<N*N;i++){ out[i]=Math.hypot(kr[i],ki[i]); if(out[i]>mx)mx=out[i]; }
      for(let i=0;i<N*N;i++) out[i]/=mx; return out; },
    draw(){ const x=this.x,W=this.W,H=this.H,N=this.N; if(!x)return; x.clearRect(0,0,W,H);
      const rec=this.recon();
      const size=360, gap=70, x0=40, x1=x0+size+gap, y0=48;
      // k-space
      this.kctx.putImageData(grayTo(this.kctx,this.kdisp,N,N,0.9),0,0);
      x.imageSmoothingEnabled=false; x.drawImage(this.koff,x0,y0,size,size);
      // image
      this.ictx.putImageData(grayTo(this.ictx,rec,N,N,1),0,0);
      x.imageSmoothingEnabled=true; x.drawImage(this.ioff,x1,y0,size,size);
      // borders + labels
      x.strokeStyle='#c3c8cf'; x.lineWidth=1.5; x.strokeRect(x0,y0,size,size); x.strokeRect(x1,y0,size,size);
      T(x,'k-rom (bevart del)',x0+size/2,y0-16,{size:15,col:C.blue,weight:'bold',align:'center'});
      T(x,'← k_FE →',x0+size/2,y0+size+22,{size:12,col:C.mut,align:'center'});
      T(x,'Bilde (invers Fourier)',x1+size/2,y0-16,{size:15,col:C.green,weight:'bold',align:'center'});
      // arrow between
      const ay=y0+size/2; x.strokeStyle=C.mut; x.lineWidth=2;
      x.beginPath(); x.moveTo(x0+size+12,ay); x.lineTo(x1-12,ay); x.stroke();
      x.fillStyle=C.mut; x.beginPath(); x.moveTo(x1-12,ay); x.lineTo(x1-22,ay-6); x.lineTo(x1-22,ay+6); x.closePath(); x.fill();
      T(x,'FT⁻¹',(x0+size+x1)/2,ay-10,{size:12,col:C.mut,align:'center',weight:'bold'});
      // effect caption
      const cap={full:'Beskjærer k-rom til et sentralt kvadrat → lavere k_max gir grovere oppløsning (uskarpt).',
        low:'Beholder bare sentrum → kontrast og grovform, men ingen skarpe kanter (lavpass).',
        high:'Beholder bare ytterkant → kanter og detaljer, men ingen jevn kontrast (høypass).',
        under:'Hopper over hver R-te fasekodingslinje → mindre FoV → innbretting (aliasing).'}[this.mode];
      T(x,cap,W/2,H-16,{size:13.5,col:C.ink,align:'center'}); }
  };

  // ============================================================
  // 2. K-SPACE TRAJECTORY ANIMATOR  (animated)
  // ============================================================
  M.traj={ready:false,animated:true,cv:null,x:null,W:960,H:460,mode:'seq',Ny:32,N:64,
    order:[], filled:0, acc:0, speed:2.2, last:null,
    init(root){ this.cv=root.querySelector('#cv-tr'); this.x=fit(this.cv,this.W,this.H);
      const N=this.N; this.img=phantom(N,N); this.Kr=this.img.slice(); this.Ki=new Float64Array(N*N);
      fft2(this.Kr,this.Ki,N,N,false);
      this.ioff=offscreen(N,N); this.ictx=this.ioff.getContext('2d');
      root.querySelectorAll('[data-tmode]').forEach(b=>b.onclick=()=>{ this.mode=b.dataset.tmode;
        root.querySelectorAll('[data-tmode]').forEach(q=>q.classList.toggle('on',q===b)); this.build(); });
      const sp=root.querySelector('#tr-sp'); if(sp){ sp.oninput=()=>{ this.speed=+sp.value; root.querySelector('#tr-spo').textContent=(+sp.value).toFixed(1)+'×'; };
        root.querySelector('#tr-spo').textContent=this.speed.toFixed(1)+'×'; }
      const rb=root.querySelector('#tr-restart'); if(rb) rb.onclick=()=>this.build();
      this.build(); },
    build(){ const Ny=this.Ny; const lines=[]; const half=Ny/2;
      if(this.mode==='seq'){ for(let i=0;i<Ny;i++) lines.push(i); }         // top -> bottom
      else if(this.mode==='centric'){ // center out, alternating
        let a=half-1,b=half; while(lines.length<Ny){ if(b<Ny)lines.push(b++); if(a>=0)lines.push(a--); } }
      else { // spiral (non-Cartesian) handled separately in draw; still track progress
        for(let i=0;i<Ny;i++) lines.push(i); }
      this.order=lines; this.filled=0; this.acc=0; this.recImg=new Float64Array(this.N*this.N); },
    reconPartial(){ const N=this.N; const kr=new Float64Array(N*N), ki=new Float64Array(N*N);
      const rows=new Set(this.order.slice(0,this.filled).map(r=>this.rowToK(r)));
      for(let y=0;y<N;y++) if(rows.has(y)){ for(let x=0;x<N;x++){ kr[y*N+x]=this.Kr[y*N+x]; ki[y*N+x]=this.Ki[y*N+x]; } }
      fft2(kr,ki,N,N,true); let mx=1e-9; const out=new Float64Array(N*N);
      for(let i=0;i<N*N;i++){ out[i]=Math.hypot(kr[i],ki[i]); if(out[i]>mx)mx=out[i]; }
      for(let i=0;i<N*N;i++) out[i]/=mx; this.recImg=out; },
    rowToK(lineIdx){ // map a display line index (0..Ny-1, DC at center) to k-space row (DC at 0)
      const N=this.N, Ny=this.Ny; const off=lineIdx-Ny/2; const ky=Math.round(off*(N/Ny));
      return ((ky%N)+N)%N; },
    tick(t){ if(this.last==null)this.last=t; const dt=Math.min(0.05,t-this.last); this.last=t;
      if(this.filled<this.order.length){ this.acc+=dt*this.speed*6;
        while(this.acc>=1 && this.filled<this.order.length){ this.acc-=1; this.filled++; }
        if(this.mode!=='spiral') this.reconPartial(); }
      this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H);
      const gx0=40,gy0=48,gs=340;   // k-space grid box
      const ix0=560,iy0=48,is=340;  // recon box
      x.strokeStyle='#c3c8cf'; x.lineWidth=1.5; x.strokeRect(gx0,gy0,gs,gs); x.strokeRect(ix0,iy0,is,is);
      T(x,'k-rom — fyllerekkefølge',gx0+gs/2,gy0-16,{size:15,col:C.blue,weight:'bold',align:'center'});
      T(x,'Bilde bygges opp',ix0+is/2,iy0-16,{size:15,col:C.green,weight:'bold',align:'center'});
      if(this.mode==='spiral'){ this.drawSpiral(x,gx0,gy0,gs); }
      else {
        const Ny=this.Ny, lh=gs/Ny;
        const doneSet=new Set(this.order.slice(0,this.filled));
        for(let i=0;i<Ny;i++){ const yy=gy0+i*lh; const on=doneSet.has(i);
          x.fillStyle= on? (i===Ny/2||i===Ny/2-1?C.red:C.blue) : '#eef1f4';
          x.fillRect(gx0+1,yy+0.5,gs-2,lh-1); }
        // current line highlight
        if(this.filled>0 && this.filled<=this.order.length){ const cur=this.order[this.filled-1];
          const yy=gy0+cur*lh; x.strokeStyle=C.amber; x.lineWidth=2; x.strokeRect(gx0+1,yy+0.5,gs-2,lh-1); }
        T(x,'DC (sentrum)',gx0+gs+6,gy0+gs/2+4,{size:11,col:C.red,weight:'bold'});
        x.strokeStyle=C.red; x.setLineDash([3,3]); x.beginPath(); x.moveTo(gx0,gy0+gs/2); x.lineTo(gx0+gs,gy0+gs/2); x.stroke(); x.setLineDash([]);
      }
      // recon image
      if(this.mode!=='spiral'){ this.ictx.putImageData(grayTo(this.ictx,this.recImg,this.N,this.N,1),0,0);
        x.imageSmoothingEnabled=true; x.drawImage(this.ioff,ix0,iy0,is,is); }
      else { T(x,'(spiral: ikke-kartesisk bane)',ix0+is/2,iy0+is/2,{size:14,col:C.mut,align:'center'}); }
      // progress
      const pct=Math.round(this.filled/this.order.length*100);
      T(x,'Fylt: '+pct+'%',gx0,gy0+gs+26,{size:13.5,col:C.ink,weight:'bold'});
      const names={seq:'Sekvensiell (topp → bunn): kanter/oppløsning tidlig, kontrast til slutt.',
        centric:'Sentrisk (sentrum → ut): kontrast med en gang, detaljer til slutt.',
        spiral:'Spiral: én kontinuerlig bane fra sentrum og utover (ikke-kartesisk).'};
      T(x,names[this.mode],W/2,H-14,{size:13,col:C.ink,align:'center'}); },
    drawSpiral(x,gx,gy,gs){ const cx=gx+gs/2, cy=gy+gs/2, R=gs/2-6;
      const turns=6, tmax=this.filled/this.order.length; x.strokeStyle=C.blue; x.lineWidth=2; x.beginPath();
      const steps=400; for(let i=0;i<=steps*tmax;i++){ const u=i/steps; const ang=u*turns*TAU; const r=u*R;
        const px=cx+Math.cos(ang)*r, py=cy+Math.sin(ang)*r; i?x.lineTo(px,py):x.moveTo(px,py); } x.stroke();
      if(tmax>0){ const u=tmax, ang=u*turns*TAU, r=u*R; x.fillStyle=C.amber;
        x.beginPath(); x.arc(cx+Math.cos(ang)*r,cy+Math.sin(ang)*r,4,0,TAU); x.fill(); }
      x.fillStyle=C.red; x.beginPath(); x.arc(cx,cy,3,0,TAU); x.fill(); }
  };

  // ============================================================
  // 3. MULTI-SLICE TIMELINE  (animated)
  // ============================================================
  M.multislice={ready:false,animated:true,cv:null,x:null,W:960,H:430,mode:'single',
    TR:600,TE:30,readout:40,nSlices:6,t:0,last:null,speed:220,
    init(root){ this.cv=root.querySelector('#cv-ms'); this.x=fit(this.cv,this.W,this.H);
      root.querySelectorAll('[data-msmode]').forEach(b=>b.onclick=()=>{ this.mode=b.dataset.msmode;
        root.querySelectorAll('[data-msmode]').forEach(q=>q.classList.toggle('on',q===b)); this.t=0; });
      const bind=(id,oid,fmt,set)=>{ const el=root.querySelector(id),o=root.querySelector(oid);
        if(!el)return; el.oninput=()=>{ o.textContent=fmt(+el.value); set(+el.value); this.t=0; }; o.textContent=fmt(+el.value); };
      bind('#ms-tr','#ms-tro',v=>v+' ms',v=>this.TR=v);
      bind('#ms-n','#ms-no',v=>v,v=>this.nSlices=v);
      this.t=0; },
    tick(t){ if(this.last==null)this.last=t; const dt=Math.min(0.05,t-this.last); this.last=t;
      this.t+=dt*this.speed; if(this.t>this.TR) this.t-=this.TR; this.draw(); },
    seg(){ return this.TE+this.readout; },        // time occupied by one slice's excite+readout
    maxSlices(){ return Math.max(1,Math.floor(this.TR/this.seg())); },
    draw(){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H);
      const L=60,R=W-40, tw=R-L, y0=70; const t2x=tt=>L+tt/this.TR*tw;
      const nS = this.mode==='single'?1:Math.min(this.nSlices,this.maxSlices());
      const laneH=34, laneGap=8, lanesTop=y0;
      // title / TR bar
      T(x,'Én TR = '+this.TR+' ms'+(this.mode==='single'?'  ·  1 snitt':'  ·  '+nS+' snitt'),L,40,{size:16,col:C.ink,weight:'bold'});
      // time axis
      x.strokeStyle='#c3c8cf'; x.lineWidth=1; const axisY=lanesTop+nS*(laneH+laneGap)+16;
      line(x,L,axisY,R,axisY,'#c3c8cf',1);
      for(let k=0;k<=4;k++){ const tt=k/4*this.TR; const px=t2x(tt); line(x,px,axisY,px,axisY+5,'#c3c8cf',1);
        T(x,Math.round(tt)+'',px,axisY+20,{size:11,col:C.mut,align:'center'}); }
      T(x,'tid (ms)',R,axisY+20,{size:11,col:C.mut,align:'end'});
      // TR boundary
      line(x,t2x(this.TR),lanesTop-10,t2x(this.TR),axisY,C.mut,1.4,[4,3]);
      T(x,'TR',t2x(this.TR)-4,lanesTop-14,{size:12,col:C.mut,align:'end',weight:'bold'});
      // lanes (slices)
      for(let s=0;s<nS;s++){ const ly=lanesTop+s*(laneH+laneGap);
        const start=this.mode==='single'?0:s*this.seg();
        // lane bg
        x.fillStyle='#f5f6f8'; rr(x,L,ly,tw,laneH,6); x.fill();
        T(x,'Snitt '+(s+1),L-8,ly+laneH/2+4,{size:11.5,col:C.mut,align:'end'});
        // RF excite (thin) at start
        const exX=t2x(start); x.fillStyle=C.purple; x.fillRect(exX,ly+3,3,laneH-6);
        T(x,'RF',exX+5,ly+12,{size:9.5,col:C.purple,weight:'bold'});
        // TE gap then readout block
        const roX=t2x(start+this.TE), roW=t2x(start+this.TE+this.readout)-roX;
        x.fillStyle=C.blue; rr(x,roX,ly+6,roW,laneH-12,4); x.fill();
        T(x,'lesing',roX+roW/2,ly+laneH/2+4,{size:10.5,col:'#fff',weight:'bold',align:'center'});
        // TE bracket
        line(x,exX,ly+laneH-2,roX,ly+laneH-2,C.amber,1.2);
        T(x,'TE',(exX+roX)/2,ly+laneH+9,{size:9.5,col:C.amber,align:'center'});
      }
      // dead time (single) shading
      if(this.mode==='single'){ const d0=t2x(this.TE+this.readout), d1=t2x(this.TR);
        x.fillStyle='rgba(192,57,43,0.10)'; x.fillRect(d0,lanesTop,d1-d0,nS*(laneH+laneGap)-laneGap);
        T(x,'dødtid — sløst ('+(this.TR-this.TE-this.readout)+' ms)',(d0+d1)/2,lanesTop+laneH/2+4,{size:12.5,col:C.red,weight:'bold',align:'center'}); }
      // playhead
      const px=t2x(this.t); line(x,px,lanesTop-10,px,axisY,C.green,2);
      x.fillStyle=C.green; x.beginPath(); x.moveTo(px,lanesTop-10); x.lineTo(px-5,lanesTop-18); x.lineTo(px+5,lanesTop-18); x.closePath(); x.fill();
      // caption
      const cap=this.mode==='single'
        ? 'Ett snitt per TR: etter lesing venter vi til neste TR — det meste av tiden er tom.'
        : 'Flettet fleroppdeling: dødtiden fylles med andre snitt → opptil '+this.maxSlices()+' snitt i samme TR.';
      T(x,cap,W/2,H-14,{size:13.5,col:C.ink,align:'center'}); }
  };
  function line(x,a,b,c,d,col,w,dash){ x.strokeStyle=col; x.lineWidth=w||1; x.setLineDash(dash||[]);
    x.beginPath(); x.moveTo(a,b); x.lineTo(c,d); x.stroke(); x.setLineDash([]); }
  function rr(x,px,py,w,h,r){ x.beginPath(); x.moveTo(px+r,py); x.arcTo(px+w,py,px+w,py+h,r);
    x.arcTo(px+w,py+h,px,py+h,r); x.arcTo(px,py+h,px,py,r); x.arcTo(px,py,px+w,py,r); x.closePath(); }

  // ---- bootstrap ----
  window.runViz=function(name){ const m=M[name]; if(!m){ console.error('unknown viz',name); return; }
    try{ m.init(document); m.ready=true; }catch(e){ console.error(e); }
    if(m.animated && m.tick){ (function loop(ts){ m.tick((ts||0)/1000); requestAnimationFrame(loop); })(); }
    window.addEventListener('resize',function(){ if(!m.cv)return; m.x=fit(m.cv,m.W,m.H); if(!m.animated && m.draw) m.draw(); }); };
  window.__seq={M,phantom,fft2};
})();
