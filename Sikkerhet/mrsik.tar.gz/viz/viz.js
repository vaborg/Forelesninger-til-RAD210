/* MRI-sikkerhet — interaktive visualiseringer (lastes i Quarto reveal.js via iframe).
   Én modul kjøres per side via runViz(navn). Fysikk verifisert i Node før innbygging. */
(function(){
  "use strict";
  const F="'DejaVu Sans', Verdana, sans-serif";
  const C={blue:'#2F5FA8',red:'#C0392B',purple:'#5d3a8e',orange:'#b54a16',green:'#10b981',
           ink:'#1f2430',mut:'#9aa2ad',grid:'#eef1f4',amber:'#d99a10'};
  function fit(cv,w,h){ const dpr=Math.max(1,Math.min(2.5,window.devicePixelRatio||1));
    cv.width=w*dpr; cv.height=h*dpr; cv.style.aspectRatio=w+'/'+h;
    const x=cv.getContext('2d'); x.setTransform(dpr,0,0,dpr,0,0); return x; }
  function T(x,s,px,py,o){ o=o||{}; x.globalAlpha=1; x.fillStyle=o.col||C.ink;
    x.font=(o.weight||'normal')+' '+(o.size||14)+'px '+F; x.textAlign=o.align||'left';
    x.textBaseline=o.base||'alphabetic'; x.fillText(s,px,py); }
  function L(x,a,b,c,d,col,w,dash){ x.strokeStyle=col; x.lineWidth=w||1; x.globalAlpha=1;
    x.setLineDash(dash||[]); x.beginPath(); x.moveTo(a,b); x.lineTo(c,d); x.stroke(); x.setLineDash([]); }
  function rr(x,px,py,w,h,r){ x.beginPath(); x.moveTo(px+r,py); x.arcTo(px+w,py,px+w,py+h,r);
    x.arcTo(px+w,py+h,px,py+h,r); x.arcTo(px,py+h,px,py,r); x.arcTo(px,py,px+w,py,r); x.closePath(); }
  const clamp=(v,a,b)=>v<a?a:(v>b?b:v);
  // horizontal bar gauge with threshold ticks
  function barGauge(x,gx,gy,gw,gh,frac,col,ticks,vmin,vmax){
    x.fillStyle='#eef1f4'; rr(x,gx,gy,gw,gh,gh/2); x.fill();
    const w=clamp(frac,0,1)*gw; x.fillStyle=col; rr(x,gx,gy,Math.max(gh,w),gh,gh/2); x.fill();
    (ticks||[]).forEach(t=>{ const fx=gx+(t.v-vmin)/(vmax-vmin)*gw;
      L(x,fx,gy-3,fx,gy+gh+3,t.col||'#555',1.5,[3,3]);
      T(x,t.lab,fx,gy-6,{size:11,col:t.col||'#555',align:'center',weight:'bold'}); });
  }
  const M={};

  // ============================================================
  // 1. MISSILE / PROSJEKTIL-EFFEKTEN  (animated loop)
  // ============================================================
  M.missile={ready:false,animated:true,cv:null,x:null,W:960,H:430,obj:'flaske',last:null,
    B0:1.5,Rm:0.9,Pmax:1.66,
    P(z){ const R=this.Rm,B0=this.B0; const b=B0*R**3/(R*R+z*z)**1.5; const db=3*B0*R**3*z/(R*R+z*z)**2.5; return b*db; },
    init(root){ this.cv=root.querySelector('#cv-missile'); this.x=fit(this.cv,this.W,this.H);
      this.dEl=root.querySelector('#mi-d'); const o=root.querySelector('#mi-do');
      root.querySelectorAll('[data-obj]').forEach(b=>{ b.onclick=()=>{ this.obj=b.dataset.obj;
        root.querySelectorAll('[data-obj]').forEach(q=>q.classList.remove('on')); b.classList.add('on'); }; });
      const first=root.querySelector('[data-obj]'); if(first)first.classList.add('on');
      this.dEl.oninput=()=>{ o.textContent=(+this.dEl.value).toFixed(1)+' m'; this.reset(); };
      o.textContent=(+this.dEl.value).toFixed(1)+' m'; this.reset(); },
    reset(){ this.z=+this.dEl.value; this.v=0; this.phase='fly'; this.flash=0; this.hold=0; },
    tick(t){ if(this.last==null)this.last=t; let dt=Math.min(0.05,t-this.last); this.last=t;
      if(this.phase==='fly'){ const a=-(0.02+this.P(Math.max(0.03,this.z))/this.Pmax)*6.5;
        this.v+=a*dt; this.z+=this.v*dt;
        if(this.z<=0.05){ this.z=0.05; this.phase='impact'; this.flash=1; this.hold=0; } }
      else { this.flash=Math.max(0,this.flash-dt*2.2); this.hold+=dt; if(this.hold>1.1) this.reset(); }
      this.draw(); },
    drawObj(x,px,py,s){ const o=this.obj; x.lineWidth=2.5; x.lineJoin='round';
      if(o==='flaske'){ x.fillStyle='#2f8f6f'; rr(x,px-9*s,py-22*s,18*s,44*s,7*s); x.fill();
        x.fillStyle='#555'; x.fillRect(px-4*s,py-30*s,8*s,10*s); x.strokeStyle='#1c6b52'; rr(x,px-9*s,py-22*s,18*s,44*s,7*s); x.stroke();
        T(x,'O₂',px,py+4*s,{size:12*s,col:'#fff',align:'center',weight:'bold'}); }
      else if(o==='kjetting'){ x.strokeStyle='#7a7f88'; x.fillStyle='none';
        for(let i=-2;i<=2;i++){ x.beginPath(); x.ellipse(px+i*11*s,py,6*s,9*s,0,0,7); x.stroke(); } }
      else if(o==='saks'){ x.strokeStyle='#6b7280'; L(x,px-16*s,py-12*s,px+14*s,py+12*s,'#6b7280',3*s);
        L(x,px-16*s,py+12*s,px+14*s,py-12*s,'#6b7280',3*s);
        x.beginPath(); x.arc(px-16*s,py-12*s,5*s,0,7); x.arc(px-16*s,py+12*s,5*s,0,7); x.stroke(); }
      else { x.strokeStyle='#6b7280'; x.beginPath(); x.arc(px-4*s,py+14*s,15*s,0,7); x.stroke();
        L(x,px-12*s,py-16*s,px+8*s,py-16*s,'#6b7280',3*s); L(x,px+8*s,py-16*s,px+8*s,py+2*s,'#6b7280',3*s);
        L(x,px-12*s,py-16*s,px-12*s,py+2*s,'#6b7280',3*s); } },
    draw(){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H);
      const xIso=815, yMid=190, scale=(xIso-70)/3.0;
      // fringe field glow
      const g=x.createRadialGradient(xIso,yMid,20,xIso,yMid,430);
      g.addColorStop(0,'rgba(47,95,168,0.30)'); g.addColorStop(0.4,'rgba(47,95,168,0.10)'); g.addColorStop(1,'rgba(47,95,168,0)');
      x.fillStyle=g; x.fillRect(0,0,W,300);
      for(let i=1;i<=4;i++){ x.strokeStyle='rgba(47,95,168,'+(0.28-i*0.05)+')'; x.lineWidth=1;
        x.beginPath(); x.ellipse(xIso,yMid,i*95,i*70,0,0,7); x.stroke(); }
      // magnet body + bore
      x.fillStyle='#dfe3e8'; rr(x,xIso-6,yMid-96,150,192,16); x.fill();
      x.strokeStyle='#c3c8cf'; x.lineWidth=1.5; rr(x,xIso-6,yMid-96,150,192,16); x.stroke();
      x.fillStyle='#11151c'; x.beginPath(); x.ellipse(xIso+2,yMid,26,58,0,0,7); x.fill();
      T(x,'MR-magnet',xIso+70,yMid-104,{size:13,col:C.mut,align:'center',weight:'bold'});
      T(x,'ALLTID PÅ',xIso+70,yMid+118,{size:14,col:C.red,align:'center',weight:'bold'});
      // object
      const ox=xIso - this.z*scale;
      const arrow=(0.02+this.P(Math.max(0.03,this.z))/this.Pmax); // 0..1
      this.drawObj(x,ox,yMid,1.15);
      // force arrow toward bore
      const alen=30+arrow*70; L(x,ox+22,yMid,ox+22+alen,yMid,C.red,3+arrow*3);
      x.fillStyle=C.red; x.beginPath(); x.moveTo(ox+22+alen,yMid); x.lineTo(ox+22+alen-11,yMid-7); x.lineTo(ox+22+alen-11,yMid+7); x.closePath(); x.fill();
      // impact flash
      if(this.flash>0){ x.globalAlpha=this.flash; x.fillStyle='#ffd34d'; x.beginPath();
        for(let k=0;k<12;k++){ const a=k/12*Math.PI*2, r=(k%2?18:42)*(0.6+this.flash*0.6); const px=xIso+Math.cos(a)*r, py=yMid+Math.sin(a)*r*0.9; k?x.lineTo(px,py):x.moveTo(px,py); } x.closePath(); x.fill(); x.globalAlpha=1;
        T(x,'TREFF',xIso-70,yMid-70,{size:20,col:C.red,align:'center',weight:'bold'}); }
      // distance markers
      L(x,70,yMid+96,xIso,yMid+96,'#d3d7dd',1);
      for(let m=0;m<=3;m++){ const px=xIso-m*scale; L(x,px,yMid+92,px,yMid+100,'#c3c8cf',1);
        T(x,m+' m',px,yMid+114,{size:11,col:C.mut,align:'center'}); }
      // force gauge (left)
      T(x,'Tiltrekkende kraft  ∝  B · dB/dz',60,28,{size:15,col:C.ink,weight:'bold'});
      barGauge(x,60,42,300,16,arrow,arrow>0.6?C.red:arrow>0.3?C.amber:C.green,[],0,1);
      T(x, arrow>0.6?'ENORM nær boringen':arrow>0.3?'øker bratt':'liten på avstand',
        60,80,{size:12.5,col:arrow>0.6?C.red:C.mut,weight:'bold'});
      // force-vs-distance curve (bottom)
      const cx0=60,cx1=900,cy0=300,cy1=395;
      T(x,'Kraft mot avstand',cx0,cy0-6,{size:12.5,col:C.mut,weight:'bold'});
      L(x,cx0,cy1,cx1,cy1,'#d3d7dd',1);
      x.strokeStyle=C.blue; x.lineWidth=2.2; x.beginPath();
      for(let i=0;i<=300;i++){ const zz=3.0*(1-i/300); const px=cx0+(cx1-cx0)*i/300;
        const py=cy1-(this.P(Math.max(0.03,zz))/this.Pmax)*(cy1-cy0); i?x.lineTo(px,py):x.moveTo(px,py); } x.stroke();
      const mpx=cx0+(cx1-cx0)*(1-this.z/3.0); L(x,mpx,cy0,mpx,cy1,'rgba(192,57,43,0.6)',1.5,[4,3]);
      T(x,'boring',cx1-4,cy1-4,{size:11,col:C.mut,align:'end'}); T(x,'3 m',cx0+4,cy1-4,{size:11,col:C.mut}); }
  };

  // ============================================================
  // 2. RF og SAR  (static)
  // ============================================================
  M.sar={ready:false,animated:false,cv:null,x:null,W:960,H:380,B0:3,seq:'FSE',k:0.00082,
    init(root){ this.cv=root.querySelector('#cv-sar'); this.x=fit(this.cv,this.W,this.H);
      this.aEl=root.querySelector('#sar-a'); this.trEl=root.querySelector('#sar-tr');
      this.nEl=root.querySelector('#sar-n'); this.etlEl=root.querySelector('#sar-etl');
      const outs=()=>{ root.querySelector('#sar-ao').textContent=this.aEl.value+'°';
        root.querySelector('#sar-tro').textContent=this.trEl.value+' ms';
        root.querySelector('#sar-no').textContent=this.nEl.value;
        root.querySelector('#sar-etlo').textContent=this.etlEl.value; };
      [this.aEl,this.trEl,this.nEl,this.etlEl].forEach(e=>e.oninput=()=>{ outs(); this.draw(); });
      root.querySelectorAll('[data-b0]').forEach(b=>b.onclick=()=>{ this.B0=+b.dataset.b0;
        root.querySelectorAll('[data-b0]').forEach(q=>q.classList.toggle('on',q===b)); this.draw(); });
      root.querySelectorAll('[data-seq]').forEach(b=>b.onclick=()=>{ this.seq=b.dataset.seq;
        root.querySelectorAll('[data-seq]').forEach(q=>q.classList.toggle('on',q===b)); this.draw(); });
      root.querySelectorAll('[data-fix]').forEach(b=>b.onclick=()=>{ const f=b.dataset.fix;
        if(f==='tr') this.trEl.value=Math.min(+this.trEl.max,Math.round(+this.trEl.value*1.7));
        if(f==='a') this.aEl.value=Math.max(+this.aEl.min,+this.aEl.value-30);
        if(f==='n') this.nEl.value=Math.max(+this.nEl.min,Math.round(+this.nEl.value/2));
        if(f==='gre'){ this.seq='GRE'; this.aEl.value=25; root.querySelectorAll('[data-seq]').forEach(q=>q.classList.toggle('on',q.dataset.seq==='GRE')); }
        outs(); this.draw(); });
      outs(); this.draw(); },
    val(){ const a=+this.aEl.value,TR=+this.trEl.value/1000,N=+this.nEl.value,ETL=+this.etlEl.value; let eff;
      if(this.seq==='GRE') eff=N*((a/180)**2)/TR;
      else { const e=(this.seq==='SE')?1:ETL; eff=N*(0.25+e*(a/180)**2)/TR; }
      return this.k*this.B0*this.B0*eff; },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H);
      const S=this.val(), dT=0.25*S;
      const col = S>4?C.red : S>2?C.amber : C.green;
      // SAR vertical bar
      const bx=90,bTop=50,bBot=330,bh=bBot-bTop, smax=6;
      T(x,'Helkropps-SAR',bx+20,34,{size:15,col:C.ink,weight:'bold',align:'center'});
      x.fillStyle='#eef1f4'; rr(x,bx,bTop,40,bh,6); x.fill();
      const hh=clamp(S/smax,0,1)*bh; x.fillStyle=col; rr(x,bx,bBot-hh,40,hh,6); x.fill();
      [[2,'Normal 2',C.green],[4,'1. nivå 4',C.amber]].forEach(t=>{ const ly=bBot-(t[0]/smax)*bh;
        L(x,bx-8,ly,bx+48,ly,t[2],1.6,[5,3]); T(x,t[1],bx+54,ly+4,{size:12,col:t[2],weight:'bold'}); });
      T(x,S.toFixed(2),bx+20,bBot-hh-8,{size:16,col:col,align:'center',weight:'bold'});
      T(x,'W/kg',bx+20,bBot+18,{size:12,col:C.mut,align:'center'});
      // status
      const st = S>4?'Over grensen — ikke tillatt' : S>2?'Første nivå — krever medisinsk tilsyn' : 'Normal modus — rutine';
      T(x,st,bx-10,bBot+40,{size:13.5,col:col,weight:'bold'});
      // temperature
      const tx=330; T(x,'Kjernetemperatur ↑',tx,34,{size:14,col:C.ink,weight:'bold'});
      const tmax=1.5, tgh=bBot-bTop;
      x.fillStyle='#eef1f4'; rr(x,tx,bTop,34,tgh,6); x.fill();
      const thh=clamp(dT/tmax,0,1)*tgh; x.fillStyle=dT>1?C.red:dT>0.5?C.amber:C.green; rr(x,tx,bBot-thh,34,thh,6); x.fill();
      [[0.5,'0,5 °C'],[1.0,'1,0 °C']].forEach(t=>{ const ly=bBot-(t[0]/tmax)*tgh; L(x,tx-6,ly,tx+40,ly,'#999',1.4,[5,3]);
        T(x,t[1],tx+46,ly+4,{size:11.5,col:'#777'}); });
      T(x,'+'+dT.toFixed(2).replace('.',',')+' °C',tx+17,bBot-thh-8,{size:13,col:dT>1?C.red:C.ink,align:'center',weight:'bold'});
      // equation + summary (right)
      const ex=560; T(x,'SAR  =  σ |E|²  /  ρ',ex,70,{size:22,col:C.ink,weight:'bold'});
      T(x,'σ ledningsevne · E elektrisk felt · ρ vevstetthet',ex,96,{size:12.5,col:C.mut});
      const rows=[['Felt B₀',this.B0+' T   (SAR ∝ B₀²)'],['Sekvens',this.seq],
        ['Vinkel α',this.aEl.value+'°   (SAR ∝ α²)'],['TR',this.trEl.value+' ms   (SAR ∝ 1/TR)'],
        ['Antall snitt',this.nEl.value],['ETL (FSE)',this.seq==='FSE'?this.etlEl.value:'—']];
      rows.forEach((r,i)=>{ const yy=140+i*30; T(x,r[0],ex,yy,{size:13.5,col:C.mut});
        T(x,r[1],ex+140,yy,{size:13.5,col:C.ink,weight:'bold'}); });
      T(x,'Reduser SAR: ↓vinkel, ↓snitt, ↓B₀, ↑TR, VERSE/hyperecho, GRE',ex,H-14,{size:12.5,col:C.blue,weight:'bold'}); }
  };

  // ============================================================
  // 3. GRADIENTER: støy + nervestimulering  (animated)
  // ============================================================
  M.gradients={ready:false,animated:true,cv:null,x:null,W:960,H:400,ph:0,last:null,rheo:15,tc:360e-6,rper:0.30,
    spl(G){ return clamp(95+25*Math.log10((G/20)*(3/1.5)+0.3),80,132); },
    pns(G,SR){ const t=(G/1000)/SR; const dBdt=SR*this.rper; const thr=this.rheo*(1+this.tc/t); return dBdt/thr; },
    init(root){ this.cv=root.querySelector('#cv-grad'); this.x=fit(this.cv,this.W,this.H);
      this.gEl=root.querySelector('#gr-g'); this.srEl=root.querySelector('#gr-sr');
      const o=()=>{ root.querySelector('#gr-go').textContent=this.gEl.value+' mT/m';
        root.querySelector('#gr-sro').textContent=this.srEl.value+' T/m/s'; };
      [this.gEl,this.srEl].forEach(e=>e.oninput=o); o(); },
    tick(t){ if(this.last==null)this.last=t; const dt=Math.min(0.05,t-this.last); this.last=t;
      const G=+this.gEl.value; this.ph+=dt*(6+G*0.25); this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H);
      const G=+this.gEl.value, SR=+this.srEl.value; const dB=this.spl(G), pr=this.pns(G,SR)*100;
      // -- left: gauges --
      T(x,'Akustisk støy',60,34,{size:15,col:C.ink,weight:'bold'});
      barGauge(x,60,44,380,18,(dB-70)/(132-70), dB>120?C.red:dB>99?C.amber:C.green,
        [{v:85,lab:'85',col:'#777'},{v:99,lab:'99 – hørselvern',col:C.amber},{v:120,lab:'120',col:C.red}],70,132);
      T(x,dB.toFixed(0)+' dB(A)',60,92,{size:16,col:dB>99?C.red:C.ink,weight:'bold'});
      T(x, dB>99?'Hørselvern PÅKREVD':'under vernegrense',175,92,{size:12.5,col:dB>99?C.red:C.mut,weight:'bold'});

      T(x,'Perifer nervestimulering (PNS)',60,148,{size:15,col:C.ink,weight:'bold'});
      barGauge(x,60,158,380,18,pr/170, pr>130?C.red:pr>100?C.amber:C.green,
        [{v:100,lab:'terskel',col:C.amber},{v:130,lab:'grense',col:C.red}],0,170);
      T(x,pr.toFixed(0)+' %',60,206,{size:16,col:pr>100?C.red:C.ink,weight:'bold'});
      T(x, pr>130?'ubehagelig — over grensen':pr>100?'prikking / rykninger':'komfortabelt',
        120,206,{size:12.5,col:pr>100?C.red:C.mut,weight:'bold'});
      T(x,'Hjertestimulering: terskel ≈ 20× høyere → nås ikke',60,232,{size:12,col:C.green,weight:'bold'});
      T(x,'Nervestimulering ∝ dB/dt (endringstakt) — derfor grense på slew rate (~200 T/m/s)',
        60,H-14,{size:12.5,col:C.mut});

      // -- right: coil + waveform --
      const cx=690, cy=110, jitter=(dB-90)/40*6;
      const jx=Math.sin(this.ph*6)*jitter;
      x.strokeStyle=C.purple; x.lineWidth=6; rr(x,cx-70+jx,cy-40,140,80,14); x.stroke();
      T(x,'gradientspole',cx,cy-52,{size:12,col:C.purple,align:'center',weight:'bold'});
      // Lorentz force arrows (alternating)
      const dir=Math.sin(this.ph*6)>0?1:-1;
      [-1,1].forEach(s=>{ const ax=cx+s*50+jx, ay1=cy - dir*s*26;
        L(x,ax,cy,ax,ay1,C.red,2.5); const by=ay1+(cy>ay1?6:-6);
        x.fillStyle=C.red; x.beginPath(); x.moveTo(ax,ay1); x.lineTo(ax-5,by); x.lineTo(ax+5,by); x.closePath(); x.fill(); });
      T(x,'F = B·I·L',cx,cy+56,{size:12,col:C.red,align:'center',weight:'bold'});
      // acoustic waveform strip
      const wy=230, wA=6+(dB-85)/47*26;
      T(x,'lydtrykk',cx-70,wy-30,{size:12,col:C.mut});
      x.strokeStyle=dB>99?C.red:C.blue; x.lineWidth=2; x.beginPath();
      for(let i=0;i<=200;i++){ const px=cx-80+i*0.8; const y=wy - wA*Math.sin(i*0.35 - this.ph*6);
        i?x.lineTo(px,y):x.moveTo(px,y); } x.stroke();
      // tingling indicator
      if(pr>100){ const fl=(Math.sin(this.ph*10)+1)/2; x.globalAlpha=0.5+fl*0.5;
        T(x,'⚡ prikking i huden',cx,H-40,{size:14,col:C.red,align:'center',weight:'bold'}); x.globalAlpha=1; } }
  };

  // ============================================================
  // 4. RANDFELT + ACR-SONER  (static + draggable)
  // ============================================================
  M.fringe={ready:false,animated:false,cv:null,x:null,W:960,H:450,mx:250,my:120,
    // labeled contour rings: [pixelRadius, gauss]
    rings:[[70,1000],[110,300],[150,100],[205,30],[270,10],[335,5],[390,3]],
    cx:640,cy:225,
    init(root){ this.cv=root.querySelector('#cv-fringe'); this.x=fit(this.cv,this.W,this.H);
      const set=(e)=>{ const r=this.cv.getBoundingClientRect(); const sx=this.W/r.width, sy=this.H/r.height;
        this.mx=clamp((e.clientX-r.left)*sx,10,this.W-10); this.my=clamp((e.clientY-r.top)*sy,10,320); this.draw(); };
      let down=false;
      this.cv.addEventListener('pointerdown',e=>{ down=true; set(e); this.cv.setPointerCapture(e.pointerId); });
      this.cv.addEventListener('pointermove',e=>{ if(down) set(e); });
      this.cv.addEventListener('pointerup',()=>{ down=false; });
      this.draw(); },
    fieldAt(rpx){ const R=this.rings; if(rpx<=R[0][0]) return 1500;
      for(let i=0;i<R.length-1;i++){ if(rpx<=R[i+1][0]){ const t=(rpx-R[i][0])/(R[i+1][0]-R[i][0]);
        return Math.exp(Math.log(R[i][1])*(1-t)+Math.log(R[i+1][1])*t); } } return Math.max(0.3,R[R.length-1][1]*Math.pow(R[R.length-1][0]/rpx,3)); },
    zoneOf(rpx){ if(rpx<75) return {n:'IV',c:C.red,lab:'Sone IV — magnetrom'};
      if(rpx<335) return {n:'III',c:C.orange,lab:'Sone III — kontrollert'};
      if(rpx<400) return {n:'II',c:C.amber,lab:'Sone II — screening'};
      return {n:'I',c:C.green,lab:'Sone I — offentlig'}; },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H);
      const cx=this.cx,cy=this.cy;
      // zone bands (outer -> inner)
      const zb=[[400,'rgba(16,185,129,0.10)'],[335,'rgba(217,154,16,0.12)'],[75,'rgba(181,74,22,0.12)'],[0,'rgba(192,57,43,0.16)']];
      // draw as filled circles largest first
      [[420,'rgba(16,185,129,0.10)'],[400,'rgba(217,154,16,0.13)'],[335,'rgba(181,74,22,0.10)'],[75,'rgba(192,57,43,0.18)']]
        .forEach(z=>{ x.fillStyle=z[1]; x.beginPath(); x.arc(cx,cy,z[0],0,7); x.fill(); });
      // zone labels
      T(x,'Sone I — offentlig',cx-405,cy-150,{size:13,col:C.green,weight:'bold'});
      T(x,'II',cx-355,cy,{size:14,col:C.amber,weight:'bold'});
      T(x,'III — kontrollert adgang',cx-300,cy-95,{size:13,col:C.orange,weight:'bold'});
      // contour rings
      this.rings.forEach(rg=>{ const is5=rg[1]===5;
        x.strokeStyle=is5?C.red:'rgba(47,95,168,0.5)'; x.lineWidth=is5?2.4:1; x.setLineDash(is5?[]:[4,4]);
        x.beginPath(); x.arc(cx,cy,rg[0],0,7); x.stroke(); x.setLineDash([]);
        T(x,rg[1]+' G',cx,cy-rg[0]+14,{size:11,col:is5?C.red:'#8aa0c8',align:'center',weight:is5?'bold':'normal'}); });
      T(x,'5 gauss (0,5 mT) — grense for adgangskontroll / pacemaker',cx,cy+410,{size:12.5,col:C.red,align:'center',weight:'bold'});
      // magnet
      x.fillStyle='#dfe3e8'; rr(x,cx-46,cy-34,92,68,10); x.fill(); x.strokeStyle='#c3c8cf'; rr(x,cx-46,cy-34,92,68,10); x.stroke();
      x.fillStyle='#11151c'; x.beginPath(); x.ellipse(cx,cy,14,26,0,0,7); x.fill();
      T(x,'MR',cx,cy-40,{size:12,col:C.mut,align:'center',weight:'bold'});
      // marker
      const rpx=Math.hypot(this.mx-cx,this.my-cy); const fld=this.fieldAt(rpx); const zone=this.zoneOf(rpx);
      x.fillStyle=C.ink; x.beginPath(); x.arc(this.mx,this.my,7,0,7); x.fill();
      x.fillStyle='#fff'; x.beginPath(); x.arc(this.mx,this.my,2.5,0,7); x.fill();
      L(x,cx,cy,this.mx,this.my,'rgba(31,36,48,0.35)',1.2,[3,3]);
      // readout box
      const rx=40,ry=350; x.fillStyle='#fff'; x.strokeStyle=zone.c; x.lineWidth=2; rr(x,rx,ry,880,84,12); x.fill(); rr(x,rx,ry,880,84,12); x.stroke();
      T(x,'Dra markøren i rommet:',rx+18,ry+26,{size:13,col:C.mut});
      T(x,zone.lab,rx+18,ry+54,{size:17,col:zone.c,weight:'bold'});
      const mT=fld/10; T(x,'Felt ≈ '+(mT>=1?mT.toFixed(mT>=10?0:1)+' mT':(fld).toFixed(0)+' G'),rx+330,ry+40,{size:16,col:C.ink,weight:'bold'});
      let warn = fld>=5 ? (rpx<75?'PROSJEKTILFARE — ingen ferromagnetiske gjenstander!':'Implantat/pacemaker: risiko forbi 5 gauss')
        : zone.n==='II' ? 'Her screenes pasienten før videre adgang' : 'Trygt område — ingen spesiell fare';
      T(x,'⚠ '+warn,rx+560,ry+40,{size:13.5,col:fld>=5?C.red:zone.c,weight:'bold'});
      T(x,'(skjematisk kart — aktivt skjermede magneter har mindre randfelt)',rx+18,ry+74,{size:11.5,col:C.mut}); }
  };

  // ---- bootstrap ----
  window.runViz=function(name){ const m=M[name]; if(!m){ console.error('unknown viz',name); return; }
    try{ m.init(document); m.ready=true; }catch(e){ console.error(e); }
    if(m.animated && m.tick){ (function loop(ts){ m.tick((ts||0)/1000); requestAnimationFrame(loop); })(); }
    window.addEventListener('resize',function(){ if(!m.cv)return; m.x=fit(m.cv,m.W,m.H); if(!m.animated && m.draw) m.draw(); }); };
})();
