# Conversion report

Source: `MRI_maskin.odp`
Slides: **26**  ·  images extracted: **60**
Image payload: 31.6 MB → **6.0 MB**

## What needs your attention

- slide 2: 7 vector shape(s) dropped
- slide 4: no title placeholder in the original; promoted the top text box to the heading — check it reads sensibly

## Always worth checking

- **Wrapped lines**: Impress paragraphs that were one sentence split across lines have been rejoined heuristically. Skim for any that were joined wrongly (or missed).
- **Bullets vs prose**: a text box with 2+ paragraphs became an incremental list. Where that was really prose, delete the `::: {.incremental}` wrapper.
- **Layout**: one image beside one text box became two columns on the original side. Everything else stacks vertically — re-arrange freely.
- **Vector shapes** (arrows, callouts) are not represented in the output; search the deck for `TODO`.
- **Speaker notes** were preserved. Press `S` while presenting.
