/* MR-spektroskopi — interaktive animasjoner for Quarto reveal.js (iframe).
   Spektra modelleres analytisk (Lorentz-linjer på ppm-akse). FID→FFT og lactat-J
   verifisert numerisk før innbygging. */
(function(){
  "use strict";
  const FT="'DejaVu Sans', Verdana, sans-serif";
  const C={blue:'#2F5FA8',red:'#C0392B',purple:'#5d3a8e',orange:'#b54a16',green:'#10b981',
           amber:'#d99a10',ink:'#1f2430',mut:'#9aa2ad',line:'#e3e6ea'};
  const clamp=(v,a,b)=>v<a?a:(v>b?b:v), TAU=Math.PI*2;
  function fit(cv,w,h){ const dpr=Math.max(1,Math.min(2.5,window.devicePixelRatio||1));
    cv.width=w*dpr; cv.height=h*dpr; cv.style.aspectRatio=w+'/'+h; const x=cv.getContext('2d'); x.setTransform(dpr,0,0,dpr,0,0); return x; }
  function T(x,s,px,py,o){ o=o||{}; x.globalAlpha=o.alpha==null?1:o.alpha; x.fillStyle=o.col||C.ink;
    x.font=(o.weight||'normal')+' '+(o.size||14)+'px '+FT; x.textAlign=o.align||'left'; x.textBaseline=o.base||'alphabetic'; x.fillText(s,px,py); x.globalAlpha=1; }
  function L(x,a,b,c,d,col,w,dash){ x.strokeStyle=col; x.lineWidth=w||1; x.setLineDash(dash||[]); x.beginPath(); x.moveTo(a,b); x.lineTo(c,d); x.stroke(); x.setLineDash([]); }
  function rr(x,px,py,w,h,r){ x.beginPath(); x.moveTo(px+r,py); x.arcTo(px+w,py,px+w,py+h,r); x.arcTo(px+w,py+h,px,py+h,r); x.arcTo(px,py+h,px,py,r); x.arcTo(px,py,px+w,py,r); x.closePath(); }
  function wrapText(x,s,px,py,maxw,lh,o){ const words=s.split(' '); let line='',yy=py; x.font=(o.weight||'normal')+' '+(o.size||13)+'px '+FT;
    for(const w of words){ const t=line?line+' '+w:w; if(x.measureText(t).width>maxw && line){ T(x,line,px,yy,o); line=w; yy+=lh; } else line=t; } if(line) T(x,line,px,yy,o); return yy; }
  // FFT (verified)
  function fft(re,im,inv){ const n=re.length;
    for(let i=1,j=0;i<n;i++){ let bit=n>>1; for(;j&bit;bit>>=1) j^=bit; j^=bit; if(i<j){let t=re[i];re[i]=re[j];re[j]=t;t=im[i];im[i]=im[j];im[j]=t;} }
    for(let len=2;len<=n;len<<=1){ const a=(inv?2:-2)*Math.PI/len,wr=Math.cos(a),wi=Math.sin(a);
      for(let i=0;i<n;i+=len){ let cr=1,ci=0; for(let k=0;k<len/2;k++){ const p=i+k,q=i+k+len/2;
        const vr=re[q]*cr-im[q]*ci,vi=re[q]*ci+im[q]*cr; re[q]=re[p]-vr;im[q]=im[p]-vi;re[p]+=vr;im[p]+=vi;
        const ncr=cr*wr-ci*wi;ci=cr*wi+ci*wr;cr=ncr; } } } if(inv){for(let i=0;i<n;i++){re[i]/=n;im[i]/=n;}} }

  // metabolite library: ppm, linewidth, optional doublet split (ppm), colour
  const MET={
    Lip:{ppm:1.30,w:0.13,c:C.orange}, AA:{ppm:0.90,w:0.08,c:C.orange},
    Lac:{ppm:1.33,w:0.030,dbl:0.066,c:C.red}, Ala:{ppm:1.47,w:0.030,dbl:0.066,c:C.amber},
    Ace:{ppm:1.92,w:0.045,c:C.amber}, NAA:{ppm:2.01,w:0.050,c:C.blue},
    Glx:{ppm:2.35,w:0.11,c:C.green}, Succ:{ppm:2.40,w:0.045,c:C.amber},
    Cit:{ppm:2.62,w:0.05,dbl:0.10,c:C.purple}, Cr:{ppm:3.03,w:0.045,c:C.purple},
    Cho:{ppm:3.22,w:0.045,c:C.red}, Tau:{ppm:3.42,w:0.05,c:C.green},
    mI:{ppm:3.56,w:0.055,c:C.green}, Cr2:{ppm:3.93,w:0.045,c:C.purple}
  };
  const ppmL=4.35, ppmR=0.15;
  function lor(x,x0,w){ return w*w/((x-x0)*(x-x0)+w*w); }
  // peaks: [{m:'NAA', a:amp}] -> value at ppm
  function specVal(ppm, peaks){ let v=0;
    for(const p of peaks){ const M=MET[p.m]; if(!M)continue;
      if(M.dbl){ v+=p.a*0.5*lor(ppm,M.ppm-M.dbl/2,M.w)+p.a*0.5*lor(ppm,M.ppm+M.dbl/2,M.w); }
      else v+=p.a*lor(ppm,M.ppm,M.w); }
    return v; }
  function drawSpectrum(x, X,Y,W,H, peaks, opt){ opt=opt||{};
    // axis
    L(x,X,Y+H,X+W,Y+H,'#c3c8cf',1.2);
    for(let p=4;p>=1;p--){ const px=X+(ppmL-p)/(ppmL-ppmR)*W; L(x,px,Y+H,px,Y+H+4,'#c3c8cf',1); T(x,p+'',px,Y+H+18,{size:11,col:C.mut,align:'center'}); }
    T(x,'ppm',X+W,Y+H+18,{size:11,col:C.mut,align:'end'}); T(x,opt.title||'',X+6,Y+14,{size:13.5,col:C.ink,weight:'bold'});
    // scale: find max
    let mx=0.001; for(let i=0;i<=W;i++){ const ppm=ppmL-(i/W)*(ppmL-ppmR); const v=Math.abs(specVal(ppm,peaks)); if(v>mx)mx=v; }
    const sc=(H-24)/ (opt.fixedMax||mx);
    // curve
    x.strokeStyle=opt.col||C.blue; x.lineWidth=2; x.beginPath();
    for(let i=0;i<=W;i++){ const ppm=ppmL-(i/W)*(ppmL-ppmR); const v=specVal(ppm,peaks); const px=X+i, py=Y+H-12-v*sc; i?x.lineTo(px,py):x.moveTo(px,py); } x.stroke();
    // labels at peaks
    if(opt.labels!==false) for(const p of peaks){ if(Math.abs(p.a)<0.12)continue; const M=MET[p.m];
      const px=X+(ppmL-M.ppm)/(ppmL-ppmR)*W; const v=specVal(M.ppm,peaks); const py=Y+H-12-v*sc;
      T(x, opt.names&&opt.names[p.m]||p.m, px, py-8, {size:11.5,col:M.c,weight:'bold',align:'center'}); }
  }

  // disease/tissue profiles (relative amplitudes)
  const PROF={
    normal:{t:'Normal hjerne',pk:[{m:'NAA',a:1.0},{m:'Cr',a:0.62},{m:'Cho',a:0.5},{m:'mI',a:0.42},{m:'Glx',a:0.4},{m:'Cr2',a:0.28}],
      note:'NAA høyest (nevroner), så Cr og Cho. NAA/Cr ≈ 1,5–2, Cho/Cr ≈ 0,8.'},
    gbm:{t:'Høygradig svulst (GBM)',pk:[{m:'Cho',a:1.0},{m:'Cr',a:0.4},{m:'NAA',a:0.28},{m:'Lac',a:0.5},{m:'Lip',a:0.55},{m:'mI',a:0.3}],
      note:'Cho↑↑ (membranomsetning), NAA↓↓ (nevrontap), Lac + lipid (nekrose). Cho/NAA høy.'},
    lowgrade:{t:'Lavgradig gliom',pk:[{m:'Cho',a:0.72},{m:'Cr',a:0.5},{m:'NAA',a:0.5},{m:'mI',a:0.8}],
      note:'Cho moderat↑, NAA↓, mI↑ — vanligvis uten lipid/laktat.'},
    stroke:{t:'Akutt hjerneslag',pk:[{m:'Lac',a:1.0},{m:'NAA',a:0.5},{m:'Cr',a:0.5},{m:'Cho',a:0.5}],
      note:'Laktat↑↑ (anaerob metabolisme), NAA↓ over tid.'},
    abscess:{t:'Abscess (pyogen)',pk:[{m:'AA',a:0.9},{m:'Ace',a:0.85},{m:'Succ',a:0.6},{m:'Lac',a:0.7},{m:'Lip',a:0.35}],
      note:'Aminosyrer (0,9), acetat (1,9), succinat (2,4), laktat — INGEN NAA/Cho/Cr. Skiller fra nekrotisk svulst.'},
    alzheimer:{t:'Alzheimer / demens',pk:[{m:'NAA',a:0.7},{m:'Cr',a:0.6},{m:'Cho',a:0.55},{m:'mI',a:0.95}],
      note:'mI↑ (glia), NAA↓. mI/Cr forhøyet er tidlig markør.'},
    hepatic:{t:'Hepatisk encefalopati',pk:[{m:'Glx',a:1.0},{m:'NAA',a:0.85},{m:'Cr',a:0.6},{m:'Cho',a:0.32},{m:'mI',a:0.14}],
      note:'Glx↑↑ (glutamin), mI↓ og Cho↓ — klassisk trio.'},
    ms:{t:'MS-lesjon (akutt)',pk:[{m:'Cho',a:0.85},{m:'Cr',a:0.6},{m:'NAA',a:0.6},{m:'mI',a:0.6},{m:'Lac',a:0.3}],
      note:'Akutt: Cho↑ + laktat; kronisk: NAA↓. mI↑ ved gliose.'},
    prostate:{t:'Prostatakreft',pk:[{m:'Cho',a:0.9},{m:'Cr',a:0.45},{m:'Cit',a:0.3}],
      note:'Citrat↓ og cholin↑ → (Cho+Cr)/Citrat-forhold↑ er nøkkelmarkør.'}
  };
  const fullNames={NAA:'NAA',Cr:'Cr',Cho:'Cho',mI:'mI',Glx:'Glx',Lac:'Lac',Lip:'Lipid',AA:'AS',Ace:'Ace',Succ:'Suc',Cit:'Cit',Cr2:'Cr'};

  const M={};

  // ============================================================
  // 1. FID -> FFT -> SPECTRUM  (+ water suppression)
  // ============================================================
  M.fid={ready:false,animated:true,cv:null,x:null,W:960,H:460,water:false,t:0,last:null,
    init(root){ this.cv=root.querySelector('#cv-fid'); this.x=fit(this.cv,this.W,this.H);
      root.querySelectorAll('[data-water]').forEach(b=>b.onclick=()=>{ this.water=b.dataset.water==='1';
        root.querySelectorAll('[data-water]').forEach(q=>q.classList.toggle('on',q===b)); this.build(); });
      this.build(); },
    build(){ const N=512; this.N=N; const dt=1/2000; this.dt=dt; const T2=0.28;
      // tones (Hz) mapped from ppm-ish; include big water if enabled
      const tones=[{f:90,a:1.0},{f:150,a:0.6},{f:175,a:0.55},{f:250,a:0.4}];
      if(this.water) tones.push({f:20,a:8.0});
      const re=new Float64Array(N),im=new Float64Array(N); this.fidR=new Float64Array(N);
      for(let t=0;t<N;t++){ let sr=0,si=0; const tt=t*dt; const env=Math.exp(-tt/T2);
        for(const to of tones){ sr+=to.a*Math.cos(TAU*to.f*tt)*env; si+=to.a*Math.sin(TAU*to.f*tt)*env; } re[t]=sr; im[t]=si; this.fidR[t]=sr; }
      fft(re,im,false); this.mag=new Float64Array(N); for(let k=0;k<N;k++) this.mag[k]=Math.hypot(re[k],im[k]); this.t=0; },
    tick(t){ if(this.last==null)this.last=t; const dt=Math.min(0.05,t-this.last); this.last=t; this.t+=dt*0.4; if(this.t>1.4)this.t=0; this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H);
      T(x,'Fra FID (tid) til spektrum (frekvens)',W/2,28,{size:16,col:C.ink,weight:'bold',align:'center'});
      // FID left
      const fx=50,fy=80,fw=380,fh=150; L(x,fx,fy+fh/2,fx+fw,fy+fh/2,'#e3e6ea',1);
      const reveal=clamp(this.t,0,1); const nShow=Math.floor(reveal*this.N);
      x.strokeStyle=C.green; x.lineWidth=1.8; x.beginPath();
      let mxF=0; for(let t=0;t<this.N;t++) mxF=Math.max(mxF,Math.abs(this.fidR[t]));
      for(let t=0;t<nShow;t++){ const px=fx+t/this.N*fw, py=fy+fh/2-this.fidR[t]/mxF*(fh/2-6); t?x.lineTo(px,py):x.moveTo(px,py); } x.stroke();
      T(x,'FID — henfallende signal (sum av frekvenser)',fx,fy-8,{size:12.5,col:C.green,weight:'bold'});
      T(x,'tid →',fx+fw,fy+fh+18,{size:11,col:C.mut,align:'end'});
      // arrow
      T(x,'Fourier →',W/2,fy+fh/2,{size:14,col:C.ink,weight:'bold',align:'center'});
      // spectrum right (from FFT), reversed so low freq right
      const sx=540,sy=80,sw=380,sh=150; L(x,sx,sy+sh,sx+sw,sy+sh,'#c3c8cf',1);
      let mxS=0; for(let k=1;k<this.N/2;k++) mxS=Math.max(mxS,this.mag[k]);
      x.strokeStyle=C.blue; x.lineWidth=2; x.beginPath();
      for(let i=0;i<=sw;i++){ const k=Math.round((1-i/sw)*(this.N/2-1))+1; const px=sx+i, py=sy+sh-this.mag[k]/mxS*(sh-8); i?x.lineTo(px,py):x.moveTo(px,py); } x.stroke();
      T(x,'Spektrum — topper = metabolitter',sx,sy-8,{size:12.5,col:C.blue,weight:'bold'});
      T(x,'← frekvens (ppm)',sx+sw,sy+sh+18,{size:11,col:C.mut,align:'end'});
      // caption
      const cap = this.water
        ? 'MED vann: vanntoppen (~4,7 ppm) er tusenvis av ganger sterkere og drukner metabolittene helt.'
        : 'Hver metabolitt svinger på sin egen frekvens (kjemisk skift). Fourier-transformasjonen skiller dem til separate topper.';
      wrapText(x,cap,50,H-52,W-100,18,{size:13.5,col:C.ink});
      wrapText(x,'Derfor MÅ vannsignalet undertrykkes (CHESS) før metabolittene kan måles.',50,H-24,W-100,18,{size:13,col:C.blue,weight:'bold'}); }
  };

  // ============================================================
  // 2. METABOLITE SPECTRUM EXPLORER
  // ============================================================
  M.spectrum={ready:false,animated:false,cv:null,x:null,W:960,H:470,
    amps:{NAA:1.0,Cr:0.62,Cho:0.5,mI:0.42,Glx:0.4,Lac:0.0},
    init(root){ this.cv=root.querySelector('#cv-sp'); this.x=fit(this.cv,this.W,this.H);
      const ids=['NAA','Cr','Cho','mI','Glx','Lac'];
      ids.forEach(id=>{ const el=root.querySelector('#sp-'+id); if(el){ el.oninput=()=>{ this.amps[id]=+el.value/100; const o=root.querySelector('#sp-'+id+'o'); if(o)o.textContent=(+el.value)+' %'; this.draw(); }; const o=root.querySelector('#sp-'+id+'o'); if(o)o.textContent=Math.round(this.amps[id]*100)+' %'; } });
      this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H);
      const pk=[{m:'NAA',a:this.amps.NAA},{m:'Cr',a:this.amps.Cr},{m:'Cho',a:this.amps.Cho},{m:'mI',a:this.amps.mI},{m:'Glx',a:this.amps.Glx},{m:'Lac',a:this.amps.Lac},{m:'Cr2',a:this.amps.Cr*0.45}];
      drawSpectrum(x,40,60,880,300,pk,{title:'¹H-MRS-spektrum (hjerne, kort TE)',names:fullNames,fixedMax:1.05});
      // reference of ppm positions
      const refs=[['NAA',2.01,'nevron-markør'],['Glx',2.35,'glutamat/glutamin'],['Cr',3.03,'energi (kreatin)'],['Cho',3.22,'membranomsetning'],['mI',3.56,'glia/osmolytt'],['Lac',1.33,'anaerob (doublet)']];
      let yy=H-92; T(x,'Metabolitter og hva de betyr:',40,yy,{size:13.5,col:C.ink,weight:'bold'}); yy+=22;
      refs.forEach((r,i)=>{ const col=i%2, px=40+col*460, py=yy+Math.floor(i/2)*22;
        T(x,r[0]+' ('+r[1].toFixed(2)+' ppm): '+r[2],px,py,{size:12.5,col:MET[r[0]].c,weight:'bold'}); });
      T(x,'Dra glidebryterne — se hvordan konsentrasjon endrer toppene. Merk: ppm-aksen går HØY→LAV (vann 4,7 til venstre).',40,H-8,{size:12,col:C.mut}); }
  };

  // ============================================================
  // 3. DISEASE PATTERNS
  // ============================================================
  M.disease={ready:false,animated:false,cv:null,x:null,W:960,H:470,cur:'gbm',
    init(root){ this.cv=root.querySelector('#cv-dis'); this.x=fit(this.cv,this.W,this.H);
      root.querySelectorAll('[data-dis]').forEach(b=>{ b.classList.toggle('on',b.dataset.dis===this.cur);
        b.onclick=()=>{ this.cur=b.dataset.dis; root.querySelectorAll('[data-dis]').forEach(q=>q.classList.toggle('on',q===b)); this.draw(); }; });
      this.draw(); },
    ratios(pk){ const g=m=>{ const f=pk.find(p=>p.m===m); return f?f.a:0; };
      return {naacr:(g('NAA')/(g('Cr')||1)).toFixed(2), chocr:(g('Cho')/(g('Cr')||1)).toFixed(2), chonaa:(g('Cho')/(g('NAA')||0.01)).toFixed(2)}; },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H);
      const P=PROF[this.cur]; const norm=PROF.normal;
      // normal reference (faint) + disease
      drawSpectrum(x,40,60,600,300,P.pk,{title:P.t,names:fullNames,fixedMax:1.05,col:C.blue});
      // faint normal overlay
      x.save(); x.globalAlpha=0.28; drawSpectrum(x,40,60,600,300,norm.pk,{title:'',names:{},labels:false,fixedMax:1.05,col:C.mut}); x.restore();
      T(x,'(grå = normal referanse)',300,H-96,{size:11,col:C.mut,align:'center'});
      // info panel
      const ix=680; T(x,'Mønster',ix,80,{size:16,col:C.ink,weight:'bold'});
      wrapText(x,P.note,ix,108,W-ix-30,19,{size:13,col:C.ink});
      const r=this.ratios(P.pk); const ry=H-140;
      T(x,'Nøkkelforhold:',ix,ry,{size:13,col:C.ink,weight:'bold'});
      T(x,'NAA/Cr = '+r.naacr,ix,ry+24,{size:13,col:C.blue,weight:'bold'});
      T(x,'Cho/Cr = '+r.chocr,ix,ry+46,{size:13,col:C.red,weight:'bold'});
      T(x,'Cho/NAA = '+r.chonaa,ix,ry+68,{size:13,col:C.purple,weight:'bold'});
      T(x,'Sammenlign toppene med den grå normale referansen.',40,H-8,{size:12,col:C.mut}); }
  };

  // ============================================================
  // 4. TE / LACTATE DOUBLET INVERSION
  // ============================================================
  M.teflip={ready:false,animated:false,cv:null,x:null,W:960,H:470,TE:35,J:7,
    init(root){ this.cv=root.querySelector('#cv-te'); this.x=fit(this.cv,this.W,this.H);
      this.sl=root.querySelector('#te-te'); this.slo=root.querySelector('#te-teo');
      this.sl.oninput=()=>{ this.TE=+this.sl.value; this.slo.textContent=this.TE+' ms'; this.draw(); }; this.slo.textContent=this.TE+' ms';
      this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H);
      const TE=this.TE; const T2s=Math.exp(-TE/300);           // singlets decay slowly
      const coupled=Math.exp(-TE/120);                          // Glx/mI dephase faster
      const lacF=Math.cos(Math.PI*this.J*TE/1000)*Math.exp(-TE/250); // doublet phase + decay
      const pk=[{m:'NAA',a:1.0*T2s},{m:'Cr',a:0.62*T2s},{m:'Cho',a:0.5*T2s},
                {m:'mI',a:0.42*coupled},{m:'Glx',a:0.45*coupled},{m:'Lac',a:0.7*lacF},{m:'Cr2',a:0.28*T2s}];
      drawSpectrum(x,40,60,880,300,pk,{title:'Spektrum ved TE = '+TE+' ms',names:fullNames,fixedMax:1.05});
      // lactate state
      const st = lacF>0.15?'OPP (opp)': lacF<-0.15?'NED (invertert)':'≈ null';
      const col = lacF>0.15?C.green: lacF<-0.15?C.red:C.mut;
      T(x,'Laktat-doublett: '+st+'   (faktor cos(πJ·TE) = '+ (Math.cos(Math.PI*this.J*TE/1000)).toFixed(2)+')',40,H-92,{size:14,col,weight:'bold'});
      wrapText(x,'Laktat er J-koblet (J≈7 Hz): opp ved kort TE, ≈null ved ~68 ms, INVERTERT ved TE 135–144 ms, opp igjen ved ~272 ms.',40,H-64,W-80,18,{size:13,col:C.ink});
      wrapText(x,'Kort TE (30–35 ms): flere metabolitter (mI, Glx, lipider). Lang TE (135–288 ms): renere baseline, laktat-inversjon som «signatur».',40,H-36,W-80,18,{size:13,col:C.blue,weight:'bold'});
      // clinical TE markers
      [['35',35],['68',68],['135',135],['144',144],['270',270]].forEach(m=>{ const px=40+ (m[1]/300)*300; }); }
  };

  // ============================================================
  // 5. SINGLE VOXEL vs MRSI  (localization + metabolite map)
  // ============================================================
  M.mrsi={ready:false,animated:false,cv:null,x:null,W:960,H:470,mode:'single',vox:[2,2],
    init(root){ this.cv=root.querySelector('#cv-mr'); this.x=fit(this.cv,this.W,this.H);
      root.querySelectorAll('[data-mmode]').forEach(b=>{ b.classList.toggle('on',b.dataset.mmode===this.mode);
        b.onclick=()=>{ this.mode=b.dataset.mmode; root.querySelectorAll('[data-mmode]').forEach(q=>q.classList.toggle('on',q===b)); this.draw(); }; });
      this.cv.addEventListener('pointerdown',e=>{ const r=this.cv.getBoundingClientRect(); const gx=this.gx0,gy=this.gy0,gs=this.gs;
        const cx=(e.clientX-r.left)*(this.W/r.width), cy=(e.clientY-r.top)*(this.H/r.height);
        if(cx>gx&&cx<gx+gs*4&&cy>gy&&cy<gy+gs*4){ this.vox=[Math.floor((cx-gx)/gs),Math.floor((cy-gy)/gs)]; this.draw(); } });
      this.draw(); },
    tumorAt(i,j){ return (i>=2&&i<=3&&j>=1&&j<=2); },  // tumour region in grid
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H);
      const gx0=60,gy0=70,gs=76; this.gx0=gx0; this.gy0=gy0; this.gs=gs;
      T(x,'Lokalisering: enkelt voksel vs. MRSI-kart',W/2,30,{size:16,col:C.ink,weight:'bold',align:'center'});
      // brain
      x.fillStyle='#eceff3'; x.beginPath(); x.ellipse(gx0+gs*2,gy0+gs*2,gs*2.05,gs*2.15,0,0,TAU); x.fill();
      // tumour blob
      x.fillStyle='rgba(192,57,43,0.35)'; x.beginPath(); x.ellipse(gx0+gs*3,gy0+gs*1.5,gs*0.9,gs*0.8,0,0,TAU); x.fill();
      T(x,'svulst',gx0+gs*3,gy0+gs*1.5,{size:11,col:C.red,align:'center',weight:'bold'});
      if(this.mode==='single'){
        // single voxel box (draggable)
        const vx=gx0+this.vox[0]*gs, vy=gy0+this.vox[1]*gs; x.strokeStyle=C.blue; x.lineWidth=3; x.strokeRect(vx,vy,gs,gs);
        T(x,'enkelt voksel (klikk for å flytte)',gx0+gs*2,gy0+gs*4+26,{size:12.5,col:C.blue,align:'center',weight:'bold'});
        // spectrum for that voxel
        const inT=this.tumorAt(this.vox[0],this.vox[1]);
        const pk= inT? PROF.gbm.pk : PROF.normal.pk;
        drawSpectrum(x,560,80,360,240,pk,{title:inT?'Voksel: svulst-mønster':'Voksel: normal',names:fullNames,fixedMax:1.05,col:inT?C.red:C.blue});
        T(x, inT?'Cho↑, NAA↓ — malignt':'Normal metabolittprofil', 560, 350, {size:12.5,col:inT?C.red:C.green,weight:'bold'});
      } else {
        // MRSI grid + Cho/NAA map
        for(let i=0;i<4;i++)for(let j=0;j<4;j++){ x.strokeStyle='#c3c8cf'; x.lineWidth=1; x.strokeRect(gx0+i*gs,gy0+j*gs,gs,gs);
          const inT=this.tumorAt(i,j); const val=inT?1:0.2; const r=Math.round(255- val*40), g=Math.round(255-val*180), b=Math.round(255-val*180);
          x.fillStyle='rgba('+r+','+g+','+b+',0.55)'; x.fillRect(gx0+i*gs+1,gy0+j*gs+1,gs-2,gs-2);
          // mini spectrum
          const pk= inT?PROF.gbm.pk:PROF.normal.pk; x.strokeStyle=inT?C.red:C.blue; x.lineWidth=1.2; x.beginPath();
          let mxv=0.001; for(let s=0;s<=gs-10;s+=3){ const ppm=ppmL-(s/(gs-10))*(ppmL-ppmR); mxv=Math.max(mxv,Math.abs(specVal(ppm,pk))); }
          for(let s=0;s<=gs-10;s+=3){ const ppm=ppmL-(s/(gs-10))*(ppmL-ppmR); const v=specVal(ppm,pk); const px=gx0+i*gs+5+s, py=gy0+j*gs+gs-8-v/mxv*(gs-20); s?x.lineTo(px,py):x.moveTo(px,py); } x.stroke(); }
        T(x,'MRSI: rutenett av spektra → metabolittkart',gx0+gs*2,gy0+gs*4+26,{size:12.5,col:C.ink,align:'center',weight:'bold'});
        // Cho map legend
        const lx=600; T(x,'Cholin-kart',lx,90,{size:14,col:C.ink,weight:'bold'});
        for(let j=0;j<4;j++)for(let i=0;i<4;i++){ const inT=this.tumorAt(i,j); const g=inT?60:230; x.fillStyle='rgb(255,'+g+','+g+')'; x.fillRect(lx+i*40,110+j*40,38,38); }
        T(x,'rødt = høy Cholin (svulst)',lx,110+4*40+18,{size:12.5,col:C.red,weight:'bold'});
        wrapText(x,'MRSI dekker mange voksler samtidig → man kan tegne kart over hver metabolitt og finne det mest maligne området.',lx,110+4*40+44,W-lx-30,18,{size:12.5,col:C.ink});
      }
      wrapText(x,'Enkelt voksel: ett rent spektrum, høy kvalitet. MRSI: romlig dekning, men lengre tid og mer artefakter.',40,H-14,W-80,18,{size:12,col:C.mut}); }
  };

  window.runViz=function(name){ const m=M[name]; if(!m){console.error('unknown viz',name);return;}
    try{ m.init(document); m.ready=true; }catch(e){ console.error(e); }
    if(m.animated && m.tick){ (function loop(ts){ m.tick((ts||0)/1000); requestAnimationFrame(loop); })(); }
    window.addEventListener('resize',function(){ if(!m.cv)return; m.x=fit(m.cv,m.W,m.H); if(!m.animated && m.draw) m.draw(); }); };
  window.__spec={M,PROF,MET,specVal};
})();
