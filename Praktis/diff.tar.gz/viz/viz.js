/* Diffusjon-MRI — interaktive animasjoner for Quarto reveal.js (iframe).
   Én modul per side via runViz(navn). Fysikk verifisert numerisk før innbygging. */
(function(){
  "use strict";
  const FT="'DejaVu Sans', Verdana, sans-serif";
  const C={blue:'#2F5FA8',red:'#C0392B',purple:'#5d3a8e',orange:'#b54a16',green:'#10b981',
           amber:'#d99a10',ink:'#1f2430',mut:'#9aa2ad',line:'#e3e6ea'};
  const clamp=(v,a,b)=>v<a?a:(v>b?b:v), TAU=Math.PI*2;
  const gauss=()=>{ let u=0,v=0; while(u===0)u=Math.random(); while(v===0)v=Math.random(); return Math.sqrt(-2*Math.log(u))*Math.cos(TAU*v); };
  function fit(cv,w,h){ const dpr=Math.max(1,Math.min(2.5,window.devicePixelRatio||1));
    cv.width=w*dpr; cv.height=h*dpr; cv.style.aspectRatio=w+'/'+h; const x=cv.getContext('2d'); x.setTransform(dpr,0,0,dpr,0,0); return x; }
  function T(x,s,px,py,o){ o=o||{}; x.globalAlpha=o.alpha==null?1:o.alpha; x.fillStyle=o.col||C.ink;
    x.font=(o.weight||'normal')+' '+(o.size||14)+'px '+FT; x.textAlign=o.align||'left'; x.textBaseline=o.base||'alphabetic'; x.fillText(s,px,py); x.globalAlpha=1; }
  function L(x,a,b,c,d,col,w,dash){ x.strokeStyle=col; x.lineWidth=w||1; x.setLineDash(dash||[]); x.beginPath(); x.moveTo(a,b); x.lineTo(c,d); x.stroke(); x.setLineDash([]); }
  function rr(x,px,py,w,h,r){ x.beginPath(); x.moveTo(px+r,py); x.arcTo(px+w,py,px+w,py+h,r); x.arcTo(px+w,py+h,px,py+h,r); x.arcTo(px,py+h,px,py,r); x.arcTo(px,py,px+w,py,r); x.closePath(); }
  function wrapText(x,s,px,py,maxw,lh,o){ const words=s.split(' '); let line='',yy=py; x.font=(o.weight||'normal')+' '+(o.size||13)+'px '+FT;
    for(const w of words){ const t=line?line+' '+w:w; if(x.measureText(t).width>maxw && line){ T(x,line,px,yy,o); line=w; yy+=lh; } else line=t; } if(line) T(x,line,px,yy,o); return yy; }
  const M={};

  // ============================================================
  // 1. BROWNIAN MOTION  (free / restricted / anisotropic)
  // ============================================================
  M.brownian={ready:false,animated:true,cv:null,x:null,W:960,H:460,mode:'fri',speed:1,last:null,
    P:[],step:0,maxStep:220,msd:[],msdX:[],msdY:[],
    init(root){ this.cv=root.querySelector('#cv-bw'); this.x=fit(this.cv,this.W,this.H);
      root.querySelectorAll('[data-bmode]').forEach(b=>b.onclick=()=>{ this.mode=b.dataset.bmode;
        root.querySelectorAll('[data-bmode]').forEach(q=>q.classList.toggle('on',q===b)); this.reset(); });
      const sp=root.querySelector('#bw-sp'); if(sp){ sp.oninput=()=>{ this.speed=+sp.value; root.querySelector('#bw-spo').textContent=(+sp.value).toFixed(1)+'×'; }; root.querySelector('#bw-spo').textContent=this.speed.toFixed(1)+'×'; }
      this.reset(); },
    reset(){ this.P=[]; const cols=[C.blue,C.red,C.green,C.purple,C.orange];
      for(let i=0;i<40;i++) this.P.push({x:0,y:0,tr:[],c:cols[i%5]});
      this.step=0; this.msd=[]; this.msdX=[]; this.msdY=[]; },
    tick(t){ if(this.last==null)this.last=t; const dt=Math.min(0.05,t-this.last); this.last=t;
      const iters=Math.max(1,Math.round(this.speed*1.4));
      for(let it=0;it<iters && this.step<this.maxStep;it++){ this.step++;
        const sx=1.0, sy=(this.mode==='anisotrop')?0.35:1.0;
        for(const p of this.P){ let nx=p.x+gauss()*sx, ny=p.y+gauss()*sy;
          if(this.mode==='begrenset'){ const R=42; const r=Math.hypot(nx,ny); if(r>R){ nx*=R/r; ny*=R/r; } }
          if(this.mode==='anisotrop'){ if(Math.abs(ny)>16){ ny=Math.sign(ny)*(32-Math.abs(ny)); } } // channel walls in y
          p.x=nx; p.y=ny; p.tr.push([nx,ny]); if(p.tr.length>40)p.tr.shift(); }
        let m=0,mx=0,my=0; for(const p of this.P){ m+=p.x*p.x+p.y*p.y; mx+=p.x*p.x; my+=p.y*p.y; }
        this.msd.push(m/this.P.length); this.msdX.push(mx/this.P.length); this.msdY.push(my/this.P.length);
      }
      if(this.step>=this.maxStep){ if(!this.holdT)this.holdT=t; if(t-this.holdT>1.5){ this.holdT=null; this.reset(); } }
      this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H);
      const cx=250,cy=235,scale=2.2;
      // container / structure
      x.strokeStyle='#dfe3e8'; x.lineWidth=1.5;
      if(this.mode==='begrenset'){ x.beginPath(); x.arc(cx,cy,42*scale,0,TAU); x.stroke(); T(x,'cellevegg',cx,cy-42*scale-8,{size:12,col:C.mut,align:'center'}); }
      else if(this.mode==='anisotrop'){ x.strokeStyle='#dfe3e8'; x.strokeRect(cx-90*scale,cy-16*scale,180*scale,32*scale); T(x,'akson (kanal)',cx,cy-16*scale-8,{size:12,col:C.mut,align:'center'}); }
      else { x.strokeStyle='#eef1f4'; x.strokeRect(cx-95*scale,cy-90,190*scale,180); }
      // origin
      x.fillStyle='#c3c8cf'; x.beginPath(); x.arc(cx,cy,3,0,TAU); x.fill();
      // trajectories + particles
      for(const p of this.P){ x.strokeStyle=p.c; x.globalAlpha=0.35; x.lineWidth=1; x.beginPath();
        p.tr.forEach((q,i)=>{ const px=cx+q[0]*scale, py=cy+q[1]*scale; i?x.lineTo(px,py):x.moveTo(px,py); }); x.stroke(); x.globalAlpha=1;
        x.fillStyle=p.c; x.beginPath(); x.arc(cx+p.x*scale,cy+p.y*scale,2.6,0,TAU); x.fill(); }
      T(x,'Brownsk bevegelse',cx,34,{size:16,col:C.ink,weight:'bold',align:'center'});
      // MSD plot
      const gx0=560,gy0=60,gw=360,gh=250;
      x.strokeStyle='#c3c8cf'; L(x,gx0,gy0,gx0,gy0+gh,'#c3c8cf',1); L(x,gx0,gy0+gh,gx0+gw,gy0+gh,'#c3c8cf',1);
      T(x,'⟨r²⟩ (forskyvning²)',gx0-4,gy0-6,{size:12,col:C.mut,align:'end'}); T(x,'tid →',gx0+gw,gy0+gh+18,{size:11,col:C.mut,align:'end'});
      const ymax = this.mode==='begrenset'?3600 : this.mode==='anisotrop'?9000 : 12000;
      const plot=(arr,col)=>{ x.strokeStyle=col; x.lineWidth=2; x.beginPath();
        for(let i=0;i<arr.length;i++){ const px=gx0+i/this.maxStep*gw, py=gy0+gh-clamp(arr[i]/ymax,0,1)*gh; i?x.lineTo(px,py):x.moveTo(px,py); } x.stroke(); };
      if(this.mode==='anisotrop'){ plot(this.msdX,C.red); plot(this.msdY,C.blue);
        T(x,'langs (rask)',gx0+10,gy0+16,{size:12,col:C.red,weight:'bold'}); T(x,'tvers (treg)',gx0+10,gy0+34,{size:12,col:C.blue,weight:'bold'}); }
      else plot(this.msd,C.blue);
      // caption
      const cap={fri:'Fri diffusjon: ⟨r²⟩ vokser lineært i tid (Einstein: ⟨r²⟩ = 2·n·D·t). Ingen grenser.',
        begrenset:'Begrenset diffusjon: veggene stopper spredningen → ⟨r²⟩ flater ut → forteller oss cellestørrelsen.',
        anisotrop:'Anisotrop diffusjon: vann sprer seg langt LANGS aksonet, lite på TVERS → retningsavhengig (grunnlaget for DTI).'}[this.mode];
      wrapText(x,cap,40,H-38,W-80,18,{size:13.5,col:C.ink});
      T(x,'Einstein:  ⟨r²⟩ = 2·n·D·t   (n = antall dimensjoner)',40,H-14,{size:13,col:C.blue,weight:'bold'}); }
  };

  // ============================================================
  // 2. STEJSKAL-TANNER PGSE  (dephase / rephase; static vs diffusing)
  // ============================================================
  M.pgse={ready:false,animated:true,cv:null,x:null,W:960,H:470,bLevel:0.6,diffuse:true,last:null,t:0,
    init(root){ this.cv=root.querySelector('#cv-pg'); this.x=fit(this.cv,this.W,this.H);
      this.sl=root.querySelector('#pg-b'); this.slo=root.querySelector('#pg-bo');
      this.sl.oninput=()=>{ this.bLevel=+this.sl.value/100; this.slo.textContent=this.sl.value+' %'; this.rebuild(); }; this.slo.textContent=this.sl.value+' %'; this.bLevel=+this.sl.value/100;
      root.querySelectorAll('[data-diff]').forEach(b=>b.onclick=()=>{ this.diffuse=b.dataset.diff==='1';
        root.querySelectorAll('[data-diff]').forEach(q=>q.classList.toggle('on',q===b)); this.rebuild(); });
      this.rebuild(); },
    rebuild(){ this.spins=[]; const nn=18; for(let i=0;i<nn;i++){ const pos=(i/(nn-1)-0.5)*2; // -1..1 position
      const disp=this.diffuse? gauss()*0.5 : 0; this.spins.push({pos,disp,ph:0}); } this.t=0; },
    tick(t){ if(this.last==null)this.last=t; const dt=Math.min(0.05,t-this.last); this.last=t; this.t+=dt*0.28; if(this.t>1)this.t-=1; this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H);
      // timeline phases (fractions of t in [0,1]): 90 @0.05, G1 0.12-0.28, 180 @0.42, G2 0.5-0.66, echo 0.8
      const tx0=48,tx1=620, t2x=tt=>tx0+tt*(tx1-tx0); const rfY=90, gY=170, k=this.bLevel*Math.PI*2.2;
      T(x,'Stejskal–Tanner (PGSE) — diffusjonskoding',W/2,30,{size:16,col:C.ink,weight:'bold',align:'center'});
      // RF row
      L(x,tx0,rfY,tx1,rfY,'#d3d7dd',1); T(x,'RF',18,rfY-30,{size:12,col:C.mut,weight:'bold'});
      L(x,t2x(0.05),rfY,t2x(0.05),rfY-34,C.blue,3); T(x,'90°',t2x(0.05),rfY-40,{size:11,col:C.blue,weight:'bold',align:'center'});
      L(x,t2x(0.42),rfY,t2x(0.42),rfY-44,C.red,3); T(x,'180°',t2x(0.42),rfY-50,{size:11,col:C.red,weight:'bold',align:'center'});
      // gradient row
      L(x,tx0,gY,tx1,gY,'#d3d7dd',1); T(x,'G_diff',12,gY-30,{size:12,col:C.mut,weight:'bold'});
      x.fillStyle=C.green; x.globalAlpha=.7; x.fillRect(t2x(0.12),gY-30,t2x(0.28)-t2x(0.12),30); x.fillRect(t2x(0.5),gY-30,t2x(0.66)-t2x(0.5),30); x.globalAlpha=1;
      T(x,'dephase',(t2x(0.12)+t2x(0.28))/2,gY+14,{size:10,col:'#0a7a54',align:'center'}); T(x,'rephase',(t2x(0.5)+t2x(0.66))/2,gY+14,{size:10,col:'#0a7a54',align:'center'});
      // playhead
      const phx=t2x(this.t); L(x,phx,rfY-52,phx,gY+18,C.amber,2);
      // compute phase state at time t
      const tt=this.t; let stage;
      const spins=this.spins;
      for(const s of spins){ let ph=0;
        if(tt<0.12) ph=0;
        else if(tt<0.28){ const f=(tt-0.12)/0.16; ph=k*s.pos*f; }             // G1 dephase (by initial pos)
        else if(tt<0.42){ ph=k*s.pos; }
        else if(tt<0.5){ ph=-k*s.pos; }                                       // 180 flips
        else if(tt<0.66){ const f=(tt-0.5)/0.16; ph=-k*s.pos + k*(s.pos+s.disp)*f; } // G2 rephase (by current pos)
        else { ph=k*s.disp; }                                                 // residual = k*displacement
        s.ph=ph; }
      // draw phasor circle (net magnetization coherence)
      const cx=250,cy=350,R=80;
      x.strokeStyle='#e3e6ea'; x.lineWidth=1.5; x.beginPath(); x.arc(cx,cy,R,0,TAU); x.stroke();
      let sumx=0,sumy=0; for(const s of spins){ const a=s.ph-Math.PI/2; const ex=cx+Math.cos(a)*R, ey=cy+Math.sin(a)*R;
        L(x,cx,cy,ex,ey,'rgba(47,95,168,0.5)',1.5); sumx+=Math.cos(a); sumy+=Math.sin(a); }
      sumx/=spins.length; sumy/=spins.length; const net=Math.hypot(sumx,sumy);
      L(x,cx,cy,cx+sumx*R,cy+sumy*R,C.red,4); x.fillStyle=C.red; x.beginPath(); x.arc(cx+sumx*R,cy+sumy*R,5,0,TAU); x.fill();
      T(x,'Spinnfaser (netto = rødt)',cx,cy+R+26,{size:12.5,col:C.mut,align:'center'});
      // signal bar (right)
      const bx=560,by=280,bw=340; const S = this.diffuse? Math.exp(-(k*k*0.25*0.25))* /*approx*/ 1 : 1; // display uses net directly
      T(x,'Signal ved ekko  S = S₀ · e^(−b·D)',bx,by-14,{size:14,col:C.ink,weight:'bold'});
      x.fillStyle='#eef1f4'; rr(x,bx,by,bw,30,15); x.fill(); x.fillStyle=net>0.6?C.green:net>0.3?C.amber:C.red; rr(x,bx,by,Math.max(30,net*bw),30,15); x.fill();
      T(x,'netto signal ≈ '+(net*100).toFixed(0)+'%',bx,by+52,{size:13,col:C.ink,weight:'bold'});
      const cap = this.diffuse
        ? 'Vann beveger seg mellom de to gradientpulsene → fasene rephaser IKKE helt → signaltap. Sterkere gradient (høyere b) → mer tap.'
        : 'Stasjonære spinn: 2. gradient opphever nøyaktig 1. → full rephasing → fullt signal (ingen diffusjonseffekt).';
      wrapText(x,cap,bx,by+80,W-bx-40,18,{size:13.5,col:C.ink});
      wrapText(x,'b-verdi = γ²G²δ²(Δ − δ/3). Høyere b = mer diffusjonssensitiv.',bx,by+80+46,W-bx-40,18,{size:12.5,col:C.blue,weight:'bold'}); }
  };

  // ============================================================
  // 3. SIGNAL vs b-value / ADC  (static + slider)
  // ============================================================
  M.adc={ready:false,animated:false,cv:null,x:null,W:960,H:470,b:1000,bmax:3000,
    tissues:[{n:'CSF / væske',D:3.0e-3,c:C.blue},{n:'Grå substans',D:0.9e-3,c:C.green},
             {n:'Hvit substans',D:0.7e-3,c:C.purple},{n:'Akutt infarkt',D:0.35e-3,c:C.red}],
    init(root){ this.cv=root.querySelector('#cv-ad'); this.x=fit(this.cv,this.W,this.H);
      this.sl=root.querySelector('#ad-b'); this.slo=root.querySelector('#ad-bo');
      this.sl.oninput=()=>{ this.b=+this.sl.value; this.slo.textContent=this.b+' s/mm²'; this.draw(); }; this.slo.textContent=this.b+' s/mm²';
      this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H);
      const px0=60,px1=540,py0=48,py1=330; const b2x=b=>px0+b/this.bmax*(px1-px0); const s2y=s=>py1-s*(py1-py0);
      T(x,'Signalforfall  S = S₀·e^(−b·D)',px0,30,{size:16,col:C.ink,weight:'bold'});
      // axes
      L(x,px0,py0,px0,py1,'#c3c8cf',1.2); L(x,px0,py1,px1,py1,'#c3c8cf',1.2);
      for(const s of [0,0.5,1]){ const yy=s2y(s); L(x,px0-4,yy,px0,yy,'#c3c8cf',1); T(x,s.toFixed(1),px0-8,yy+4,{size:11,col:C.mut,align:'end'}); }
      T(x,'S/S₀',px0-8,py0-4,{size:11,col:C.mut,align:'end'});
      for(let b=0;b<=this.bmax;b+=1000){ const xx=b2x(b); L(x,xx,py1,xx,py1+4,'#c3c8cf',1); T(x,b,xx,py1+18,{size:11,col:C.mut,align:'center'}); }
      T(x,'b-verdi (s/mm²)',px1,py1+18,{size:11,col:C.mut,align:'end'});
      // curves
      for(const ts of this.tissues){ x.strokeStyle=ts.c; x.lineWidth=2.4; x.beginPath();
        for(let b=0;b<=this.bmax;b+=30){ const s=Math.exp(-b*ts.D); const xx=b2x(b),yy=s2y(s); b===0?x.moveTo(xx,yy):x.lineTo(xx,yy); } x.stroke();
        const yEnd=s2y(Math.exp(-this.bmax*ts.D)); T(x,ts.n,px1+6,yEnd+4,{size:11.5,col:ts.c,weight:'bold'}); }
      // b marker
      const bx=b2x(this.b); L(x,bx,py0,bx,py1,C.ink,1.6,[5,3]); T(x,'b = '+this.b,bx,py0-4,{size:12,col:C.ink,weight:'bold',align:'center'});
      // swatches: DWI (S at b) and ADC (D)
      const sx=660; T(x,'DWI (ved b='+this.b+')',sx,py0-4,{size:13,col:C.ink,weight:'bold'});
      T(x,'ADC-kart',sx+150,py0-4,{size:13,col:C.ink,weight:'bold'});
      this.tissues.forEach((ts,i)=>{ const yy=py0+16+i*58;
        const S=Math.exp(-this.b*ts.D); const g=Math.round(clamp(S,0,1)*235+10);
        x.fillStyle='rgb('+g+','+g+','+g+')'; rr(x,sx,yy,52,42,6); x.fill(); x.strokeStyle=ts.c;x.lineWidth=2; rr(x,sx,yy,52,42,6); x.stroke();
        const ad=clamp(ts.D/3.0e-3,0,1); const g2=Math.round(ad*235+10);
        x.fillStyle='rgb('+g2+','+g2+','+g2+')'; rr(x,sx+150,yy,52,42,6); x.fill(); x.strokeStyle=ts.c; rr(x,sx+150,yy,52,42,6); x.stroke();
        T(x,ts.n,sx+58,yy+16,{size:11.5,col:ts.c,weight:'bold'}); T(x,'ADC='+(ts.D*1000).toFixed(2)+'e-3',sx+58,yy+32,{size:10.5,col:C.mut}); });
      // caption
      wrapText(x,'ADC = ln(S₀/S)/(b−b₀) = kurvens helning. Ved høy b faller CSF mest (høy D) → mørk på DWI, lys på ADC.',40,H-38,W-80,18,{size:13.5,col:C.ink});
      wrapText(x,'Akutt infarkt: restriktert diffusjon → LYS på DWI og MØRK på ADC (skiller ekte restriksjon fra «T2-shine-through»).',40,H-16,W-80,18,{size:13,col:C.red,weight:'bold'}); }
  };

  // ============================================================
  // 4. DIFFUSION TENSOR ELLIPSOID  (eigenvalues -> FA/MD, drag)
  // ============================================================
  M.tensor={ready:false,animated:false,cv:null,x:null,W:960,H:470,l1:1.7,l2:0.4,l3:0.3,az:-0.6,el:0.5,
    init(root){ this.cv=root.querySelector('#cv-te'); this.x=fit(this.cv,this.W,this.H);
      const bind=(id,oid,set)=>{ const el=root.querySelector(id),o=root.querySelector(oid); el.oninput=()=>{ o.textContent=(+el.value).toFixed(2); set(+el.value); this.draw(); }; o.textContent=(+el.value).toFixed(2); };
      bind('#te-l1','#te-l1o',v=>this.l1=v); bind('#te-l2','#te-l2o',v=>this.l2=v); bind('#te-l3','#te-l3o',v=>this.l3=v);
      root.querySelectorAll('[data-tp]').forEach(b=>b.onclick=()=>{ const p=b.dataset.tp;
        const s = p==='iso'?[1,1,1] : p==='cig'?[1.7,0.3,0.3] : [1.2,1.1,0.25];
        this.l1=s[0];this.l2=s[1];this.l3=s[2];
        root.querySelector('#te-l1').value=s[0];root.querySelector('#te-l2').value=s[1];root.querySelector('#te-l3').value=s[2];
        root.querySelector('#te-l1o').textContent=s[0].toFixed(2);root.querySelector('#te-l2o').textContent=s[1].toFixed(2);root.querySelector('#te-l3o').textContent=s[2].toFixed(2);
        this.draw(); });
      let dg=false,lp=null; this.cv.addEventListener('pointerdown',e=>{dg=true;lp=[e.clientX,e.clientY];this.cv.setPointerCapture(e.pointerId);});
      this.cv.addEventListener('pointermove',e=>{ if(!dg)return; this.az-=(e.clientX-lp[0])*0.01; this.el=clamp(this.el+(e.clientY-lp[1])*0.01,-1.3,1.3); lp=[e.clientX,e.clientY]; this.draw(); });
      this.cv.addEventListener('pointerup',()=>dg=false); this.draw(); },
    proj(v,cx,cy,R){ const ca=Math.cos(this.az),sa=Math.sin(this.az),ce=Math.cos(this.el),se=Math.sin(this.el);
      const x1=v[0]*ca-v[1]*sa, y1=v[0]*sa+v[1]*ca, z1=v[2]; return [cx+x1*R, cy-(z1*ce-y1*se)*R, y1*ce+z1*se]; },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H);
      const cx=270,cy=225,R=95; const l1=this.l1,l2=this.l2,l3=this.l3;
      const md=(l1+l2+l3)/3, fa=Math.sqrt(0.5)*Math.sqrt((l1-l2)**2+(l2-l3)**2+(l3-l1)**2)/(Math.sqrt(l1*l1+l2*l2+l3*l3)||1e-9);
      const ad=l1, rd=(l2+l3)/2;
      // axes
      [[[1.6,0,0],'x'],[[0,1.6,0],'y'],[[0,0,1.6],'z']].forEach(a=>{ const p0=this.proj([0,0,0],cx,cy,R),p1=this.proj(a[0],cx,cy,R); L(x,p0[0],p0[1],p1[0],p1[1],'#d3d7dd',1); });
      // ellipsoid point cloud
      const pts=[]; const nu=22,nv=16;
      for(let i=0;i<=nu;i++)for(let j=0;j<=nv;j++){ const u=i/nu*TAU, v=j/nv*Math.PI;
        const px=l1*Math.sin(v)*Math.cos(u), py=l2*Math.sin(v)*Math.sin(u), pz=l3*Math.cos(v);
        const pr=this.proj([px,py,pz],cx,cy,R); pts.push({pr, dir:[px,py,pz]}); }
      pts.sort((a,b)=>a.pr[2]-b.pr[2]);
      for(const p of pts){ const dep=(p.pr[2]+2)/4; x.globalAlpha=0.25+0.55*clamp(dep,0,1);
        x.fillStyle=C.blue; x.beginPath(); x.arc(p.pr[0],p.pr[1],2.4,0,TAU); x.fill(); }
      x.globalAlpha=1;
      T(x,'Diffusjonstensor-ellipsoide',cx,34,{size:16,col:C.ink,weight:'bold',align:'center'});
      T(x,'(dra for å rotere)',cx,cy+R+40,{size:11.5,col:C.mut,align:'center'});
      // metrics panel
      const mx0=560; T(x,'Metrikker',mx0,60,{size:16,col:C.ink,weight:'bold'});
      const rows=[['FA (anisotropi)',fa.toFixed(3),fa>0.6?C.red:fa>0.2?C.amber:C.green],
        ['MD (middel)',md.toFixed(2),C.ink],['AD (aksial λ₁)',ad.toFixed(2),C.ink],['RD (radial)',rd.toFixed(2),C.ink]];
      rows.forEach((r,i)=>{ const yy=96+i*40; T(x,r[0],mx0,yy,{size:14,col:C.mut}); T(x,r[1],mx0+230,yy,{size:16,col:r[2],weight:'bold'}); });
      const shape = fa<0.15?'≈ kule → isotrop (CSF, grå substans)' : (l2>l3*1.6? 'pannekake → planar (kryssende fibre?)' : 'sigar → lineær (hvit substans)');
      T(x,'Form: '+shape,mx0,96+4*40+8,{size:13.5,col:C.purple,weight:'bold'});
      wrapText(x,'FA = √½ · √[(λ₁−λ₂)²+(λ₂−λ₃)²+(λ₃−λ₁)²] / √[λ₁²+λ₂²+λ₃²].  FA=0 isotrop, →1 helt lineær.',mx0,H-40,W-mx0-30,18,{size:12.5,col:C.blue,weight:'bold'});
      wrapText(x,'Egenverdiene λ er retningsuavhengige → derfor trenger vi tensoren (≥6 retninger).',mx0,H-16,W-mx0-30,18,{size:12.5,col:C.ink}); }
  };

  // ============================================================
  // 5. TRACTOGRAPHY  (streamlines from a direction field; crossing)
  // ============================================================
  M.tracto={ready:false,animated:true,cv:null,x:null,W:960,H:470,last:null,streams:[],grow:0,seeds:[],
    init(root){ this.cv=root.querySelector('#cv-tr'); this.x=fit(this.cv,this.W,this.H);
      const rb=root.querySelector('#tr-restart'); if(rb) rb.onclick=()=>this.reset();
      this.reset(); },
    field(x,y){ // two bundles: arc (blue, horizontal curving) + vertical (green); blend near crossing
      // arc bundle: direction tangent to circles centered below
      const ax=1, ay=-(x-480)/300;                       // gentle arch left->right
      const na=Math.hypot(ax,ay); const a=[ax/na,ay/na];
      const v=[0,1];                                       // vertical bundle
      // crossing region near center
      const d=Math.hypot(x-480,y-235); const wV=Math.exp(-((x-480)**2)/(90*90)); // vertical band around x=480
      const bx=a[0]*(1-wV)+v[0]*wV, by=a[1]*(1-wV)+v[1]*wV; const nb=Math.hypot(bx,by)||1;
      return [bx/nb,by/nb]; },
    reset(){ this.streams=[]; this.seeds=[];
      for(let i=0;i<14;i++) this.seeds.push([70, 90+i*20]);   // seed on left edge
      for(let i=0;i<8;i++) this.seeds.push([360+i*30, 40]);   // seeds on top (vertical bundle)
      this.streams=this.seeds.map(s=>({pts:[s.slice()],done:false})); this.grow=0; this.last=null; },
    step(st){ if(st.done)return; const p=st.pts[st.pts.length-1]; const d=this.field(p[0],p[1]);
      const np=[p[0]+d[0]*6, p[1]+d[1]*6]; st.pts.push(np);
      if(np[0]<20||np[0]>940||np[1]<20||np[1]>430||st.pts.length>140) st.done=true; },
    tick(t){ if(this.last==null)this.last=t; const dt=Math.min(0.05,t-this.last); this.last=t;
      this.grow+=dt*40; let allDone=true;
      for(const st of this.streams){ if(!st.done){ allDone=false; if(st.pts.length<this.grow) this.step(st); } }
      if(allDone){ if(!this.holdT)this.holdT=t; if(t-this.holdT>2){ this.holdT=null; this.reset(); } }
      this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H);
      T(x,'Traktografi — strømlinjer fra retningsfeltet',W/2,30,{size:16,col:C.ink,weight:'bold',align:'center'});
      // crossing marker
      x.fillStyle='rgba(217,154,16,0.10)'; x.beginPath(); x.arc(480,235,60,0,TAU); x.fill();
      // streamlines colored by local direction (RGB)
      for(const st of this.streams){ for(let i=1;i<st.pts.length;i++){ const a=st.pts[i-1],b=st.pts[i];
        const dx=b[0]-a[0],dy=b[1]-a[1]; const r=Math.abs(dx),g=Math.abs(dy); const n=Math.hypot(dx,dy)||1;
        x.strokeStyle='rgb('+Math.round(r/n*220)+','+Math.round(g/n*220)+',180)'; x.lineWidth=2.4; x.beginPath(); x.moveTo(a[0],a[1]); x.lineTo(b[0],b[1]); x.stroke(); }
        const h=st.pts[st.pts.length-1]; if(!st.done){ x.fillStyle=C.ink; x.beginPath(); x.arc(h[0],h[1],2.6,0,TAU); x.fill(); } }
      T(x,'kryssende fibre',480,235-66,{size:12,col:'#9a6b06',align:'center',weight:'bold'});
      wrapText(x,'Vi følger hovedretningen (første egenvektor) fra voksel til voksel → strømlinjer som tegner hvit substans. Farge = retning (rød=x, grønn=y).',40,H-38,W-80,18,{size:13.5,col:C.ink});
      wrapText(x,'Viktig: linjene er IKKE ekte aksoner, bare en generell retning — og kryssende fibre gir feil (DTI kan ikke skille dem).',40,H-16,W-80,18,{size:13,col:C.red,weight:'bold'}); }
  };

  window.runViz=function(name){ const m=M[name]; if(!m){console.error('unknown viz',name);return;}
    try{ m.init(document); m.ready=true; }catch(e){ console.error(e); }
    if(m.animated && m.tick){ (function loop(ts){ m.tick((ts||0)/1000); requestAnimationFrame(loop); })(); }
    window.addEventListener('resize',function(){ if(!m.cv)return; m.x=fit(m.cv,m.W,m.H); if(!m.animated && m.draw) m.draw(); }); };
  window.__diff={M};
})();
