/* Funksjonell MRI — interaktive animasjoner for Quarto reveal.js (iframe).
   HRF (dobbel-gamma), konvolusjon og GLM-logikk verifisert numerisk før innbygging. */
(function(){
  "use strict";
  const FT="'DejaVu Sans', Verdana, sans-serif";
  const C={blue:'#2F5FA8',red:'#C0392B',purple:'#5d3a8e',orange:'#b54a16',green:'#10b981',
           amber:'#d99a10',ink:'#1f2430',mut:'#9aa2ad',line:'#e3e6ea'};
  const clamp=(v,a,b)=>v<a?a:(v>b?b:v), TAU=Math.PI*2;
  function fit(cv,w,h){ const dpr=Math.max(1,Math.min(2.5,window.devicePixelRatio||1));
    cv.width=w*dpr; cv.height=h*dpr; cv.style.aspectRatio=w+'/'+h; const x=cv.getContext('2d'); x.setTransform(dpr,0,0,dpr,0,0); return x; }
  function T(x,s,px,py,o){ o=o||{}; x.globalAlpha=o.alpha==null?1:o.alpha; x.fillStyle=o.col||C.ink;
    x.font=(o.weight||'normal')+' '+(o.size||14)+'px '+FT; x.textAlign=o.align||'left'; x.textBaseline=o.base||'alphabetic'; x.fillText(s,px,py); x.globalAlpha=1; }
  function L(x,a,b,c,d,col,w,dash){ x.strokeStyle=col; x.lineWidth=w||1; x.setLineDash(dash||[]); x.beginPath(); x.moveTo(a,b); x.lineTo(c,d); x.stroke(); x.setLineDash([]); }
  function rr(x,px,py,w,h,r){ x.beginPath(); x.moveTo(px+r,py); x.arcTo(px+w,py,px+w,py+h,r); x.arcTo(px+w,py+h,px,py+h,r); x.arcTo(px,py+h,px,py,r); x.arcTo(px,py,px+w,py,r); x.closePath(); }
  function wrapText(x,s,px,py,maxw,lh,o){ const words=s.split(' '); let line='',yy=py; x.font=(o.weight||'normal')+' '+(o.size||13)+'px '+FT;
    for(const w of words){ const t=line?line+' '+w:w; if(x.measureText(t).width>maxw && line){ T(x,line,px,yy,o); line=w; yy+=lh; } else line=t; } if(line) T(x,line,px,yy,o); return yy; }
  // HRF (double-gamma)
  function gammaFn(n){ const g=7,c=[0.99999999999980993,676.5203681218851,-1259.1392167224028,771.32342877765313,-176.61502916214059,12.507343278686905,-0.13857109526572012,9.9843695780195716e-6,1.5056327351493116e-7];
    if(n<0.5)return Math.PI/(Math.sin(Math.PI*n)*gammaFn(1-n)); n-=1; let x=c[0]; for(let i=1;i<g+2;i++)x+=c[i]/(n+i); const t=n+g+0.5; return Math.sqrt(2*Math.PI)*Math.pow(t,n+0.5)*Math.exp(-t)*x; }
  function gpdf(t,a,b){ return t<=0?0:Math.pow(b,a)*Math.pow(t,a-1)*Math.exp(-b*t)/gammaFn(a); }
  function hrf(t){ return gpdf(t,6,1)-(1/6)*gpdf(t,16,1); }
  const rnd=(()=>{ let s=12345; return ()=>{ s=(s*1103515245+12345)&0x7fffffff; return s/0x7fffffff; }; })();

  const M={};

  // ============================================================
  // 1. BOLD MECHANISM  (neurovascular coupling)  animated
  // ============================================================
  M.bold={ready:false,animated:true,cv:null,x:null,W:960,H:470,t:0,last:null,rbc:[],
    init(root){ this.cv=root.querySelector('#cv-bold'); this.x=fit(this.cv,this.W,this.H);
      this.rbc=[]; for(let i=0;i<16;i++) this.rbc.push({p:Math.random(),lane:(i%2)}); this.t=0; },
    tick(t){ if(this.last==null)this.last=t; const dt=Math.min(0.05,t-this.last); this.last=t; this.t+=dt; this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H);
      const period=12, tt=this.t%period; const active = tt>3 && tt<9;   // stimulus window
      const flow = active? 1.9 : 1.0;                                    // CBF increases
      const dHb = active? 0.35 : 0.75;                                   // deoxyHb fraction (drops when active)
      T(x,'BOLD: nevrovaskulær kobling',W/2,28,{size:16,col:C.ink,weight:'bold',align:'center'});
      // stimulus indicator
      x.fillStyle=active?C.amber:'#e3e6ea'; rr(x,40,44,180,22,6); x.fill();
      T(x, active?'STIMULUS PÅ':'hvile', 130,60,{size:12.5,col:active?'#7a5a06':C.mut,weight:'bold',align:'center'});
      // neuron (left)
      const nx=110,ny=200; x.fillStyle=active?C.purple:'#b9a9d0'; x.beginPath(); x.arc(nx,ny,26,0,TAU); x.fill();
      for(let a=0;a<6;a++){ const an=a/6*TAU; L(x,nx+Math.cos(an)*26,ny+Math.sin(an)*26,nx+Math.cos(an)*46,ny+Math.sin(an)*46,active?C.purple:'#b9a9d0',2); }
      T(x,'nevron',nx,ny+70,{size:12,col:C.mut,align:'center'}); if(active)T(x,'fyrer!',nx,ny-42,{size:12,col:C.purple,weight:'bold',align:'center'});
      // vessel (a horizontal capillary)
      const vx0=210,vx1=560,vy=200,vr=22; x.fillStyle='#f3d9d9'; rr(x,vx0,vy-vr,vx1-vx0,vr*2,vr); x.fill();
      x.strokeStyle='#e0b3b3'; x.lineWidth=1.5; rr(x,vx0,vy-vr,vx1-vx0,vr*2,vr); x.stroke();
      // RBCs move; colour = oxygenation (red=oxy, blue-ish=deoxy)
      for(const r of this.rbc){ r.p+=0.0016*flow* (1000/60); r.p%=1; const px=vx0+8+r.p*(vx1-vx0-16); const py=vy+(r.lane?-8:8);
        const deoxy = Math.random()<dHb; x.fillStyle= deoxy? '#6b7fc0':'#d0342b'; x.beginPath(); x.ellipse(px,py,8,5,0,0,TAU); x.fill(); }
      T(x,'kapillær',(vx0+vx1)/2,vy-vr-10,{size:12,col:C.mut,align:'center'});
      T(x, active?'blodstrøm ↑↑ → mindre deoksyHb':'deoksyHb (paramagnetisk) forstyrrer feltet',(vx0+vx1)/2,vy+vr+22,{size:12,col:active?'#0a7a54':C.red,align:'center',weight:'bold'});
      // field distortion around vessel (more when deoxy high)
      const dist = dHb; x.strokeStyle='rgba(192,57,43,'+(0.15+dist*0.5)+')'; x.lineWidth=1;
      for(let i=1;i<=3;i++){ x.beginPath(); x.ellipse((vx0+vx1)/2,vy,(vx1-vx0)/2+i*10*dist+6,vr+i*8*dist+4,0,0,TAU); x.stroke(); }
      // BOLD signal trace (right) following HRF of the stimulus
      const gx=620,gy=90,gw=300,gh=250; L(x,gx,gy+gh,gx+gw,gy+gh,'#c3c8cf',1); L(x,gx,gy,gx,gy+gh,'#c3c8cf',1);
      T(x,'BOLD-signal (%)',gx-4,gy-6,{size:12,col:C.mut,align:'end'}); T(x,'tid →',gx+gw,gy+gh+16,{size:11,col:C.mut,align:'end'});
      // build signal over one period from convolving the stimulus box with hrf
      x.strokeStyle=C.blue; x.lineWidth=2.4; x.beginPath();
      for(let i=0;i<=gw;i++){ const tau=i/gw*period; let s=0; for(let k=0;k<=tau;k+=0.25){ const stim=(k>3&&k<9)?1:0; s+=stim*hrf(tau-k)*0.25; } const px=gx+i, py=gy+gh-8-clamp(s*11,0,1)*(gh-16); i?x.lineTo(px,py):x.moveTo(px,py); } x.stroke();
      const nowx=gx+(tt/period)*gw; L(x,nowx,gy,nowx,gy+gh,C.amber,1.5);
      T(x,'↑ signal øker (~2–4 %) når deoksyHb faller',gx,gy+gh+34,{size:12,col:C.blue,weight:'bold'});
      wrapText(x,'Aktivering → oksygenbehov → blodstrømmen øker MER enn forbruket → mindre deoksyhemoglobin → mindre T2*-defasing → MER signal.',40,H-20,540,17,{size:12.5,col:C.ink}); }
  };

  // ============================================================
  // 2. HEMODYNAMIC RESPONSE FUNCTION  (single vs train)
  // ============================================================
  M.hrf={ready:false,animated:true,cv:null,x:null,W:960,H:460,mode:'single',t:0,last:null,
    init(root){ this.cv=root.querySelector('#cv-hrf'); this.x=fit(this.cv,this.W,this.H);
      root.querySelectorAll('[data-hmode]').forEach(b=>b.onclick=()=>{ this.mode=b.dataset.hmode;
        root.querySelectorAll('[data-hmode]').forEach(q=>q.classList.toggle('on',q===b)); this.t=0; }); this.t=0; },
    stimAt(t){ if(this.mode==='single') return (t>=2&&t<3)?1:0; return (t>=2 && Math.floor((t-2)/2)%1===0 && ((t-2)%2)<1)?1:0; },
    tick(t){ if(this.last==null)this.last=t; const dt=Math.min(0.05,t-this.last); this.last=t; this.t+=dt*3.5; if(this.t>32)this.t=0; this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H); const Tmax=32;
      T(x,'Hemodynamikk-responsfunksjon (HRF)',W/2,28,{size:16,col:C.ink,weight:'bold',align:'center'});
      const gx=70,gw=830; const t2x=t=>gx+t/Tmax*gw;
      // stimulus row
      const syB=90; L(x,gx,syB,gx+gw,syB,'#e3e6ea',1); T(x,'stimulus',20,syB-2,{size:12,col:C.mut,weight:'bold'});
      x.fillStyle=C.amber; for(let t=0;t<Tmax;t+=0.1){ if(this.stimAt(t)>0 && t<=this.t){ x.fillRect(t2x(t),syB-24,t2x(t+0.1)-t2x(t)+0.5,24); } }
      // BOLD (convolve stimulus with hrf)
      const by0=150,by1=360; L(x,gx,by1,gx+gw,by1,'#c3c8cf',1); L(x,gx,by0,gx,by1,'#c3c8cf',1);
      T(x,'BOLD-respons',20,by0+4,{size:12,col:C.mut,weight:'bold'});
      const nShow=Math.floor(this.t/Tmax*gw);
      x.strokeStyle=C.blue; x.lineWidth=2.6; x.beginPath();
      for(let i=0;i<=nShow;i++){ const tau=i/gw*Tmax; let s=0; for(let k=0;k<=tau;k+=0.2){ s+=this.stimAt(k)*hrf(tau-k)*0.2; } const px=gx+i, py=by1-40-clamp(s,-0.05,0.25)/0.25*(by1-by0-50); i?x.lineTo(px,py):x.moveTo(px,py); } x.stroke();
      L(x,gx,by1-40,gx+gw,by1-40,'#eef1f4',1);  // baseline
      for(let s=0;s<=Tmax;s+=5){ const xx=t2x(s); L(x,xx,by1,xx,by1+4,'#c3c8cf',1); T(x,s+'s',xx,by1+18,{size:11,col:C.mut,align:'center'}); }
      // annotate features (only in single mode, after enough time)
      if(this.mode==='single' && this.t>20){
        T(x,'initial dip',t2x(3.5),by1-30,{size:11,col:C.mut,align:'center'});
        T(x,'topp (~5–6 s)',t2x(7),by0+30,{size:12,col:C.blue,align:'center',weight:'bold'});
        T(x,'undershoot (~15 s)',t2x(16),by1-16,{size:11,col:C.red,align:'center'}); }
      wrapText(x, this.mode==='single'
        ? 'Ett kort stimulus gir en TREG respons: liten initial dip, topp etter ~5–6 s, så en undershoot rundt 15 s. Nevronene fyrer på millisekunder — blodet svarer på sekunder.'
        : 'Tett stimulus-tog: responsene overlapper (konvolusjon) og bygger seg opp til et vedvarende platå. Dette utnyttes i blokk-design.',
        70,H-40,W-140,18,{size:13,col:C.ink});
      T(x,'BOLD = stimulus ⊗ HRF (konvolusjon)',70,H-14,{size:12.5,col:C.blue,weight:'bold'}); }
  };

  // ============================================================
  // 3. EXPERIMENTAL DESIGN + AVERAGING
  // ============================================================
  M.design={ready:false,animated:false,cv:null,x:null,W:960,H:470,mode:'block',nrun:1,
    init(root){ this.cv=root.querySelector('#cv-dsg'); this.x=fit(this.cv,this.W,this.H);
      root.querySelectorAll('[data-dmode]').forEach(b=>b.onclick=()=>{ this.mode=b.dataset.dmode;
        root.querySelectorAll('[data-dmode]').forEach(q=>q.classList.toggle('on',q===b)); this.draw(); });
      this.sl=root.querySelector('#dsg-n'); this.slo=root.querySelector('#dsg-no');
      if(this.sl){ this.sl.oninput=()=>{ this.nrun=+this.sl.value; this.slo.textContent=this.nrun+(this.nrun>1?' kjøringer':' kjøring'); this.draw(); }; this.slo.textContent=this.nrun+' kjøring'; }
      this.draw(); },
    stimAt(t){ if(this.mode==='block') return (Math.floor(t/16)%2===1)?1:0;
      const events=[6,10,22,34,40,52,64,70,82,94,100,112]; for(const e of events){ if(t>=e && t<e+1) return 1; } return 0; },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H); const Tn=128, gx=70,gw=830, t2x=t=>gx+t/Tn*gw;
      T(x,'Eksperimentdesign og midling',W/2,26,{size:16,col:C.ink,weight:'bold',align:'center'});
      // paradigm
      const py0=60; T(x,'paradigme',20,py0+2,{size:11.5,col:C.mut,weight:'bold'}); x.fillStyle=C.amber;
      for(let t=0;t<Tn;t+=0.2){ if(this.stimAt(t)>0) x.fillRect(t2x(t),py0-18,Math.max(1.5,t2x(t+0.2)-t2x(t)),18); }
      // predicted BOLD
      const pr=[]; for(let t=0;t<Tn;t++){ let s=0; for(let k=0;k<=30;k+=0.5){ if(t-k>=0)s+=this.stimAt(t-k)*hrf(k)*0.5; } pr.push(s); }
      let mxp=Math.max(...pr,0.01); const pn=pr.map(v=>v/mxp);
      const dy0=90,dy1=210; T(x,'forventet BOLD',20,dy0+14,{size:11.5,col:C.mut,weight:'bold'}); L(x,gx,(dy0+dy1)/2,gx+gw,(dy0+dy1)/2,'#eef1f4',1);
      x.strokeStyle=C.green; x.lineWidth=2; x.beginPath(); for(let t=0;t<Tn;t++){ const px=t2x(t), yy=(dy0+dy1)/2-pn[t]*((dy1-dy0)/2-6); t?x.lineTo(px,yy):x.moveTo(px,yy); } x.stroke();
      // measured = predicted*amp + noise, averaged over nrun
      const my0=240,my1=380; T(x,'målt (midlet)',20,my0+14,{size:11.5,col:C.mut,weight:'bold'}); L(x,gx,(my0+my1)/2,gx+gw,(my0+my1)/2,'#eef1f4',1);
      const avg=new Array(Tn).fill(0);
      for(let r=0;r<this.nrun;r++){ for(let t=0;t<Tn;t++){ avg[t]+=pn[t]*0.9+(rnd()*2-1)*1.6; } }
      for(let t=0;t<Tn;t++)avg[t]/=this.nrun;
      x.strokeStyle=C.blue; x.lineWidth=1.8; x.beginPath(); for(let t=0;t<Tn;t++){ const px=t2x(t), yy=(my0+my1)/2-clamp(avg[t],-2.5,2.5)*((my1-my0)/2-6)/2.5; t?x.lineTo(px,yy):x.moveTo(px,yy); } x.stroke();
      // correlation with predicted
      const ma=avg.reduce((a,b)=>a+b,0)/Tn, mp=pn.reduce((a,b)=>a+b,0)/Tn; let n=0,da=0,db=0; for(let t=0;t<Tn;t++){ n+=(avg[t]-ma)*(pn[t]-mp); da+=(avg[t]-ma)**2; db+=(pn[t]-mp)**2; } const cc=n/Math.sqrt(da*db);
      T(x,'korrelasjon med forventet: r = '+cc.toFixed(2),gx,my1+22,{size:13,col:cc>0.6?'#0a7a54':C.red,weight:'bold'});
      wrapText(x, this.mode==='block'?'Blokk-design: lange på/av-perioder → stort, robust signal.':'Hendelsesrelatert: korte, spredte hendelser → fleksibelt, men svakere signal.',gx+360,my1+22,W-gx-380,17,{size:12.5,col:C.ink});
      wrapText(x,'Enkeltmålinger drukner i støy. Flere kjøringer → støyen midles bort (∝ 1/√N) → responsen dukker fram. Dra glidebryteren.',70,H-16,W-140,17,{size:12.5,col:C.blue,weight:'bold'}); }
  };

  // ============================================================
  // 4. ACTIVATION MAPPING  (functional localization)
  // ============================================================
  M.activation={ready:false,animated:true,cv:null,x:null,W:960,H:470,stim:'visuell',t:0,last:null,
    regions:{visuell:{x:0.80,y:0.52,lab:'visuell korteks',col:'#C0392B'},
             motorisk:{x:0.50,y:0.30,lab:'motorisk korteks',col:'#2F5FA8'},
             auditiv:{x:0.32,y:0.55,lab:'auditiv korteks',col:'#5d3a8e'}},
    init(root){ this.cv=root.querySelector('#cv-act'); this.x=fit(this.cv,this.W,this.H);
      root.querySelectorAll('[data-astim]').forEach(b=>{ b.classList.toggle('on',b.dataset.astim===this.stim);
        b.onclick=()=>{ this.stim=b.dataset.astim; root.querySelectorAll('[data-astim]').forEach(q=>q.classList.toggle('on',q===b)); }; }); this.t=0; },
    tick(t){ if(this.last==null)this.last=t; const dt=Math.min(0.05,t-this.last); this.last=t; this.t+=dt; this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H);
      T(x,'Aktiveringskart: funksjonell lokalisering',W/2,28,{size:16,col:C.ink,weight:'bold',align:'center'});
      // brain (sagittal-ish ellipse)
      const bx=70,by=70,bw=460,bh=340; x.fillStyle='#eceff3'; x.beginPath(); x.ellipse(bx+bw/2,by+bh/2,bw/2,bh/2,0,0,TAU); x.fill();
      x.strokeStyle='#d7dbe0'; x.lineWidth=1.5; x.stroke();
      const period=8, on=(this.t%period)<period/2;
      // regions: active one pulses
      for(const k in this.regions){ const R=this.regions[k]; const rx=bx+R.x*bw, ry=by+R.y*bh; const act=(k===this.stim)&&on;
        x.fillStyle= (k===this.stim)? (act?R.col:'#f0c9c4') : '#dfe3e8';
        if(k===this.stim && act){ x.globalAlpha=0.85; } else x.globalAlpha= (k===this.stim)?0.6:0.5;
        x.beginPath(); x.arc(rx,ry,act?26:20,0,TAU); x.fill(); x.globalAlpha=1;
        if(k===this.stim){ T(x,R.lab,rx,ry+ (R.y>0.5?42:-30),{size:12,col:R.col,weight:'bold',align:'center'}); } }
      // stimulus icon
      const stimTxt={visuell:'👁 visuelt (sjakkbrett)',motorisk:'✊ fingerbevegelse',auditiv:'🔊 lyd'}[this.stim];
      x.fillStyle=on?C.amber:'#e3e6ea'; rr(x,bx,by+bh+14,bw,26,8); x.fill();
      T(x, on?'STIMULUS PÅ':'hvile', bx+bw/2, by+bh+32,{size:12.5,col:on?'#7a5a06':C.mut,weight:'bold',align:'center'});
      // right: time series of active region vs design
      const gx=580,gy=90,gw=330,gh=150; L(x,gx,gy+gh,gx+gw,gy+gh,'#c3c8cf',1); L(x,gx,gy,gx,gy+gh,'#c3c8cf',1);
      T(x,'signal i '+this.regions[this.stim].lab,gx,gy-8,{size:12.5,col:this.regions[this.stim].col,weight:'bold'});
      x.strokeStyle=this.regions[this.stim].col; x.lineWidth=2; x.beginPath();
      for(let i=0;i<=gw;i++){ const tau=(this.t-(gw-i)*0.05); let s=0; for(let k=0;k<=20;k+=0.5){ const tk=tau-k; const st=(tk>0 && (Math.floor(tk/period)*period+0? true:true) && (tk%period)<period/2)?1:0; s+=st*hrf(k)*0.5; } const py=gy+gh-10-clamp(s*7,0,1)*(gh-20); i?x.lineTo(gx+i,py):x.moveTo(gx+i,py); } x.stroke();
      // design boxes under
      T(x,'↑ signalet følger stimulus-tidslinjen (korrelasjon → t-verdi → farge)',gx,gy+gh+24,{size:12,col:C.ink});
      wrapText(x,'Hver voksels tidsserie sammenlignes med paradigmet (GLM). Der de passer → høy t-verdi → voksel «lyser opp». Ulike stimuli aktiverer ulike korteksområder.',580,H-70,W-600,18,{size:12.5,col:C.ink});
      T(x,'Bytt stimulus og se hvilket område som aktiveres.',580,H-16,{size:12.5,col:C.blue,weight:'bold'}); }
  };

  // ============================================================
  // 5. FUNCTIONAL CONNECTIVITY  (resting-state)
  // ============================================================
  M.connectivity={ready:false,animated:true,cv:null,x:null,W:960,H:470,net:'alle',t:0,last:null,
    nodes:null,
    init(root){ this.cv=root.querySelector('#cv-con'); this.x=fit(this.cv,this.W,this.H);
      root.querySelectorAll('[data-net]').forEach(b=>{ b.classList.toggle('on',b.dataset.net===this.net);
        b.onclick=()=>{ this.net=b.dataset.net; root.querySelectorAll('[data-net]').forEach(q=>q.classList.toggle('on',q===b)); }; });
      // nodes with network membership + phase (within-net correlated)
      const nets={dmn:{col:C.red,ph:0},visuell:{col:C.blue,ph:2},motorisk:{col:C.green,ph:4}};
      this.netMeta=nets;
      const pos={dmn:[[0.30,0.30],[0.34,0.62],[0.5,0.78],[0.66,0.62]],visuell:[[0.80,0.42],[0.82,0.62]],motorisk:[[0.5,0.20],[0.62,0.30],[0.40,0.30]]};
      this.nodes=[]; for(const k in pos) pos[k].forEach(p=>this.nodes.push({x:p[0],y:p[1],net:k,col:nets[k].col,base:nets[k].ph}));
      this.t=0; },
    sig(node,t){ return Math.sin(t*0.9+node.base) + 0.35*Math.sin(t*2.3+node.x*5); },
    tick(t){ if(this.last==null)this.last=t; const dt=Math.min(0.05,t-this.last); this.last=t; this.t+=dt*1.4; this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H);
      T(x,'Funksjonell konnektivitet (hvile-tilstand)',W/2,28,{size:16,col:C.ink,weight:'bold',align:'center'});
      const bx=60,by=70,bw=520,bh=360; x.fillStyle='#f2f4f7'; x.beginPath(); x.ellipse(bx+bw/2,by+bh/2,bw/2,bh/2,0,0,TAU); x.fill();
      x.strokeStyle='#dfe3e8'; x.lineWidth=1.5; x.stroke();
      const show=n=>this.net==='alle'||this.net===n.net;
      // edges within same network (correlated)
      for(let i=0;i<this.nodes.length;i++)for(let j=i+1;j<this.nodes.length;j++){ const a=this.nodes[i],b=this.nodes[j];
        if(a.net===b.net && show(a)){ x.strokeStyle=a.col; x.globalAlpha=0.35; x.lineWidth=2; L(x,bx+a.x*bw,by+a.y*bh,bx+b.x*bw,by+b.y*bh,a.col,2); x.globalAlpha=1; } }
      // nodes pulse with their signal
      for(const n of this.nodes){ if(!show(n)){ continue; } const v=this.sig(n,this.t); const r=8+clamp((v+1.4)/2.8,0,1)*8;
        x.fillStyle=n.col; x.globalAlpha=show(n)?1:0.15; x.beginPath(); x.arc(bx+n.x*bw,by+n.y*bh,r,0,TAU); x.fill(); x.globalAlpha=1; }
      // legend + time series
      const lx=620; T(x,'Nettverk',lx,84,{size:15,col:C.ink,weight:'bold'});
      [['dmn','Default mode',C.red],['visuell','Visuelt',C.blue],['motorisk','Motorisk',C.green]].forEach((r,i)=>{ const yy=110+i*26; x.fillStyle=r[2]; x.beginPath(); x.arc(lx+6,yy-4,6,0,TAU); x.fill(); T(x,r[1],lx+20,yy,{size:13,col:r[2],weight:'bold'}); });
      // two example time series (same net = correlated)
      const gx=lx,gy=210,gw=300,gh=90; L(x,gx,gy+gh,gx+gw,gy+gh,'#c3c8cf',1);
      const nA=this.nodes[0], nB=this.nodes[1], nC=this.nodes.find(n=>n.net==='visuell');
      const plot=(nd,col,off)=>{ x.strokeStyle=col; x.lineWidth=2; x.beginPath(); for(let i=0;i<=gw;i++){ const tau=this.t-(gw-i)*0.03; const py=gy+gh/2-this.sig(nd,tau)*(gh/2-6)+off; i?x.lineTo(gx+i,py):x.moveTo(gx+i,py); } x.stroke(); };
      plot(nA,C.red,-2); plot(nB,'#e07a72',2); if(nC)plot(nC,C.blue,0);
      T(x,'DMN-noder svinger i takt (korrelert); annet nettverk ute av fase.',gx,gy+gh+20,{size:11.5,col:C.mut});
      wrapText(x,'I hvile svinger BOLD-signalet spontant. Regioner som svinger SAMMEN hører til samme nettverk (f.eks. default mode) — uten noen oppgave.',lx,H-56,W-lx-30,18,{size:12.5,col:C.ink});
      T(x,'Filtrer nettverk med knappene under.',lx,H-16,{size:12.5,col:C.blue,weight:'bold'}); }
  };

  window.runViz=function(name){ const m=M[name]; if(!m){console.error('unknown viz',name);return;}
    try{ m.init(document); m.ready=true; }catch(e){ console.error(e); }
    if(m.animated && m.tick){ (function loop(ts){ m.tick((ts||0)/1000); requestAnimationFrame(loop); })(); }
    window.addEventListener('resize',function(){ if(!m.cv)return; m.x=fit(m.cv,m.W,m.H); if(!m.animated && m.draw) m.draw(); }); };
  window.__fmri={M,hrf};
})();
