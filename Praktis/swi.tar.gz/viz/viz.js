/* Susceptibilitetsvektet avbildning (SWI) — interaktive apper for Quarto reveal.js (iframe).
   Fysikk (dipolfelt, fase φ=−γΔB·TE, fasemaske, mIP) verifisert numerisk før innbygging. */
(function(){
  "use strict";
  const FT="'DejaVu Sans', Verdana, sans-serif";
  const C={blue:'#2F5FA8',red:'#C0392B',purple:'#5d3a8e',orange:'#b54a16',green:'#10b981',
           amber:'#d99a10',ink:'#1f2430',mut:'#9aa2ad',line:'#e3e6ea'};
  const clamp=(v,a,b)=>v<a?a:(v>b?b:v), TAU=Math.PI*2;
  function fit(cv,w,h){ const dpr=Math.max(1,Math.min(2.5,window.devicePixelRatio||1));
    cv.width=w*dpr; cv.height=h*dpr; cv.style.aspectRatio=w+'/'+h; const x=cv.getContext('2d'); x.setTransform(dpr,0,0,dpr,0,0); return x; }
  function T(x,s,px,py,o){ o=o||{}; x.globalAlpha=o.alpha==null?1:o.alpha; x.fillStyle=o.col||C.ink;
    x.font=(o.weight||'normal')+' '+(o.size||14)+'px '+FT; x.textAlign=o.align||'left'; x.textBaseline=o.base||'alphabetic'; x.fillText(s,px,py); x.globalAlpha=1; }
  function L(x,a,b,c,d,col,w,dash){ x.strokeStyle=col; x.lineWidth=w||1; x.setLineDash(dash||[]); x.beginPath(); x.moveTo(a,b); x.lineTo(c,d); x.stroke(); x.setLineDash([]); }
  function rr(x,px,py,w,h,r){ x.beginPath(); x.moveTo(px+r,py); x.arcTo(px+w,py,px+w,py+h,r); x.arcTo(px+w,py+h,px,py+h,r); x.arcTo(px,py+h,px,py,r); x.arcTo(px,py,px+w,py,r); x.closePath(); }
  function wrapText(x,s,px,py,maxw,lh,o){ const words=s.split(' '); let line='',yy=py; x.font=(o.weight||'normal')+' '+(o.size||13)+'px '+FT;
    for(const w of words){ const t=line?line+' '+w:w; if(x.measureText(t).width>maxw && line){ T(x,line,px,yy,o); line=w; yy+=lh; } else line=t; } if(line) T(x,line,px,yy,o); return yy; }
  const wrapPhase=p=>((p+Math.PI)%TAU+TAU)%TAU-Math.PI;
  // colormaps
  function divRGB(v){ // -1..1 → blue..white..red
    v=clamp(v,-1,1); if(v>=0){ const t=v; return [255, Math.round(255-t*200), Math.round(255-t*200)]; }
    const t=-v; return [Math.round(255-t*200), Math.round(255-t*160), 255]; }
  function phaseRGB(p){ // -π..π cyclic → hue wheel
    const h=(wrapPhase(p)+Math.PI)/TAU*360; const s=0.65,l=0.5; return hsl(h,s,l); }
  function hsl(h,s,l){ const c=(1-Math.abs(2*l-1))*s, x=c*(1-Math.abs((h/60)%2-1)), m=l-c/2; let r,g,b;
    if(h<60)[r,g,b]=[c,x,0]; else if(h<120)[r,g,b]=[x,c,0]; else if(h<180)[r,g,b]=[0,c,x]; else if(h<240)[r,g,b]=[0,x,c]; else if(h<300)[r,g,b]=[x,0,c]; else [r,g,b]=[c,0,x];
    return [Math.round((r+m)*255),Math.round((g+m)*255),Math.round((b+m)*255)]; }

  const M={};

  // ============================================================
  // 1. SUSCEPTIBILITY → DIPOLE FIELD → PHASE  (TE slider, para/dia)
  // ============================================================
  M.suscfield={ready:false,animated:false,cv:null,x:null,W:960,H:470,TE:20,sign:+1,
    init(root){ this.cv=root.querySelector('#cv-sf'); this.x=fit(this.cv,this.W,this.H);
      this.sl=root.querySelector('#sf-te'); this.slo=root.querySelector('#sf-teo');
      this.sl.oninput=()=>{ this.TE=+this.sl.value; this.slo.textContent=this.TE+' ms'; this.draw(); }; this.slo.textContent=this.TE+' ms';
      root.querySelectorAll('[data-sus]').forEach(b=>{ b.classList.toggle('on',(+b.dataset.sus)===this.sign);
        b.onclick=()=>{ this.sign=+b.dataset.sus; root.querySelectorAll('[data-sus]').forEach(q=>q.classList.toggle('on',q===b)); this.draw(); }; });
      this.draw(); },
    field(dx,dy,R){ const r=Math.hypot(dx,dy); if(r<R) return null; // inside object
      const cos=dy/r; return this.sign*(3*cos*cos-1)*Math.pow(R/r,3); },
    panel(x, X,Y,S, mode){ const R=S*0.13, cx=X+S/2, cy=Y+S/2; const img=this.x.createImageData(S,S); const d=img.data;
      for(let j=0;j<S;j++)for(let i=0;i<S;i++){ const dx=i-S/2, dy=j-S/2; const f=this.field(dx,dy,R); let rgb;
        if(f===null){ rgb=[70,70,78]; }
        else if(mode==='field'){ rgb=divRGB(clamp(f*1.6,-1,1)); }
        else { const ph=wrapPhase(-f*this.TE*0.09); rgb=phaseRGB(ph); }
        const k=(j*S+i)*4; d[k]=rgb[0]; d[k+1]=rgb[1]; d[k+2]=rgb[2]; d[k+3]=255; }
      x.putImageData(img,X,Y); x.strokeStyle='#c3c8cf'; x.lineWidth=1; x.strokeRect(X,Y,S,S);
      x.fillStyle='#2b2f38'; x.beginPath(); x.arc(cx,cy,R,0,TAU); x.fill(); },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H);
      T(x,'Susceptibilitet → lokalt felt → fase',W/2,28,{size:16,col:C.ink,weight:'bold',align:'center'});
      const S=300;
      this.panel(x,60,60,S,'field'); T(x,'Feltforstyrrelse ΔB (dipolfelt)',60+S/2,50,{size:13,col:C.ink,weight:'bold',align:'center'});
      this.panel(x,560,60,S,'phase'); T(x,'Fasebilde  φ = −γ·ΔB·TE',560+S/2,50,{size:13,col:C.ink,weight:'bold',align:'center'});
      // B0 arrow
      L(x,30,80,30,300,C.mut,2); T(x,'B₀',22,72,{size:12,col:C.mut,weight:'bold'});
      // legend for field
      T(x,'rød +ΔB · blå −ΔB',60,60+S+20,{size:12,col:C.mut});
      T(x, this.sign>0?'paramagnetisk (χ>0): deoksyHb, jern, blødning':'diamagnetisk (χ<0): kalk',60,60+S+38,{size:12.5,col:this.sign>0?C.red:C.blue,weight:'bold'});
      const nwrap=Math.abs(2*0.09*this.TE*2)/TAU;
      T(x,'lengre TE → mer fasevikling (flere ombrytninger)',560,60+S+20,{size:12,col:C.mut});
      T(x,'ved ±π brytes fasen om («fase-mareritt»)',560,60+S+38,{size:12.5,col:C.purple,weight:'bold'});
      wrapText(x,'Objektet magnetiseres og lager et dipolfelt (3cos²θ−1): positivt ved polene, negativt ved ekvator, null ved «magisk vinkel» 54,7°. Fasen vokser med TE og skifter fortegn mellom para- og diamagnetisk.',60,H-24,W-120,17,{size:12.5,col:C.ink}); }
  };

  // ============================================================
  // 2. SWI PIPELINE  (magnitude × phase-mask^n)
  // ============================================================
  M.swipipe={ready:false,animated:false,cv:null,x:null,W:960,H:470,n:4,
    veins:[[0.30,0.35,0.05],[0.62,0.55,0.045],[0.45,0.72,0.055],[0.72,0.30,0.04]],
    init(root){ this.cv=root.querySelector('#cv-sp'); this.x=fit(this.cv,this.W,this.H);
      this.sl=root.querySelector('#sp-n'); this.slo=root.querySelector('#sp-no');
      this.sl.oninput=()=>{ this.n=+this.sl.value; this.slo.textContent='n = '+this.n; this.draw(); }; this.slo.textContent='n = '+this.n;
      this.draw(); },
    magAt(u,v){ let m=0.72; // background brain
      for(const b of this.veins){ const r=Math.hypot(u-b[0],v-b[1]); if(r<b[2]) m=0.18; } // vessel signal void
      return m; },
    phaseAt(u,v){ let p=0; for(const b of this.veins){ const dx=u-b[0],dy=v-b[1]; const r=Math.hypot(dx,dy);
      if(r<b[2]) p+=-2.4; else { const cos=dy/(r||1); p+=-(3*cos*cos-1)*Math.pow(b[2]/r,2)*0.5; } } return wrapPhase(p); },
    pmask(phi){ if(phi<0 && phi>-Math.PI) return (Math.PI+phi)/Math.PI; return 1; },
    panel(x,X,Y,S,kind){ const img=this.x.createImageData(S,S); const d=img.data;
      for(let j=0;j<S;j++)for(let i=0;i<S;i++){ const u=i/S,v=j/S; let g; let rgb=null;
        const mag=this.magAt(u,v), ph=this.phaseAt(u,v);
        if(kind==='mag'){ g=mag; }
        else if(kind==='phase'){ rgb=phaseRGB(ph); }
        else if(kind==='mask'){ g=this.pmask(ph); }
        else { g=mag*Math.pow(this.pmask(ph),this.n); } // SWI
        const k=(j*S+i)*4;
        if(rgb){ d[k]=rgb[0];d[k+1]=rgb[1];d[k+2]=rgb[2]; } else { const gg=Math.round(clamp(g,0,1)*255); d[k]=d[k+1]=d[k+2]=gg; }
        d[k+3]=255; }
      x.putImageData(img,X,Y); x.strokeStyle='#c3c8cf'; x.strokeRect(X,Y,S,S); },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H);
      T(x,'SWI = magnitude × (fasemaske)ⁿ',W/2,26,{size:16,col:C.ink,weight:'bold',align:'center'});
      const S=180, y=64, xs=[40,280,520]; const lab=['Magnitude','Fase','Fasemaske'];
      const kinds=['mag','phase','mask'];
      for(let k=0;k<3;k++){ this.panel(x,xs[k],y,S,kinds[k]); T(x,lab[k],xs[k]+S/2,y-8,{size:12.5,col:C.ink,weight:'bold',align:'center'}); }
      // multiply arrow → SWI
      T(x,'×  ↑ⁿ  =',xs[2]+S+8,y+S/2,{size:15,col:C.ink,weight:'bold'});
      this.panel(x,740,y,S,'swi'); T(x,'SWI',740+S/2,y-8,{size:13,col:C.red,weight:'bold',align:'center'});
      wrapText(x,'Fasen bærer susceptibilitetsinformasjon. En fasemaske (negativ fase → 0…1) opphøyes i n (typisk 4) og multipliseres inn i magnitudebildet → årer og jern blir mørkere og mye tydeligere.',40,y+S+40,W-80,18,{size:13,col:C.ink});
      T(x,'Dra n: høyere n = sterkere susceptibilitetskontrast (men mer støyfølsomt).',40,y+S+40+46,{size:12.5,col:C.blue,weight:'bold'}); }
  };

  // ============================================================
  // 3. minimum Intensity Projection (mIP) — venography
  // ============================================================
  M.mip={ready:false,animated:true,cv:null,x:null,W:960,H:470,nSlices:1,auto:true,t:0,last:null,
    init(root){ this.cv=root.querySelector('#cv-mp'); this.x=fit(this.cv,this.W,this.H);
      // build 8 slices, each with a few vein segments (dark) at different positions
      this.slices=[]; const rnd=(s=>()=>{ s=(s*1103515245+12345)&0x7fffffff; return s/0x7fffffff; })(7);
      this.vseg=[]; for(let s=0;s<8;s++){ const segs=[]; const nseg=2+Math.floor(rnd()*2);
        for(let k=0;k<nseg;k++){ segs.push({x0:rnd(),y0:rnd(),x1:rnd(),y1:rnd(),w:0.01+rnd()*0.012}); } this.vseg.push(segs); }
      this.sl=root.querySelector('#mp-n'); this.slo=root.querySelector('#mp-no');
      if(this.sl){ this.sl.oninput=()=>{ this.auto=false; this.nSlices=+this.sl.value; this.slo.textContent=this.nSlices+' snitt'; this.draw(); }; }
      this.render(); },
    sliceImg(count){ const S=this.S=300; const buf=new Float32Array(S*S).fill(0.85);
      for(let s=0;s<count;s++){ for(const seg of this.vseg[s]){ // draw dark segment
        const steps=60; for(let t=0;t<=steps;t++){ const f=t/steps; const px=(seg.x0+(seg.x1-seg.x0)*f)*S, py=(seg.y0+(seg.y1-seg.y0)*f)*S; const rad=seg.w*S;
          for(let jj=-rad;jj<=rad;jj++)for(let ii=-rad;ii<=rad;ii++){ const xi=Math.round(px+ii),yi=Math.round(py+jj); if(xi<0||yi<0||xi>=S||yi>=S)continue; if(ii*ii+jj*jj<=rad*rad){ const idx=yi*S+xi; buf[idx]=Math.min(buf[idx],0.12); } } } } }
      return buf; },
    render(){ this.buf=this.sliceImg(this.nSlices); this.draw(); },
    tick(t){ if(this.last==null)this.last=t; const dt=Math.min(0.05,t-this.last); this.last=t;
      if(this.auto){ this.t+=dt; const target=1+Math.floor((this.t%9)/9*8); if(target!==this.nSlices){ this.nSlices=clamp(target,1,8); if(this.sl){this.sl.value=this.nSlices; this.slo.textContent=this.nSlices+' snitt';} this.render(); } }
      else this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x||!this.buf)return; x.clearRect(0,0,W,H);
      T(x,'Minimum-intensitetsprojeksjon (mIP) — venografi',W/2,28,{size:16,col:C.ink,weight:'bold',align:'center'});
      const S=this.S, X=60,Y=70; const img=x.createImageData(S,S); const d=img.data;
      for(let p=0;p<S*S;p++){ const g=Math.round(this.buf[p]*255); d[p*4]=d[p*4+1]=d[p*4+2]=g; d[p*4+3]=255; }
      x.putImageData(img,X,Y); x.strokeStyle='#c3c8cf'; x.strokeRect(X,Y,S,S);
      T(x,'projeksjon over '+this.nSlices+' snitt',X+S/2,Y+S+22,{size:13,col:C.ink,weight:'bold',align:'center'});
      // slice stack schematic (right)
      const sx=460,sy=110; for(let s=0;s<8;s++){ const on=s<this.nSlices; x.globalAlpha=on?1:0.25;
        x.strokeStyle=on?C.blue:'#c3c8cf'; x.lineWidth=on?2:1; x.strokeRect(sx+s*8,sy+s*10,150,60); x.globalAlpha=1; }
      T(x,'3D-stabel av tynne snitt',sx,sy-14,{size:12.5,col:C.mut,weight:'bold'});
      wrapText(x,'Hvert snitt fanger biter av årene. Ved å ta MINIMUM langs stabelen kobles de mørke bitene sammen til et sammenhengende venekart — som en venografi, uten kontrastmiddel.',460,Y+S-40,W-500,18,{size:13,col:C.ink});
      T(x, this.auto?'(spilles automatisk — dra glidebryteren for å styre selv)':'Dra for å endre antall snitt.',460,H-24,{size:12.5,col:C.blue,weight:'bold'}); }
  };

  // ============================================================
  // 4. PARAMAGNETIC vs DIAMAGNETIC  (microbleed vs calcification)
  // ============================================================
  M.paramag={ready:false,animated:false,cv:null,x:null,W:960,H:470,
    init(root){ this.cv=root.querySelector('#cv-pm'); this.x=fit(this.cv,this.W,this.H); this.draw(); },
    panel(x,X,Y,S,sign){ const R=S*0.16, img=this.x.createImageData(S,S), d=img.data;
      for(let j=0;j<S;j++)for(let i=0;i<S;i++){ const dx=i-S/2,dy=j-S/2,r=Math.hypot(dx,dy); let rgb;
        if(r<R){ rgb=[40,40,46]; } else { const cos=dy/r; const f=sign*(3*cos*cos-1)*Math.pow(R/r,3); rgb=phaseRGB(wrapPhase(-f*2.2)); }
        const k=(j*S+i)*4; d[k]=rgb[0];d[k+1]=rgb[1];d[k+2]=rgb[2];d[k+3]=255; }
      x.putImageData(img,X,Y); x.strokeStyle='#c3c8cf'; x.strokeRect(X,Y,S,S); },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H);
      T(x,'Para- vs diamagnetisk: fasetegnet skiller dem',W/2,28,{size:16,col:C.ink,weight:'bold',align:'center'});
      const S=250;
      this.panel(x,90,64,S,+1); T(x,'Mikroblødning (paramagnetisk, χ>0)',90+S/2,54,{size:13,col:C.red,weight:'bold',align:'center'});
      this.panel(x,560,64,S,-1); T(x,'Forkalkning (diamagnetisk, χ<0)',560+S/2,54,{size:13,col:C.blue,weight:'bold',align:'center'});
      T(x,'fasemønsteret vrir seg MOTSATT vei',W/2,64+S+22,{size:13.5,col:C.purple,weight:'bold',align:'center'});
      wrapText(x,'På magnitude/T2* ser en blødning og en forkalkning nesten like ut (begge mørke). Men susceptibiliteten har MOTSATT fortegn → fasebildet vrir seg motsatt vei.',60,64+S+52,W-120,18,{size:13,col:C.ink});
      wrapText(x,'Derfor kan SWI-fasen (med riktig venstre/høyre-håndskonvensjon) SKILLE blødning fra kalk — klinisk svært nyttig.',60,64+S+52+42,W-120,18,{size:13,col:C.blue,weight:'bold'}); }
  };

  // ============================================================
  // 5. MICROBLEED SENSITIVITY  (SWI vs GRE-T2*)  "blooming"
  // ============================================================
  M.microbleed={ready:false,animated:false,cv:null,x:null,W:960,H:470,mode:'swi',
    bleeds:[[0.28,0.34,0.9],[0.55,0.28,0.6],[0.68,0.6,1.0],[0.4,0.62,0.5],[0.75,0.42,0.7],[0.5,0.5,0.35],[0.32,0.7,0.8],[0.62,0.75,0.45]],
    init(root){ this.cv=root.querySelector('#cv-mb'); this.x=fit(this.cv,this.W,this.H);
      root.querySelectorAll('[data-mb]').forEach(b=>{ b.classList.toggle('on',b.dataset.mb===this.mode);
        b.onclick=()=>{ this.mode=b.dataset.mb; root.querySelectorAll('[data-mb]').forEach(q=>q.classList.toggle('on',q===b)); this.draw(); }; });
      this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H);
      T(x,'Mikroblødninger: SWI vs. GRE-T2*',W/2,28,{size:16,col:C.ink,weight:'bold',align:'center'});
      const S=330,X=70,Y=60; const swi=this.mode==='swi';
      // brain background
      const img=x.createImageData(S,S), d=img.data;
      for(let j=0;j<S;j++)for(let i=0;i<S;i++){ const u=(i-S/2)/(S/2),v=(j-S/2)/(S/2); const inside=u*u/0.85+v*v<1;
        let g=inside?0.62:0.09; const k=(j*S+i)*4; d[k]=d[k+1]=d[k+2]=Math.round(g*255); d[k+3]=255; }
      x.putImageData(img,X,Y);
      // bleeds: on SWI they "bloom" (bigger, darker); on T2* small/faint
      let visible=0; const thr=0.5;
      for(const b of this.bleeds){ const cx=X+b[0]*S, cy=Y+b[1]*S; const strength=b[2];
        const rad=swi? (6+strength*10) : (2+strength*3); const dark=swi? 0.92 : (strength*0.5);
        x.fillStyle='rgba(10,10,14,'+clamp(dark,0,1)+')'; x.beginPath(); x.arc(cx,cy,rad,0,TAU); x.fill();
        if((swi?dark:strength*0.5)>=thr-0.15) visible++; }
      x.strokeStyle='#c3c8cf'; x.strokeRect(X,Y,S,S);
      T(x, swi?'SWI':'GRE-T2*', X+S/2, Y-8,{size:14,col:swi?C.red:C.blue,weight:'bold',align:'center'});
      // count panel
      const px=460; T(x,'Påvisbare mikroblødninger',px,110,{size:14,col:C.ink,weight:'bold'});
      T(x, (swi?'~8 / 8':'~4 / 8')+' synlige', px,144,{size:22,col:swi?C.green:C.amber,weight:'bold'});
      wrapText(x, swi
        ? 'SWI kombinerer magnitude og fase → mikroblødninger «blomstrer» (blooming): større, mørkere og lettere å telle. Høyest sensitivitet.'
        : 'GRE-T2* ser blødningene svakt. De minste forsvinner i bakgrunnen → man underestimerer antallet.',
        px,170,W-px-40,19,{size:13.5,col:C.ink});
      wrapText(x,'Klinisk: diffus aksonal skade (traume), cerebral amyloid angiopati, kavernomer — SWI finner flere lesjoner enn T2*.',px,260,W-px-40,19,{size:13,col:C.blue,weight:'bold'});
      T(x,'Bytt sekvens med knappene under.',px,H-24,{size:12.5,col:C.mut}); }
  };

  window.runViz=function(name){ const m=M[name]; if(!m){console.error('unknown viz',name);return;}
    try{ m.init(document); m.ready=true; }catch(e){ console.error(e); }
    if(m.animated && m.tick){ (function loop(ts){ m.tick((ts||0)/1000); requestAnimationFrame(loop); })(); }
    window.addEventListener('resize',function(){ if(!m.cv)return; m.x=fit(m.cv,m.W,m.H); if(!m.animated && m.draw) m.draw(); }); };
  window.__swi={M,wrapPhase};
})();
