
(function(){
  "use strict";
  const F="'DejaVu Sans', Verdana, sans-serif";
  const C={blue:'#2F5FA8',red:'#C0392B',purple:'#5d3a8e',orange:'#b54a16',green:'#10b981',
           ink:'#1f2430',mut:'#9aa2ad',grid:'#eef1f4'};
  // ---------- tiny 2D helpers ----------
  function fit(cv,w,h){ const dpr=Math.max(1,Math.min(2.5,window.devicePixelRatio||1));
    cv.width=w*dpr; cv.height=h*dpr; cv.style.aspectRatio=w+'/'+h;
    const x=cv.getContext('2d'); x.setTransform(dpr,0,0,dpr,0,0); return x; }
  function T(x,s,px,py,o){ o=o||{}; x.globalAlpha=1; x.fillStyle=o.col||C.ink;
    x.font=(o.weight||'normal')+' '+(o.size||14)+'px '+F; x.textAlign=o.align||'left';
    x.textBaseline=o.base||'alphabetic'; x.fillText(s,px,py); }
  function L(x,a,b,c,d,col,w,dash){ x.strokeStyle=col; x.lineWidth=w||1; x.globalAlpha=1;
    x.setLineDash(dash||[]); x.beginPath(); x.moveTo(a,b); x.lineTo(c,d); x.stroke(); x.setLineDash([]); }
  const clamp=(v,a,b)=>v<a?a:(v>b?b:v);
  const comma=v=>v.toFixed(1).replace('.',',');

  // =========================================================
  // MODULES
  // =========================================================
  const M={};

  // ---- title background: gentle flowing sine ----
  M.title={ready:false,animated:true,cv:null,x:null,W:880,H:180,
    init(root){ this.cv=root.querySelector('#cv-title'); this.x=fit(this.cv,this.W,this.H); },
    tick(t){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H);
      const mid=H/2;
      for(let s=0;s<3;s++){ const A=[30,20,12][s], f=[1,2,3][s], sp=[0.6,-0.9,1.3][s];
        const col=[C.blue,C.purple,C.red][s];
        x.strokeStyle=col; x.globalAlpha=[0.9,0.55,0.4][s]; x.lineWidth=[2.6,2,1.6][s]; x.beginPath();
        for(let px=10;px<=W-10;px++){ const ph=2*Math.PI*f*(px-10)/(W-20)+t*sp;
          const y=mid - A*Math.sin(ph); px===10?x.moveTo(px,y):x.lineTo(px,y);} x.stroke(); }
      x.globalAlpha=1; T(x,'signal  =  Σ  rene bølger', W/2, H-16,{col:C.mut,size:15,align:'center'}); }
  };

  // ---- prism: composite wave -> prism -> component waves ----
  M.prism={ready:false,animated:false,cv:null,x:null,W:920,H:320,
    init(root){ this.cv=root.querySelector('#cv-prism'); this.x=fit(this.cv,this.W,this.H); this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H);
      // left: composite wave in a box
      const bx=30,by=70,bw=250,bh=180;
      x.fillStyle='#fff'; x.strokeStyle=C.grid; x.lineWidth=1; x.strokeRect(bx,by,bw,bh);
      x.strokeStyle=C.ink; x.lineWidth=2.2; x.beginPath();
      for(let i=0;i<=bw;i++){ const u=i/bw; const y=by+bh/2 -
        30*Math.sin(2*Math.PI*1*u) -18*Math.sin(2*Math.PI*3*u+1) -10*Math.sin(2*Math.PI*6*u);
        i?x.lineTo(bx+i,y):x.moveTo(bx+i,y);} x.stroke();
      T(x,'sammensatt signal',bx+bw/2,by-12,{col:C.mut,size:14,align:'center'});
      // arrow into prism
      L(x,bx+bw+6,H/2,bx+bw+52,H/2,C.blue,2.4); 
      // prism triangle
      const px0=bx+bw+60, cx=px0+70, cy=H/2;
      x.fillStyle='rgba(47,95,168,0.10)'; x.strokeStyle=C.blue; x.lineWidth=2;
      x.beginPath(); x.moveTo(cx,cy-70); x.lineTo(cx-52,cy+58); x.lineTo(cx+52,cy+58); x.closePath(); x.fill(); x.stroke();
      T(x,'Fourier',cx,cy+40,{col:C.blue,size:14,align:'center',weight:'bold'});
      // component waves (right lanes)
      const lx=cx+70, lw=250; const cols=[C.blue,C.purple,C.red]; const fr=[1,2,4]; const labs=['lav frekvens','middels','høy frekvens'];
      for(let s=0;s<3;s++){ const ly=90+s*75;
        L(x,cx+56,cy + (s-1)*22, lx-6, ly,cols[s],1.6,[4,3]);
        x.strokeStyle=cols[s]; x.lineWidth=2; x.beginPath();
        for(let i=0;i<=lw;i++){ const u=i/lw; const y=ly-18*Math.sin(2*Math.PI*fr[s]*u);
          i?x.lineTo(lx+i,y):x.moveTo(lx+i,y);} x.stroke();
        T(x,labs[s],lx+lw+4,ly+4,{col:cols[s],size:12.5,weight:'bold'}); }
    }
  };

  // ---- sine from rotating circle ----
  M.sine={ready:false,animated:true,cv:null,x:null,W:920,H:340,fEl:null,aEl:null,
    init(root){ this.cv=root.querySelector('#cv-sine'); this.x=fit(this.cv,this.W,this.H);
      this.fEl=root.querySelector('#s-freq'); this.aEl=root.querySelector('#s-amp');
      const fo=root.querySelector('#s-freqo'), ao=root.querySelector('#s-ampo');
      const upd=()=>{ fo.textContent=comma(+this.fEl.value); ao.textContent=comma(+this.aEl.value); };
      this.fEl.oninput=upd; this.aEl.oninput=upd; upd(); },
    tick(t){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H);
      const f=+this.fEl.value, amp=+this.aEl.value;
      const ccx=165, ccy=170, r=118, R=r*amp;
      const th=2*Math.PI*f*0.32*t;
      // circle
      x.strokeStyle=C.grid; x.lineWidth=1.4; x.beginPath(); x.arc(ccx,ccy,r,0,7); x.stroke();
      L(x,ccx-r-6,ccy,ccx+r+6,ccy,'#eef1f4',1); L(x,ccx,ccy-r-6,ccx,ccy+r+6,'#eef1f4',1);
      const Px=ccx+R*Math.cos(th), Py=ccy-R*Math.sin(th);
      L(x,ccx,ccy,Px,Py,C.blue,2.4);                       // radius vector
      x.fillStyle=C.blue; x.beginPath(); x.arc(Px,Py,5,0,7); x.fill();
      // wave window (unwraps to the right as the point rotates)
      const wx0=330, wx1=900, base=ccy, cyc=f;
      x.strokeStyle=C.blue; x.lineWidth=2.4; x.beginPath();
      for(let xp=wx0;xp<=wx1;xp++){ const ph=th - 2*Math.PI*cyc*(xp-wx0)/(wx1-wx0);
        const y=base - R*Math.sin(ph); xp===wx0?x.moveTo(xp,y):x.lineTo(xp,y);} x.stroke();
      // marker at the left edge = current projection (sits on the curve)
      const my=base-R*Math.sin(th);
      L(x,Px,Py,wx0,my,'rgba(47,95,168,0.5)',1.5,[5,4]);
      x.fillStyle=C.red; x.beginPath(); x.arc(wx0,my,5,0,7); x.fill();
      // labels
      T(x,'amplitude',ccx+R*0.5*Math.cos(th)-2,ccy-R*0.5*Math.sin(th)-8,{col:C.blue,size:12,weight:'bold'});
      T(x,'sinusbølge',wx0+6,base+R+26,{col:C.blue,size:13,weight:'bold'});
      T(x,'høyde = sin θ',wx1-4,42,{col:C.mut,size:12,align:'end'});
    }
  };

  // ---- build square wave from harmonics ----
  M.build={ready:false,animated:false,cv:null,x:null,W:920,H:380,nEl:null,
    init(root){ this.cv=root.querySelector('#cv-build'); this.x=fit(this.cv,this.W,this.H);
      this.nEl=root.querySelector('#b-n'); const no=root.querySelector('#b-no');
      this.nEl.oninput=()=>{ no.textContent=this.nEl.value; this.draw(); }; no.textContent=this.nEl.value; this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H);
      const N=+this.nEl.value, x0=64,x1=900, base=H/2, A=125, TT=4*Math.PI, NS=1200;
      // ideal square (dashed)
      x.strokeStyle='#c7ccd3'; x.lineWidth=1.3; x.setLineDash([5,4]); x.beginPath();
      for(let i=0;i<=NS;i++){ const t=TT*i/NS, v=Math.sign(Math.sin(t)||1), xp=x0+(x1-x0)*i/NS, y=base-A*v;
        i?x.lineTo(xp,y):x.moveTo(xp,y);} x.stroke(); x.setLineDash([]);
      // individual harmonics (faint, first up to 6)
      const cols=[C.blue,C.purple,C.orange,C.green,'#8a6d3b','#3b8a86'];
      let hk=0; for(let k=1;k<=2*N-1 && hk<6;k+=2,hk++){ x.strokeStyle=cols[hk]; x.globalAlpha=0.32; x.lineWidth=1.3; x.beginPath();
        for(let i=0;i<=NS;i++){ const t=TT*i/NS, v=(4/Math.PI)*(1/k)*Math.sin(k*t), xp=x0+(x1-x0)*i/NS, y=base-A*v;
          i?x.lineTo(xp,y):x.moveTo(xp,y);} x.stroke(); }
      x.globalAlpha=1;
      // partial sum (bold red)
      x.strokeStyle=C.red; x.lineWidth=2.6; x.beginPath();
      for(let i=0;i<=NS;i++){ const t=TT*i/NS; let s=0; for(let k=1;k<=2*N-1;k+=2) s+=(4/Math.PI)*(1/k)*Math.sin(k*t);
        const xp=x0+(x1-x0)*i/NS, y=base-A*s; i?x.lineTo(xp,y):x.moveTo(xp,y);} x.stroke();
      L(x,x0,base,x1,base,'#e0e4e9',1);
      T(x,'n = '+N+' ledd',x1,30,{col:C.red,size:15,align:'end',weight:'bold'});
      T(x,'ideell firkant',x0+4,30,{col:C.mut,size:13});
    }
  };

  // ---- axes: orthogonal independent directions ----
  M.axes={ready:false,animated:false,cv:null,x:null,W:460,H:340,
    init(root){ this.cv=root.querySelector('#cv-axes'); this.x=fit(this.cv,this.W,this.H); this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H); const ox=90,oy=250, ax=300, ay=200;
      // axes
      L(x,ox,oy,ox+ax,oy,C.blue,2); L(x,ox,oy,ox,oy-ay,C.blue,2);
      T(x,'øst',ox+ax+2,oy+4,{col:C.blue,size:13,weight:'bold'});
      T(x,'nord',ox-6,oy-ay-6,{col:C.blue,size:13,weight:'bold',align:'start'});
      // right-angle mark
      L(x,ox+16,oy,ox+16,oy-16,C.blue,1); L(x,ox,oy-16,ox+16,oy-16,C.blue,1);
      // a point/vector
      const vx=ox+200, vy=oy-150;
      L(x,ox,oy,vx,vy,C.red,2.4); x.fillStyle=C.red; x.beginPath(); x.arc(vx,vy,5,0,7); x.fill();
      // components (dashed)
      L(x,vx,vy,vx,oy,C.purple,1.6,[5,4]); L(x,vx,vy,ox,vy,C.orange,1.6,[5,4]);
      x.fillStyle=C.purple; x.beginPath(); x.arc(vx,oy,4,0,7); x.fill();
      x.fillStyle=C.orange; x.beginPath(); x.arc(ox,vy,4,0,7); x.fill();
      T(x,'øst-del',(ox+vx)/2,oy+18,{col:C.purple,size:12,align:'center',weight:'bold'});
      T(x,'nord-del',ox-6,(oy+vy)/2,{col:C.orange,size:12,align:'end',weight:'bold'});
      T(x,'uavhengige akser',W/2,26,{col:C.mut,size:13,align:'center'});
    }
  };

  // ---- orthogonality / resonance detector ----
  M.ortho={ready:false,animated:false,cv:null,x:null,W:920,H:470,fEl:null,
    sig(u){ return Math.sin(2*Math.PI*3*u)+0.7*Math.sin(2*Math.PI*5*u); },
    init(root){ this.cv=root.querySelector('#cv-ortho'); this.x=fit(this.cv,this.W,this.H);
      this.fEl=root.querySelector('#o-f'); const fo=root.querySelector('#o-fo');
      this.fEl.oninput=()=>{ fo.textContent=comma(+this.fEl.value); this.draw(); }; fo.textContent=comma(+this.fEl.value); this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H);
      const f=+this.fEl.value, x0=70,x1=900, NS=900;
      const rows=[{b:70,A:44,col:C.blue,lab:'Signal (blanding av 3 og 5)',fn:u=>this.sig(u)/1.7},
                  {b:180,A:38,col:C.purple,lab:'Testbølge (frekvens f)',fn:u=>Math.sin(2*Math.PI*f*u)},
                  {b:300,A:44,col:C.red,lab:'Produkt (signal × testbølge)',fn:u=>this.sig(u)*Math.sin(2*Math.PI*f*u)/1.7,fill:true}];
      for(const r of rows){ L(x,x0,r.b,x1,r.b,'#e8ebef',1);
        if(r.fill){ x.beginPath(); x.moveTo(x0,r.b);
          for(let i=0;i<=NS;i++){ const u=i/NS, xp=x0+(x1-x0)*u, y=r.b-r.A*r.fn(u); x.lineTo(xp,y);}
          x.lineTo(x1,r.b); x.closePath(); x.fillStyle='rgba(192,57,43,0.14)'; x.fill(); }
        x.strokeStyle=r.col; x.lineWidth=2.2; x.beginPath();
        for(let i=0;i<=NS;i++){ const u=i/NS, xp=x0+(x1-x0)*u, y=r.b-r.A*r.fn(u); i?x.lineTo(xp,y):x.moveTo(xp,y);} x.stroke();
        T(x,r.lab,x0,r.b-r.A-8,{col:r.col,size:13,weight:'bold'}); }
      // correlation
      let Cc=0; for(let i=0;i<NS;i++){ const u=(i+0.5)/NS; Cc+=this.sig(u)*Math.sin(2*Math.PI*f*u);} Cc/=NS;
      // meter
      const my=420, mcx=W/2, half=300;
      L(x,x0,my,x1,my,'#e8ebef',1); L(x,mcx,my-24,mcx,my+24,'#c7ccd3',1.4);
      const val=clamp(Cc/0.55,-1,1), bw=val*half;
      x.fillStyle = Math.abs(Cc)>0.2?C.green:'#b7bcc4';
      x.fillRect(Math.min(mcx,mcx+bw),my-13,Math.abs(bw),26);
      T(x,'Match = snitt av produktet',x0,my-30,{col:C.ink,size:13,weight:'bold'});
      T(x,(Cc>=0?'+':'')+Cc.toFixed(2),mcx+bw+(bw>=0?8:-8),my+5,{col:C.ink,size:14,weight:'bold',align:bw>=0?'start':'end'});
      T(x, Math.abs(Cc)>0.2?'resonans!':'≈ 0 (ortogonalt)', mcx, my+40,{col:Math.abs(Cc)>0.2?C.green:C.mut,size:13,align:'center',weight:'bold'});
    }
  };

  // ---- signal <-> spectrum ----
  M.spectrum={ready:false,animated:false,cv:null,x:null,W:920,H:400,amps:[1,0,0.5,0],els:[],
    init(root){ this.cv=root.querySelector('#cv-spec'); this.x=fit(this.cv,this.W,this.H);
      const host=root.querySelector('#spec-sliders'); this.els=[];
      for(let k=0;k<4;k++){ const d=document.createElement('div'); d.className='ctrl';
        d.innerHTML='f='+(k+1)+' <input type="range" min="0" max="1" step="0.05" value="'+this.amps[k]+'">';
        const inp=d.querySelector('input'); inp.oninput=()=>{ this.amps[k]=+inp.value; this.draw(); };
        this.els.push(inp); host.appendChild(d); }
      root.querySelectorAll('[data-preset]').forEach(b=>b.onclick=()=>{ const p=b.dataset.preset;
        const set = p==='pure'?[1,0,0,0] : p==='two'?[0,1,0,0.7] : [1,0,0.33,0];
        this.amps=set.slice(); this.els.forEach((e,i)=>e.value=this.amps[i]); this.draw(); });
      this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H);
      const x0=70,x1=900, sBase=120, sA=72, NS=900;
      T(x,'Signal (tid)',x0,30,{col:C.red,size:13,weight:'bold'});
      L(x,x0,sBase,x1,sBase,'#e8ebef',1);
      x.strokeStyle=C.red; x.lineWidth=2.4; x.beginPath();
      for(let i=0;i<=NS;i++){ const u=i/NS; let s=0; for(let k=0;k<4;k++) s+=this.amps[k]*Math.sin(2*Math.PI*(k+1)*u);
        const xp=x0+(x1-x0)*u, y=sBase-sA*s/2.2; i?x.lineTo(xp,y):x.moveTo(xp,y);} x.stroke();
      // spectrum
      const bBase=360, bMax=150; T(x,'Spekter (frekvens) — «oppskriften»',x0,236,{col:C.blue,size:13,weight:'bold'});
      L(x,x0,bBase,x1,bBase,'#c7ccd3',1.5);
      for(let k=0;k<4;k++){ const cx=x0+(x1-x0)*(k+0.5)/4, bw=54, h=this.amps[k]*bMax;
        x.fillStyle=C.blue; x.globalAlpha=0.85; x.fillRect(cx-bw/2,bBase-h,bw,h); x.globalAlpha=1;
        T(x,'f='+(k+1),cx,bBase+18,{col:C.mut,size:12.5,align:'center'});
        T(x,this.amps[k].toFixed(2),cx,bBase-h-6,{col:C.blue,size:12,align:'center',weight:'bold'}); }
    }
  };

  // ---- time vs frequency illustration ----
  M.domains={ready:false,animated:false,cv:null,x:null,W:460,H:360,
    init(root){ this.cv=root.querySelector('#cv-domains'); this.x=fit(this.cv,this.W,this.H); this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H);
      // messy time signal (tone + noise)
      const x0=30,x1=430; let seed=7; const rnd=()=>{ seed=(seed*9301+49297)%233280; return seed/233280-0.5; };
      T(x,'Tid: rotete signal',x0,26,{col:C.ink,size:13,weight:'bold'});
      L(x,x0,110,x1,110,'#e8ebef',1);
      x.strokeStyle=C.ink; x.lineWidth=1.6; x.beginPath();
      for(let i=0;i<=400;i++){ const u=i/400; const y=110 -30*Math.sin(2*Math.PI*4*u) -34*rnd();
        i?x.lineTo(x0+i,y):x.moveTo(x0+i,y);} x.stroke();
      // spectrum reveals the hidden tone
      T(x,'Frekvens: skjult topp',x0,206,{col:C.blue,size:13,weight:'bold'});
      const bBase=330; L(x,x0,bBase,x1,bBase,'#c7ccd3',1.5);
      // noise floor bars + one big peak at f=4
      let s2=3; const rn=()=>{ s2=(s2*9301+49297)%233280; return s2/233280; };
      for(let k=0;k<26;k++){ const cx=x0+8+k*15.4; const h = (k===7)? 120 : 6+rn()*14;
        x.fillStyle = k===7?C.blue:'#c4cad2'; x.fillRect(cx-4,bBase-h,8,h); }
      T(x,'ekte tone',x0+8+7*15.4,bBase-128,{col:C.blue,size:12,align:'center',weight:'bold'});
    }
  };

  // ---- MRI: k-space <-> image (real FFT) ----
  M.mri={ready:false,animated:false,cv:null,x:null,W:920,H:420,rEl:null,n:128,kr:null,ki:null,ksImg:null,oimg:null,oks:null,
    fft(re,im,inv){ const n=re.length;
      for(let i=1,j=0;i<n;i++){ let bit=n>>1; for(;j&bit;bit>>=1) j^=bit; j^=bit;
        if(i<j){ const t=re[i];re[i]=re[j];re[j]=t; const u=im[i];im[i]=im[j];im[j]=u; } }
      for(let len=2;len<=n;len<<=1){ const ang=(inv?2:-2)*Math.PI/len, wr=Math.cos(ang), wi=Math.sin(ang);
        for(let i=0;i<n;i+=len){ let cr=1,ci=0;
          for(let k=0;k<len/2;k++){ const a=i+k,b=i+k+len/2;
            const vr=re[b]*cr-im[b]*ci, vi=re[b]*ci+im[b]*cr;
            re[b]=re[a]-vr; im[b]=im[a]-vi; re[a]+=vr; im[a]+=vi;
            const t=cr*wr-ci*wi; ci=cr*wi+ci*wr; cr=t; } } }
      if(inv) for(let i=0;i<n;i++){ re[i]/=n; im[i]/=n; } },
    fft2(re,im,inv){ const n=this.n, tr=new Float64Array(n), ti=new Float64Array(n);
      for(let y=0;y<n;y++){ const o=y*n; for(let k=0;k<n;k++){tr[k]=re[o+k];ti[k]=im[o+k];} this.fft(tr,ti,inv);
        for(let k=0;k<n;k++){re[o+k]=tr[k];im[o+k]=ti[k];} }
      for(let xx=0;xx<n;xx++){ for(let y=0;y<n;y++){tr[y]=re[y*n+xx];ti[y]=im[y*n+xx];} this.fft(tr,ti,inv);
        for(let y=0;y<n;y++){re[y*n+xx]=tr[y];im[y*n+xx]=ti[y];} } },
    phantom(){ const n=this.n, img=new Float64Array(n*n);
      const E=(cx,cy,ax,ay,v)=>{ for(let y=0;y<n;y++)for(let x=0;x<n;x++){ const dx=(x-cx)/ax,dy=(y-cy)/ay;
        if(dx*dx+dy*dy<=1) img[y*n+x]+=v; }};
      E(64,64,46,54,0.5); E(64,64,40,48,0.15); E(50,60,10,16,-0.25); E(78,60,10,16,-0.25);
      E(64,92,7,7,0.35); E(64,50,2.2,2.2,0.6); E(58,44,1.6,1.6,0.6); E(70,44,1.6,1.6,0.6);
      let mx=0; for(const v of img) mx=Math.max(mx,v); for(let i=0;i<img.length;i++) img[i]=Math.max(0,img[i])/mx; return img; },
    init(root){ this.cv=root.querySelector('#cv-mri'); this.x=fit(this.cv,this.W,this.H);
      this.rEl=root.querySelector('#m-r'); const ro=root.querySelector('#m-ro');
      const n=this.n; const img=this.phantom();
      this.kr=Float64Array.from(img); this.ki=new Float64Array(n*n); this.fft2(this.kr,this.ki,false);
      // display k-space (log mag, fftshifted)
      this.ksImg=new Uint8ClampedArray(n*n*4); let mmax=0;
      const mag=new Float64Array(n*n);
      for(let y=0;y<n;y++)for(let x=0;x<n;x++){ const v=Math.log(1+Math.hypot(this.kr[y*n+x],this.ki[y*n+x]));
        mag[y*n+x]=v; if(v>mmax)mmax=v; }
      for(let y=0;y<n;y++)for(let x=0;x<n;x++){ const sy=(y+n/2)%n, sx=(x+n/2)%n; // shift DC to center
        const g=Math.round(255*mag[sy*n+sx]/mmax); const o=(y*n+x)*4;
        this.ksImg[o]=g;this.ksImg[o+1]=g;this.ksImg[o+2]=g;this.ksImg[o+3]=255; }
      this.oimg=document.createElement('canvas'); this.oimg.width=n; this.oimg.height=n;
      this.oks=document.createElement('canvas'); this.oks.width=n; this.oks.height=n;
      this.oks.getContext('2d').putImageData(new ImageData(this.ksImg,n,n),0,0);
      this.rEl.oninput=()=>{ ro.textContent=this.rEl.value; this.draw(); }; ro.textContent=this.rEl.value; this.draw(); },
    reconstruct(R){ const n=this.n, rr=new Float64Array(n*n), ii=new Float64Array(n*n);
      for(let y=0;y<n;y++){ const fy=y<n/2?y:y-n; for(let x=0;x<n;x++){ const fx=x<n/2?x:x-n;
        if(fx*fx+fy*fy<=R*R){ rr[y*n+x]=this.kr[y*n+x]; ii[y*n+x]=this.ki[y*n+x]; } } }
      this.fft2(rr,ii,true); const out=new Float64Array(n*n);
      for(let i=0;i<n*n;i++) out[i]=Math.hypot(rr[i],ii[i]); return out; },
    draw(){ const x=this.x,W=this.W,H=this.H,n=this.n; if(!x)return; x.clearRect(0,0,W,H);
      const R=+this.rEl.value; const rec=this.reconstruct(R);
      const id=new ImageData(n,n); for(let i=0;i<n*n;i++){ const g=Math.round(255*clamp(rec[i],0,1));
        id.data[i*4]=g; id.data[i*4+1]=g; id.data[i*4+2]=g; id.data[i*4+3]=255; }
      this.oimg.getContext('2d').putImageData(id,0,0);
      const S=336, ix=44, iy=42, kx=W-S-44, ky=42;
      x.imageSmoothingEnabled=true;
      x.drawImage(this.oimg,ix,iy,S,S); x.drawImage(this.oks,kx,ky,S,S);
      x.strokeStyle=C.grid; x.lineWidth=1; x.strokeRect(ix,iy,S,S); x.strokeRect(kx,ky,S,S);
      T(x,'Bilde (rekonstruert)',ix+S/2,iy-12,{col:C.ink,size:14,align:'center',weight:'bold'});
      T(x,'k-rom (målt)',kx+S/2,ky-12,{col:C.ink,size:14,align:'center',weight:'bold'});
      // dim k-space outside kept disk + bright ring
      const cx=kx+S/2, cy=ky+S/2, rDisk=R/(n/2)*(S/2);
      x.save(); x.beginPath(); x.rect(kx,ky,S,S); x.arc(cx,cy,rDisk,0,7);
      x.fillStyle='rgba(10,12,16,0.55)'; x.fill('evenodd'); x.restore();
      x.strokeStyle=C.orange; x.lineWidth=2; x.beginPath(); x.arc(cx,cy,rDisk,0,7); x.stroke();
      T(x,'brukt: radius '+R,cx,ky+S+18,{col:C.orange,size:12.5,align:'center',weight:'bold'});
    }
  };

  // =========================================================
  // STANDALONE BOOTSTRAP (one module per page, for Quarto iframes)
  // =========================================================
  window.runViz = function(name){
    const m = M[name]; if(!m){ console.error('unknown viz', name); return; }
    try { m.init(document); m.ready = true; } catch(e){ console.error(e); }
    if (m.animated && m.tick){ (function loop(ts){ m.tick((ts||0)/1000); requestAnimationFrame(loop); })(); }
    window.addEventListener('resize', function(){
      if(!m.cv) return; m.x = fit(m.cv, m.W, m.H);
      if(!m.animated && m.draw) m.draw();
    });
  };
})();
