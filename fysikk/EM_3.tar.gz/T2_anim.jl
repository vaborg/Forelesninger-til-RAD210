using Plots

# ---------------------------------------------------------
# Physical parameters
# ---------------------------------------------------------
N      = 10               # number of spins
T2     = 3.0              # T2 relaxation time (arbitrary units, e.g. seconds)
tmax   = 10.0              # total animation time (≈ 3×T2)
nt     = 220              # number of frames

# Each spin has a slightly different precession frequency in the rotating frame.
# A linear spread from -2π to +2π rad/s creates a symmetric dephasing pattern.
Δω = range(-2π, 2π, length=N)

# Time axis
t = range(0, tmax, length=nt)

# ---------------------------------------------------------
# Build animation
# ---------------------------------------------------------
anim = @animate for ti in t
    
    # 1) T2 decay: magnitude of every transverse vector shrinks exponentially
    M = exp(-ti / T2)
    
    # 2) Precession in the rotating frame (x'y'-plane)
    #    At t=0 all spins start along x' (because of the 90° pulse)
    x = M .* cos.(Δω .* ti)   # x' components
    y = M .* sin.(Δω .* ti)   # y' components
    
    # 3) Net magnetization (vector sum / N) – this is the observable signal
    x_net = sum(x) / N
    y_net = sum(y) / N
    
    # ---- Draw frame ----
    plot(xlims=(-1.2, 1.2), ylims=(-1.2, 1.2),
         aspect_ratio = :equal,
         framestyle = :box,
         title = "T₂ Relaxation & Dephasing   (t = $(round(ti, digits=2)))",
         xlabel = "x' (rotating frame)",
         ylabel = "y' (rotating frame)",
         legend = :topright,
         size = (1000, 1000))
    
    # Faint unit circle as a reference
    θ = range(0, 2π, length=100)
    plot!(cos.(θ), sin.(θ), color=:lightgray, lw=1, ls=:dash, label="")
    
    # Individual spin vectors (blue arrows from the origin)
    for j in 1:N
        plot!([0, x[j]], [0, y[j]],
              arrow = true,
              color = :steelblue,
              lw = 2,
              alpha = 0.7,
              label = (j == 1 ? "Individual spins" : ""))
    end
    
    # Net magnetization vector (red) – shows coherence loss as it shrinks
    plot!([0, x_net], [0, y_net],
          arrow = true,
          color = :crimson,
          lw = 4,
          label = "Net Mₓᵧ")
    
    # Annotation: remaining coherence (length of net vector)
    coh = sqrt(x_net^2 + y_net^2)
    annotate!(-1.1, 1.1, text("Coherence = $(round(coh, digits=2))", 10))
end

# ---------------------------------------------------------
# Save GIF
# ---------------------------------------------------------
gif(anim, "t2_spin_dephasing.gif", fps = 15)

println("Animation saved as: t2_spin_dephasing.gif")
