using Plots

# ---------------------------------------------------------
# Parameters
# ---------------------------------------------------------
N        = 20           # number of individual spins shown
T2       = 2.0          # T2 relaxation time (arbitrary units)
tmax     = 6.0          # evolution time after the pulse (≈ 3·T2)
nt_pulse = 30           # animation frames for the RF pulse
nt_evo   = 200          # animation frames for free evolution
nt       = nt_pulse + nt_evo

# Local precession frequencies in the rotating frame (spread causes dephasing)
Δω = range(-2π, 2π, length=N)

# ---------------------------------------------------------
# Animation loop
# ---------------------------------------------------------
anim = @animate for i in 1:nt

    # ==========================================
    # Phase 1 : 90° RF pulse  (z  →  x')
    # ==========================================
    if i <= nt_pulse
        # angle sweeps 0 → π/2
        α = (i - 1) / max(nt_pulse - 1, 1) * (π/2)

        # all spins move identically during the pulse
        x = fill(sin(α), N)
        y = fill(0.0,   N)
        z = fill(cos(α), N)

        x_net = sin(α)
        y_net = 0.0
        z_net = cos(α)

        title_str = "90° Pulse  (θ = $(round(rad2deg(α), digits=1))°)"

    # ==========================================
    # Phase 2 : Free evolution (T2 + dephasing)
    # ==========================================
    else
        # time sweeps 0 → tmax
        t = (i - nt_pulse - 1) / max(nt_evo - 1, 1) * tmax
        M = exp(-t / T2)          # T2 decay of each transverse vector

        x = M .* cos.(Δω .* t)    # x' components
        y = M .* sin.(Δω .* t)    # y' components
        z = fill(0.0, N)          # stays in the transverse plane (T1 ignored)

        x_net = sum(x) / N
        y_net = sum(y) / N
        z_net = 0.0

        title_str = "T₂ Relaxation  (t = $(round(t, digits=2)))"
    end

    # ---- 3D canvas ----
    p = plot3d(xlims=(-1.2, 1.2), ylims=(-1.2, 1.2), zlims=(-1.2, 1.2),
               xlabel = "x'", ylabel = "y'", zlabel = "z'",
               title  = title_str,
               camera = (45, 25),        # nice static viewing angle
               framestyle = :origin,
               legend = :topright, size = (1000, 1000))

    # ---- Reference guides ----
    # z-axis line
    plot3d!([0, 0], [0, 0], [-1.2, 1.2], color=:gray, lw=1, label="")
    # Unit circle in the transverse (x'y') plane
    θ = range(0, 2π, length=100)
    plot3d!(cos.(θ), sin.(θ), zeros(100), color=:lightgray, lw=1, ls=:dash, label="")
    # Arc showing the RF-pulse trajectory in the x'z plane
    θa = range(0, π/2, length=50)
    plot3d!(sin.(θa), zeros(50), cos.(θa), color=:lightblue, lw=1.5, ls=:dash, label="Pulse path")

    # ---- Individual spins (blue) ----
    for j in 1:N
        # shaft
        plot3d!([0, x[j]], [0, y[j]], [0, z[j]],
                color = :steelblue, lw = 2, alpha = 0.7,
                label = (j == 1 ? "Individual spins" : ""))
        # tip marker (acts as arrowhead)
        scatter3d!([x[j]], [y[j]], [z[j]],
                   color = :steelblue, markersize = 3, label = "")
    end

    # ---- Net magnetization (red) ----
    plot3d!([0, x_net], [0, y_net], [0, z_net],
            color = :crimson, lw = 5, label = "Net M")
    scatter3d!([x_net], [y_net], [z_net],
               color = :crimson, markersize = 6, label = "")

    # Show remaining coherence as text
    coh = sqrt(x_net^2 + y_net^2 + z_net^2)
    annotate!(-1.1, 1.1, 1.0, text("Coherence = $(round(coh, digits=2))", 9))

    p
end

# ---------------------------------------------------------
# Save GIF (requires ImageMagick or FFMPEG)
# ---------------------------------------------------------
gif(anim, "t2_relaxation_3d.gif", fps = 15)

println("Done! File saved: t2_relaxation_3d.gif")
