using Plots, Random

# ---------------------------------------------------------
# Physical parameters
# ---------------------------------------------------------
N        = 30               # spins shown
T1       = 3.5              # longitudinal recovery time
T2       = 2.5              # transverse decay time (T2 < T1)
M0       = 1.0              # equilibrium magnetisation
nt_pulse = 30               # frames for the 90° pulse
nt_evo   = 250              # frames for free evolution
nt       = nt_pulse + nt_evo

# Random local precession frequencies (symmetric around 0 in rotating frame)
Random.seed!(42)
Δω = randn(N) .* 2.0        # rad/s

# Evolution time axis (0 → 4·T1)
t_evo = range(0, 4.0 * T1, length=nt_evo)

# ---------------------------------------------------------
# Animation
# ---------------------------------------------------------
anim = @animate for i in 1:nt

    # ========== Phase 1 : 90° RF pulse (z → x') ==========
    if i <= nt_pulse
        α = (i - 1) / max(nt_pulse - 1, 1) * (π / 2)

        x = fill(M0 * sin(α), N)
        y = fill(0.0, N)
        z = fill(M0 * cos(α), N)

        x_net = M0 * sin(α)
        y_net = 0.0
        z_net = M0 * cos(α)

        title_str = "90° RF Pulse   (θ = $(round(rad2deg(α), digits=0))°)"

    # ========== Phase 2 : T1 + T2 relaxation ==========
    else
        t = t_evo[i - nt_pulse]

        Mz      = M0 * (1.0 - exp(-t / T1))     # T1 recovery
        Mxy_amp = M0 * exp(-t / T2)             # T2 decay

        ϕ = Δω .* t
        x = Mxy_amp .* cos.(ϕ)                  # each spin precesses...
        y = Mxy_amp .* sin.(ϕ)
        z = fill(Mz, N)                         # ...while rising in z

        x_net = sum(x) / N
        y_net = sum(y) / N
        z_net = Mz

        title_str = "T₁ & T₂ Relaxation   (t = $(round(t, digits=2)))"
    end

    # ---- 3D canvas ----
    p = plot3d(xlims=(-1.3, 1.3), ylims=(-1.3, 1.3), zlims=(-0.2, 1.3),
               xlabel = "x'", ylabel = "y'", zlabel = "z",
               title  = title_str,
               camera = (35, 25),
               size   = (900, 800),
               framestyle = :box,
               legend = false)

    # ---- Reference geometry ----
    # Equilibrium point on z-axis
    plot3d!([0, 0], [0, 0], [0, M0], color=:black, lw=1, alpha=0.2)
    scatter3d!([0], [0], [M0], color=:black, markersize=2, alpha=0.3)

    # Unit circle on the xy-plane (floor)
    θ = range(0, 2π, length=100)
    plot3d!(cos.(θ), sin.(θ), zeros(100), color=:lightgray, lw=1, ls=:dash)

    # ---- Individual spins ----
    for j in 1:N
        # Actual spin vector (blue)
        plot3d!([0, x[j]], [0, y[j]], [0, z[j]],
                color = :steelblue, lw = 2, alpha = 0.55)

        # Tip marker
        scatter3d!([x[j]], [y[j]], [z[j]],
                   color = :steelblue, markersize = 2, alpha = 0.6)

        # Projection drop-line to the xy floor (grey dotted)
        plot3d!([x[j], x[j]], [y[j], y[j]], [0, z[j]],
                color = :gray, lw = 1, alpha = 0.25, ls = :dot)

        # Shadow / projection on the xy plane (cyan dot)
        scatter3d!([x[j]], [y[j]], [0],
                   color = :cyan, markersize = 3, alpha = 0.45)
    end

    # ---- Net magnetisation vector (thick red) ----
    plot3d!([0, x_net], [0, y_net], [0, z_net],
            color = :crimson, lw = 5)
    scatter3d!([x_net], [y_net], [z_net],
               color = :crimson, markersize = 5)

    # ---- Z-axis projection = T1 recovery (green) ----
    plot3d!([0, 0], [0, 0], [0, z_net],
            color = :green, lw = 6, alpha = 0.8)

    # ---- XY-plane projection = T2 signal (purple) ----
    # Vertical connector for the net vector
    if z_net > 0.005
        plot3d!([x_net, x_net], [y_net, y_net], [0, z_net],
                color = :crimson, lw = 2, alpha = 0.35, ls = :dash)
    end
    # Net transverse component lying on the floor
    plot3d!([0, x_net], [0, y_net], [0, 0],
            color = :purple, lw = 3, alpha = 0.7)
    scatter3d!([x_net], [y_net], [0],
               color = :purple, markersize = 4, alpha = 0.8)

    # ---- Value annotations ----
    Mxy = sqrt(x_net^2 + y_net^2)
    Mtot = sqrt(x_net^2 + y_net^2 + z_net^2)

    annotate!(-1.2, -1.2, 1.25, text("M_z = $(round(z_net, digits=2))", 10, :left, :green))
    annotate!(-1.2, -1.2, 1.10, text("M_xy = $(round(Mxy, digits=2))", 10, :left, :purple))
    annotate!(-1.2, -1.2, 0.95, text("|M| = $(round(Mtot, digits=2))", 10, :left, :black))

    p
end

# ---------------------------------------------------------
# Save GIF
# ---------------------------------------------------------
gif(anim, "t1_t2_combined_3d.gif", fps = 15)

println("Done: t1_t2_combined_3d.gif")
