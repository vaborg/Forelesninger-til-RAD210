/* Rask MRI (del 1) — interaktive apper for Quarto reveal.js (iframe).
   Skanntid, hermitisk symmetri, undersampling/aliasing verifisert numerisk før innbygging. */
(function(){
  "use strict";
  const FT="'DejaVu Sans', Verdana, sans-serif";
  const C={blue:'#2F5FA8',red:'#C0392B',purple:'#5d3a8e',orange:'#b54a16',green:'#10b981',
           amber:'#d99a10',ink:'#1f2430',mut:'#9aa2ad',line:'#e3e6ea'};
  const clamp=(v,a,b)=>v<a?a:(v>b?b:v), TAU=Math.PI*2;
  function fit(cv,w,h){ const dpr=Math.max(1,Math.min(2.5,window.devicePixelRatio||1));
    cv.width=w*dpr; cv.height=h*dpr; cv.style.aspectRatio=w+'/'+h; const x=cv.getContext('2d'); x.setTransform(dpr,0,0,dpr,0,0); return x; }
  function T(x,s,px,py,o){ o=o||{}; x.globalAlpha=o.alpha==null?1:o.alpha; x.fillStyle=o.col||C.ink;
    x.font=(o.weight||'normal')+' '+(o.size||14)+'px '+FT; x.textAlign=o.align||'left'; x.textBaseline=o.base||'alphabetic'; x.fillText(s,px,py); x.globalAlpha=1; }
  function L(x,a,b,c,d,col,w,dash){ x.strokeStyle=col; x.lineWidth=w||1; x.setLineDash(dash||[]); x.beginPath(); x.moveTo(a,b); x.lineTo(c,d); x.stroke(); x.setLineDash([]); }
  function rr(x,px,py,w,h,r){ x.beginPath(); x.moveTo(px+r,py); x.arcTo(px+w,py,px+w,py+h,r); x.arcTo(px+w,py+h,px,py+h,r); x.arcTo(px,py+h,px,py,r); x.arcTo(px,py,px+w,py,r); x.closePath(); }
  function wrapText(x,s,px,py,maxw,lh,o){ const words=s.split(' '); let line='',yy=py; x.font=(o.weight||'normal')+' '+(o.size||13)+'px '+FT;
    for(const w of words){ const t=line?line+' '+w:w; if(x.measureText(t).width>maxw && line){ T(x,line,px,yy,o); line=w; yy+=lh; } else line=t; } if(line) T(x,line,px,yy,o); return yy; }
  // FFT
  function fft(re,im,inv){ const n=re.length;
    for(let i=1,j=0;i<n;i++){ let bit=n>>1; for(;j&bit;bit>>=1) j^=bit; j^=bit; if(i<j){let t=re[i];re[i]=re[j];re[j]=t;t=im[i];im[i]=im[j];im[j]=t;} }
    for(let len=2;len<=n;len<<=1){ const a=(inv?2:-2)*Math.PI/len,wr=Math.cos(a),wi=Math.sin(a);
      for(let i=0;i<n;i+=len){ let cr=1,ci=0; for(let k=0;k<len/2;k++){ const p=i+k,q=i+k+len/2;
        const vr=re[q]*cr-im[q]*ci,vi=re[q]*ci+im[q]*cr; re[q]=re[p]-vr;im[q]=im[p]-vi;re[p]+=vr;im[p]+=vi;
        const ncr=cr*wr-ci*wi;ci=cr*wi+ci*wr;cr=ncr; } } } if(inv){for(let i=0;i<n;i++){re[i]/=n;im[i]/=n;}} }
  function fft2(re,im,inv,N){ const rr=new Float64Array(N),ri=new Float64Array(N);
    for(let r=0;r<N;r++){ for(let c=0;c<N;c++){rr[c]=re[r*N+c];ri[c]=im[r*N+c];} fft(rr,ri,inv); for(let c=0;c<N;c++){re[r*N+c]=rr[c];im[r*N+c]=ri[c];} }
    for(let c=0;c<N;c++){ for(let r=0;r<N;r++){rr[r]=re[r*N+c];ri[r]=im[r*N+c];} fft(rr,ri,inv); for(let r=0;r<N;r++){re[r*N+c]=rr[r];im[r*N+c]=ri[r];} } }
  // head phantom (N×N), analytic ellipses
  function phantom(N){ const im=new Float64Array(N*N);
    function ell(cx,cy,a,b,ang,val){ const ca=Math.cos(ang),sa=Math.sin(ang);
      for(let r=0;r<N;r++)for(let c=0;c<N;c++){ const x=(c-N/2)/(N/2)-cx, y=(r-N/2)/(N/2)-cy; const xr=x*ca+y*sa, yr=-x*sa+y*ca;
        if(xr*xr/(a*a)+yr*yr/(b*b)<=1) im[r*N+c]=val; } }
    ell(0,0,0.72,0.88,0,0.35);          // skull/scalp
    ell(0,0,0.62,0.80,0,0.62);          // brain
    ell(0,0.05,0.45,0.62,0,0.72);       // deep
    ell(-0.16,0.08,0.09,0.26,0.2,0.30); // ventricle L
    ell(0.16,0.08,0.09,0.26,-0.2,0.30); // ventricle R
    ell(0.28,-0.28,0.11,0.10,0,0.95);   // bright lesion
    return im; }

  const M={};

  // ============================================================
  // 1. ECHO TRAIN (TSE/FSE): fills ETL k-space lines per shot
  // ============================================================
  M.echotrain={ready:false,animated:true,cv:null,x:null,W:960,H:470,ETL:8,t:0,last:null,
    init(root){ this.cv=root.querySelector('#cv-et'); this.x=fit(this.cv,this.W,this.H);
      this.sl=root.querySelector('#et-n'); this.slo=root.querySelector('#et-no');
      this.sl.oninput=()=>{ this.ETL=+this.sl.value; this.slo.textContent='ETL = '+this.ETL; this.t=0; }; this.slo.textContent='ETL = '+this.ETL;
      this.t=0; },
    tick(t){ if(this.last==null)this.last=t; const dt=Math.min(0.05,t-this.last); this.last=t; this.t+=dt*0.5; if(this.t>1.25)this.t=0; this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H);
      T(x,'Ekkotog (TSE/FSE): flere k-rom-linjer per skudd',W/2,26,{size:16,col:C.ink,weight:'bold',align:'center'});
      const gx=50,gw=560, t2x=f=>gx+f*gw; const rfY=78, sigY=150;
      // RF: 90 then ETL refocusing 180s
      L(x,gx,rfY,gx+gw,rfY,'#d3d7dd',1); T(x,'RF',18,rfY-24,{size:12,col:C.mut,weight:'bold'});
      L(x,t2x(0.03),rfY,t2x(0.03),rfY-30,C.blue,3); T(x,'90°',t2x(0.03),rfY-36,{size:10,col:C.blue,weight:'bold',align:'center'});
      const prog=this.t; const shown=Math.min(this.ETL,Math.floor(prog*this.ETL)+1);
      for(let e=0;e<this.ETL;e++){ const f=0.1+e/(this.ETL)*0.85; const on=e<shown;
        L(x,t2x(f),rfY,t2x(f),rfY-38,on?C.red:'#e3d0cf',on?3:2); if(e===0||e===this.ETL-1)T(x,'180°',t2x(f),rfY-44,{size:9,col:on?C.red:'#ccc',align:'center'}); }
      // signal: echoes decaying with T2
      L(x,gx,sigY,gx+gw,sigY,'#d3d7dd',1); T(x,'ekko',12,sigY-24,{size:12,col:C.mut,weight:'bold'});
      for(let e=0;e<this.ETL;e++){ const f=0.1+e/(this.ETL)*0.85+0.42/this.ETL; const amp=Math.exp(-e/this.ETL*1.6)*30; const on=e<shown;
        x.strokeStyle=on?C.green:'#d7e8e0'; x.lineWidth=on?2:1.2; x.beginPath();
        for(let s=-6;s<=6;s++){ const px=t2x(f)+s*2.2, py=sigY-Math.exp(-(s*s)/6)*amp*Math.cos(s*0.9); s===-6?x.moveTo(px,py):x.lineTo(px,py); } x.stroke(); }
      T(x,'T2-henfall over ekkotoget →',t2x(0.5),sigY+40,{size:11,col:C.mut});
      // k-space filling
      const kx=640,ky=70,ks=220; x.strokeStyle='#c3c8cf'; x.strokeRect(kx,ky,ks,ks); T(x,'k-rom',kx+ks/2,ky-8,{size:12.5,col:C.ink,weight:'bold',align:'center'});
      const Nl=32; for(let i=0;i<Nl;i++){ const yy=ky+i/Nl*ks; const filled = (i%1===0) && (i< shown*(Nl/this.ETL)) ; // fill 'shown' groups
        const grp=Math.floor(i/(Nl/this.ETL)); const isFilled= grp<shown;
        L(x,kx,yy,kx+ks,yy,isFilled?C.blue:'#eef1f4',isFilled?1.6:1); }
      T(x,shown+' / '+this.ETL+' linjer i dette skuddet',kx+ks/2,ky+ks+20,{size:12,col:C.blue,weight:'bold',align:'center'});
      // scan-time result
      const Tse=3000/1000*256, Ttse=Tse/this.ETL;
      wrapText(x,'Ett 90°-skudd følges av et TOG av 180°-pulser — hver gir et ekko og en NY k-rom-linje. Skanntid ≈ TR × N/ETL.',50,H-58,W-100,17,{size:12.5,col:C.ink});
      T(x,'256², TR 3 s:   SE (ETL 1) = '+(Tse/60).toFixed(0)+' min   →   TSE (ETL '+this.ETL+') = '+(Ttse<60?Ttse.toFixed(0)+' s':(Ttse/60).toFixed(1)+' min'),50,H-18,{size:13.5,col:C.red,weight:'bold'}); }
  };

  // ============================================================
  // 2. k-SPACE UNDERSAMPLING → ALIASING  (real FFT result)
  // ============================================================
  M.undersample={ready:false,animated:false,cv:null,x:null,W:960,H:470,R:1,N:128,
    init(root){ this.cv=root.querySelector('#cv-us'); this.x=fit(this.cv,this.W,this.H);
      this.ph=phantom(this.N); const kr=this.ph.slice(), ki=new Float64Array(this.N*this.N); fft2(kr,ki,false,this.N);
      this.kr=kr; this.ki=ki;
      this.sl=root.querySelector('#us-r'); this.slo=root.querySelector('#us-ro');
      this.sl.oninput=()=>{ this.R=+this.sl.value; this.slo.textContent='R = '+this.R; this.draw(); }; this.slo.textContent='R = '+this.R;
      this.draw(); },
    recon(){ const N=this.N; const kr=this.kr.slice(), ki=this.ki.slice();
      for(let r=0;r<N;r++){ if(r%this.R!==0){ for(let c=0;c<N;c++){ kr[r*N+c]=0; ki[r*N+c]=0; } } }
      fft2(kr,ki,true,N); const mag=new Float64Array(N*N); let mx=0; for(let p=0;p<N*N;p++){ mag[p]=Math.hypot(kr[p],ki[p]); if(mag[p]>mx)mx=mag[p]; } return {mag,mx}; },
    blit(x,arr,mx,X,Y,S,N){ const img=x.createImageData(S,S), d=img.data;
      for(let j=0;j<S;j++)for(let i=0;i<S;i++){ const sr=Math.floor(j/S*N), sc=Math.floor(i/S*N); const g=Math.round(clamp(arr[sr*N+sc]/mx,0,1)*255); const k=(j*S+i)*4; d[k]=d[k+1]=d[k+2]=g; d[k+3]=255; }
      x.putImageData(img,X,Y); x.strokeStyle='#c3c8cf'; x.strokeRect(X,Y,S,S); },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H); const N=this.N,S=300;
      T(x,'k-rom undersampling → aliasing',W/2,26,{size:16,col:C.ink,weight:'bold',align:'center'});
      const rec=this.recon(); this.blit(x,rec.mag,rec.mx,60,60,S,N);
      T(x, this.R===1?'Fullt k-rom → korrekt bilde':'Hver '+this.R+'. linje → innbretting', 60+S/2,50,{size:13,col:this.R===1?C.green:C.red,weight:'bold',align:'center'});
      // sampling pattern
      const px=460,py=60,ps=150; x.strokeStyle='#c3c8cf'; x.strokeRect(px,py,ps,ps);
      for(let i=0;i<40;i++){ const yy=py+i/40*ps; const on=(Math.floor(i*N/40))%this.R===0; L(x,px,yy,px+ps,yy,on?C.blue:'#f0f2f5',on?1.4:1); }
      T(x,'PE-linjer målt (blå)',px+ps/2,py-8,{size:12,col:C.ink,weight:'bold',align:'center'});
      T(x,'PE-retning ↕',px+ps+10,py+ps/2,{size:11,col:C.mut});
      // results
      const fov=100/this.R, snr=(1/Math.sqrt(this.R));
      T(x,'Resultat (R = '+this.R+'):',460,py+ps+40,{size:13.5,col:C.ink,weight:'bold'});
      T(x,'• skanntid: '+(100/this.R).toFixed(0)+' % → '+this.R+'× raskere',460,py+ps+66,{size:13,col:C.green,weight:'bold'});
      T(x,'• effektiv FoV (PE): '+(100/this.R).toFixed(0)+' %',460,py+ps+90,{size:13,col:C.ink});
      T(x,'• SNR: '+(snr*100).toFixed(0)+' % (∝ 1/√R)',460,py+ps+114,{size:13,col:C.amber,weight:'bold'});
      T(x,'• innbretting hvis objektet > redusert FoV',460,py+ps+138,{size:13,col:this.R>1?C.red:C.mut,weight:this.R>1?'bold':'normal'});
      wrapText(x,'Å hoppe over PE-linjer krymper synsfeltet i fasekodingsretningen → deler av objektet bretter inn (aliasing). Parallell avbildning (del 2) fjerner nettopp denne innbrettingen.',60,H-40,W-120,17,{size:12.5,col:C.ink}); }
  };

  // ============================================================
  // 3. PARTIAL FOURIER (Hermitian symmetry)
  // ============================================================
  M.partialfourier={ready:false,animated:false,cv:null,x:null,W:960,H:470,frac:100,mode:'symm',N:128,
    init(root){ this.cv=root.querySelector('#cv-pf'); this.x=fit(this.cv,this.W,this.H);
      this.ph=phantom(this.N); const kr=this.ph.slice(), ki=new Float64Array(this.N*this.N); fft2(kr,ki,false,this.N);
      this.kr=kr; this.ki=ki;
      this.sl=root.querySelector('#pf-f'); this.slo=root.querySelector('#pf-fo');
      this.sl.oninput=()=>{ this.frac=+this.sl.value; this.slo.textContent=this.frac+' %'; this.draw(); }; this.slo.textContent=this.frac+' %';
      root.querySelectorAll('[data-pf]').forEach(b=>{ b.classList.toggle('on',b.dataset.pf===this.mode);
        b.onclick=()=>{ this.mode=b.dataset.pf; root.querySelectorAll('[data-pf]').forEach(q=>q.classList.toggle('on',q===b)); this.draw(); }; });
      this.draw(); },
    recon(){ const N=this.N; const keep=Math.round(N*this.frac/100); const kr=new Float64Array(N*N), ki=new Float64Array(N*N);
      // acquire bottom 'keep' PE rows (indices 0..keep-1 in fftshifted sense → use rows 0..keep-1)
      for(let r=0;r<keep;r++)for(let c=0;c<N;c++){ kr[r*N+c]=this.kr[r*N+c]; ki[r*N+c]=this.ki[r*N+c]; }
      if(this.mode==='symm'){ // fill missing rows by Hermitian symmetry k(-k)=conj(k)
        for(let r=keep;r<N;r++){ const R=(N-r)%N; if(R<keep){ for(let c=0;c<N;c++){ const Cc=(N-c)%N; kr[r*N+c]=this.kr[R*N+Cc]; ki[r*N+c]=-this.ki[R*N+Cc]; } } } }
      fft2(kr,ki,true,N); const mag=new Float64Array(N*N); let mx=0; for(let p=0;p<N*N;p++){ mag[p]=Math.hypot(kr[p],ki[p]); if(mag[p]>mx)mx=mag[p]; } return {mag,mx}; },
    blit(x,arr,mx,X,Y,S,N){ const img=x.createImageData(S,S), d=img.data;
      for(let j=0;j<S;j++)for(let i=0;i<S;i++){ const sr=Math.floor(j/S*N), sc=Math.floor(i/S*N); const g=Math.round(clamp(arr[sr*N+sc]/mx,0,1)*255); const k=(j*S+i)*4; d[k]=d[k+1]=d[k+2]=g; d[k+3]=255; }
      x.putImageData(img,X,Y); x.strokeStyle='#c3c8cf'; x.strokeRect(X,Y,S,S); },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H); const N=this.N,S=300;
      T(x,'Partiell Fourier: symmetri fyller manglende k-rom',W/2,26,{size:16,col:C.ink,weight:'bold',align:'center'});
      const rec=this.recon(); this.blit(x,rec.mag,rec.mx,60,60,S,N);
      T(x, (this.mode==='symm'?'Hermitisk fyll':'kun nullfyll')+' — målte '+this.frac+' % av k-rom',60+S/2,50,{size:13,col:C.ink,weight:'bold',align:'center'});
      // pattern
      const px=460,py=60,ps=150; const keep=Math.round(40*this.frac/100); x.strokeStyle='#c3c8cf'; x.strokeRect(px,py,ps,ps);
      for(let i=0;i<40;i++){ const yy=py+i/40*ps; let col='#f0f2f5';
        if(i<keep) col=C.blue; else if(this.mode==='symm' && (40-i)<keep) col=C.purple;
        L(x,px,yy,px+ps,yy,col,1.4); }
      T(x,'målt (blå) · symmetri (lilla)',px+ps/2,py-8,{size:11.5,col:C.ink,weight:'bold',align:'center'});
      T(x,'Resultat:',460,py+ps+40,{size:13.5,col:C.ink,weight:'bold'});
      T(x,'• skanntid ≈ '+this.frac+' %',460,py+ps+66,{size:13,col:C.green,weight:'bold'});
      T(x,'• SNR ∝ √(målt andel) = '+(Math.sqrt(this.frac/100)*100).toFixed(0)+' %',460,py+ps+90,{size:13,col:C.amber,weight:'bold'});
      T(x, this.mode==='symm'?'• symmetri gjenoppretter oppløsningen':'• nullfyll → uskarphet (tap av høyfrekvens)',460,py+ps+114,{size:13,col:this.mode==='symm'?C.blue:C.red,weight:this.mode==='symm'?'bold':'normal'});
      wrapText(x,'For et reelt bilde er k-rom hermitisk symmetrisk: k(−k)=k*(k). Da holder det å måle litt over halvparten — resten regnes ut. Raskere, men mindre SNR og mer følsomt for fase-feil.',60,H-40,W-120,17,{size:12.5,col:C.ink}); }
  };

  // ============================================================
  // 4. EPI single-shot trajectory
  // ============================================================
  M.epi={ready:false,animated:true,cv:null,x:null,W:960,H:470,t:0,last:null,
    init(root){ this.cv=root.querySelector('#cv-epi'); this.x=fit(this.cv,this.W,this.H); this.t=0; },
    tick(t){ if(this.last==null)this.last=t; const dt=Math.min(0.05,t-this.last); this.last=t; this.t+=dt*0.12; if(this.t>1.15)this.t=0; this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H);
      T(x,'Echo-planar imaging (EPI): hele k-rom i ETT skudd',W/2,26,{size:16,col:C.ink,weight:'bold',align:'center'});
      const kx=300,ky=70,ks=320; x.strokeStyle='#c3c8cf'; x.strokeRect(kx,ky,ks,ks);
      T(x,'k-rom',kx+ks/2,ky-8,{size:12.5,col:C.ink,weight:'bold',align:'center'});
      L(x,kx+ks/2,ky,kx+ks/2,ky+ks,'#eef1f4',1); L(x,kx,ky+ks/2,kx+ks,ky+ks/2,'#eef1f4',1);
      // snake trajectory
      const Nl=24; const prog=clamp(this.t,0,1); const totalPts=Nl; const done=prog*Nl;
      x.strokeStyle=C.blue; x.lineWidth=2; x.beginPath(); let started=false;
      for(let i=0;i<Nl;i++){ if(i>done)break; const yy=ky+ks - i/(Nl-1)*ks; const ltr=i%2===0;
        const x0=ltr?kx:kx+ks, x1=ltr?kx+ks:kx;
        if(!started){ x.moveTo(x0,yy); started=true; } else x.lineTo(x0,yy);
        x.lineTo(x1,yy); }
      x.stroke();
      // head position marker
      const ci=Math.min(Nl-1,Math.floor(done)); const yy=ky+ks-ci/(Nl-1)*ks; const ltr=ci%2===0; const frac=done-ci; const hx=(ltr?kx:kx+ks)+(ltr?1:-1)*frac*ks;
      x.fillStyle=C.red; x.beginPath(); x.arc(clamp(hx,kx,kx+ks),yy,4,0,TAU); x.fill();
      // gradient schematic (left)
      T(x,'Gx: raske frem/tilbake',40,ky+30,{size:12,col:C.mut}); T(x,'(les hver linje)',40,ky+48,{size:11,col:C.mut});
      T(x,'Gy: små «blips»',40,ky+80,{size:12,col:C.mut}); T(x,'(neste linje)',40,ky+98,{size:11,col:C.mut});
      wrapText(x,'Etter ÉN eksitasjon leser EPI hele k-rom i et sikk-sakk-mønster: rask Gx frem og tilbake, små Gy-blips mellom linjene. Et helt bilde på titalls millisekunder.',40,H-58,W-80,17,{size:13,col:C.ink});
      T(x,'Svært rask (fMRI, diffusjon) — men følsom for forvrengning og off-resonans.',40,H-22,{size:12.5,col:C.blue,weight:'bold'}); }
  };

  // ============================================================
  // 5. NON-CARTESIAN TRAJECTORIES + gridding
  // ============================================================
  M.trajectory={ready:false,animated:true,cv:null,x:null,W:960,H:470,mode:'cartesian',t:0,last:null,
    init(root){ this.cv=root.querySelector('#cv-tr'); this.x=fit(this.cv,this.W,this.H);
      root.querySelectorAll('[data-traj]').forEach(b=>{ b.classList.toggle('on',b.dataset.traj===this.mode);
        b.onclick=()=>{ this.mode=b.dataset.traj; root.querySelectorAll('[data-traj]').forEach(q=>q.classList.toggle('on',q===b)); this.t=0; }; }); this.t=0; },
    tick(t){ if(this.last==null)this.last=t; const dt=Math.min(0.05,t-this.last); this.last=t; this.t+=dt*0.4; if(this.t>1.3)this.t=0; this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H);
      T(x,'k-rom-baner: kartesisk vs. non-kartesisk',W/2,26,{size:16,col:C.ink,weight:'bold',align:'center'});
      const kx=310,ky=64,ks=330,cx=kx+ks/2,cy=ky+ks/2,Rk=ks/2-6; x.strokeStyle='#c3c8cf'; x.strokeRect(kx,ky,ks,ks);
      L(x,cx,ky,cx,ky+ks,'#eef1f4',1); L(x,kx,cy,kx+ks,cy,'#eef1f4',1);
      const prog=clamp(this.t,0,1);
      x.strokeStyle=C.blue; x.lineWidth=1.8;
      if(this.mode==='cartesian'){ const Nl=18; const done=prog*Nl;
        for(let i=0;i<Nl;i++){ if(i>done)break; const yy=ky+6+i/(Nl-1)*(ks-12); L(x,kx+4,yy,kx+ks-4,yy,C.blue,1.6); } }
      else if(this.mode==='radial'){ const Ns=20; const done=prog*Ns;
        for(let i=0;i<Ns;i++){ if(i>done)break; const a=i/Ns*Math.PI; L(x,cx-Math.cos(a)*Rk,cy-Math.sin(a)*Rk,cx+Math.cos(a)*Rk,cy+Math.sin(a)*Rk,C.blue,1.4); } }
      else { // spiral
        x.beginPath(); const turns=5, maxT=prog*turns*TAU;
        for(let a=0;a<=maxT;a+=0.1){ const r=a/(turns*TAU)*Rk; const px=cx+Math.cos(a)*r, py=cy+Math.sin(a)*r; a===0?x.moveTo(px,py):x.lineTo(px,py); } x.stroke(); }
      T(x,'k-rom',cx,ky-8,{size:12.5,col:C.ink,weight:'bold',align:'center'});
      const info={cartesian:['Kartesisk','Rette linjer, rett FFT. Enkelt og robust — standard.'],
        radial:['Radial','Eiker gjennom senter. Robust mot bevegelse; senter ofte oversamplet.'],
        spiral:['Spiral','Effektiv dekning fra senter og ut. Rask, men trenger gridding + er følsom for off-resonans.']}[this.mode];
      T(x,info[0],60,ky+30,{size:15,col:C.ink,weight:'bold'});
      wrapText(x,info[1],60,ky+56,210,18,{size:12.5,col:C.ink});
      if(this.mode!=='cartesian'){
        T(x,'→ Gridding:',60,ky+150,{size:13,col:C.purple,weight:'bold'});
        wrapText(x,'Non-kartesiske data må interpoleres til et rutenett før FFT — ekstra beregning og tid.',60,ky+174,210,18,{size:12,col:C.purple}); }
      wrapText(x,'Banen bestemmer hvor raskt og hvor robust k-rom dekkes. Non-kartesiske baner (radial, spiral, «stack of cones») gir fart og bevegelsesrobusthet, men koster rekonstruksjon.',60,H-40,W-100,17,{size:12.5,col:C.ink}); }
  };

  window.runViz=function(name){ const m=M[name]; if(!m){console.error('unknown viz',name);return;}
    try{ m.init(document); m.ready=true; }catch(e){ console.error(e); }
    if(m.animated && m.tick){ (function loop(ts){ m.tick((ts||0)/1000); requestAnimationFrame(loop); })(); }
    window.addEventListener('resize',function(){ if(!m.cv)return; m.x=fit(m.cv,m.W,m.H); if(!m.animated && m.draw) m.draw(); }); };
  window.__fast={M,phantom,fft2};
})();
