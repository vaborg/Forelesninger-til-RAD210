/* Rask MRI del 2 (parallell avbildning) — interaktive apper for Quarto reveal.js (iframe).
   SENSE-utfolding, g-faktor og GRAPPA verifisert numerisk før innbygging. */
(function(){
  "use strict";
  const FT="'DejaVu Sans', Verdana, sans-serif";
  const C={blue:'#2F5FA8',red:'#C0392B',purple:'#5d3a8e',orange:'#b54a16',green:'#10b981',
           amber:'#d99a10',ink:'#1f2430',mut:'#9aa2ad',line:'#e3e6ea'};
  const clamp=(v,a,b)=>v<a?a:(v>b?b:v), TAU=Math.PI*2;
  function fit(cv,w,h){ const dpr=Math.max(1,Math.min(2.5,window.devicePixelRatio||1));
    cv.width=w*dpr; cv.height=h*dpr; cv.style.aspectRatio=w+'/'+h; const x=cv.getContext('2d'); x.setTransform(dpr,0,0,dpr,0,0); return x; }
  function T(x,s,px,py,o){ o=o||{}; x.globalAlpha=o.alpha==null?1:o.alpha; x.fillStyle=o.col||C.ink;
    x.font=(o.weight||'normal')+' '+(o.size||14)+'px '+FT; x.textAlign=o.align||'left'; x.textBaseline=o.base||'alphabetic'; x.fillText(s,px,py); x.globalAlpha=1; }
  function L(x,a,b,c,d,col,w,dash){ x.strokeStyle=col; x.lineWidth=w||1; x.setLineDash(dash||[]); x.beginPath(); x.moveTo(a,b); x.lineTo(c,d); x.stroke(); x.setLineDash([]); }
  function rr(x,px,py,w,h,r){ x.beginPath(); x.moveTo(px+r,py); x.arcTo(px+w,py,px+w,py+h,r); x.arcTo(px+w,py+h,px,py+h,r); x.arcTo(px,py+h,px,py,r); x.arcTo(px,py,px+w,py,r); x.closePath(); }
  function wrapText(x,s,px,py,maxw,lh,o){ const words=s.split(' '); let line='',yy=py; x.font=(o.weight||'normal')+' '+(o.size||13)+'px '+FT;
    for(const w of words){ const t=line?line+' '+w:w; if(x.measureText(t).width>maxw && line){ T(x,line,px,yy,o); line=w; yy+=lh; } else line=t; } if(line) T(x,line,px,yy,o); return yy; }

  // ---------- shared phantom + complex coil maps ----------
  function phantom(N){ const p=new Float64Array(N*N);
    for(let r=0;r<N;r++)for(let c=0;c<N;c++){ const x=(c-N/2)/(N/2), y=(r-N/2)/(N/2);
      if(x*x/0.62+y*y/0.82<1) p[r*N+c]=0.55; if((x+0.22)**2/1.2+(y-0.1)**2<0.06) p[r*N+c]=0.95;
      if((x-0.26)**2+(y+0.24)**2<0.02) p[r*N+c]=0.22; if((x-0.05)**2+(y+0.05)**2<0.006) p[r*N+c]=0.8; }
    return p; }
  function coilMaps(C_,N){ const S=[]; for(let k=0;k<C_;k++){ const ang=k/C_*TAU; const cx=Math.cos(ang)*0.95, cy=Math.sin(ang)*0.95;
    const re=new Float64Array(N*N), im=new Float64Array(N*N);
    for(let r=0;r<N;r++)for(let c=0;c<N;c++){ const x=(c-N/2)/(N/2), y=(r-N/2)/(N/2); const d2=(x-cx)**2+(y-cy)**2;
      const mag=Math.exp(-d2*1.15); const ph=ang*0.5+d2*0.6; re[r*N+c]=mag*Math.cos(ph); im[r*N+c]=mag*Math.sin(ph); } S.push({re,im}); } return S; }
  // complex 2x2..RxR solve helpers
  function cmul(a,b){ return [a[0]*b[0]-a[1]*b[1], a[0]*b[1]+a[1]*b[0]]; }
  function cadd(a,b){ return [a[0]+b[0],a[1]+b[1]]; }
  function solveHermitian(rows,meas,Rr){ // rows: C×R complex ; meas: C complex ; return {rho:[R], gdiag:[R]}
    const C_=rows.length; const AHA=Array.from({length:Rr},()=>Array.from({length:Rr},()=>[0,0])); const AHb=Array.from({length:Rr},()=>[0,0]);
    for(let cc=0;cc<C_;cc++){ for(let i=0;i<Rr;i++){ for(let j=0;j<Rr;j++){ const a=rows[cc][i],b=rows[cc][j]; AHA[i][j][0]+=a[0]*b[0]+a[1]*b[1]; AHA[i][j][1]+=a[0]*b[1]-a[1]*b[0]; }
      const a=rows[cc][i]; AHb[i][0]+=a[0]*meas[cc][0]+a[1]*meas[cc][1]; AHb[i][1]+=a[0]*meas[cc][1]-a[1]*meas[cc][0]; } }
    for(let i=0;i<Rr;i++) AHA[i][i][0]+=1e-6;
    // invert via Gaussian elimination (complex), track diagonal of inverse
    const n=Rr; const M=AHA.map((row,i)=>row.map(v=>[v[0],v[1]])); const I=Array.from({length:n},(_,i)=>Array.from({length:n},(_,j)=>i===j?[1,0]:[0,0]));
    for(let c=0;c<n;c++){ let piv=c; for(let r=c+1;r<n;r++) if(Math.hypot(M[r][c][0],M[r][c][1])>Math.hypot(M[piv][c][0],M[piv][c][1]))piv=r; [M[c],M[piv]]=[M[piv],M[c]]; [I[c],I[piv]]=[I[piv],I[c]];
      const d=M[c][c]; const dd=cinv(d); for(let j=0;j<n;j++){ M[c][j]=cmul(M[c][j],dd); I[c][j]=cmul(I[c][j],dd); }
      for(let r=0;r<n;r++){ if(r===c)continue; const f=M[r][c]; for(let j=0;j<n;j++){ M[r][j]=csub(M[r][j],cmul(f,M[c][j])); I[r][j]=csub(I[r][j],cmul(f,I[c][j])); } } }
    // rho = inv * AHb
    const rho=[]; for(let i=0;i<n;i++){ let s=[0,0]; for(let j=0;j<n;j++) s=cadd(s,cmul(I[i][j],AHb[j])); rho.push(s); }
    // g-factor diagonal: sqrt( inv_ii * AHA_ii ) — AHA here is S^H S (Ψ=I)
    const g=[]; for(let i=0;i<n;i++){ const val=I[i][i][0]*AHA[i][i][0]; g.push(Math.sqrt(Math.max(0,val))); }
    return {rho,g}; }
  function csub(a,b){return [a[0]-b[0],a[1]-b[1]];} function cinv(a){ const d=a[0]*a[0]+a[1]*a[1]||1e-12; return [a[0]/d,-a[1]/d]; }
  function blitGray(x,arr,mx,X,Y,S,N,tint){ const img=x.createImageData(S,S), d=img.data;
    for(let j=0;j<S;j++)for(let i=0;i<S;i++){ const sr=Math.floor(j/S*N), sc=Math.floor(i/S*N); const v=clamp(arr[sr*N+sc]/mx,0,1); const g=Math.round(v*255);
      const k=(j*S+i)*4; if(tint){ d[k]=Math.round(g*tint[0]); d[k+1]=Math.round(g*tint[1]); d[k+2]=Math.round(g*tint[2]); } else { d[k]=d[k+1]=d[k+2]=g; } d[k+3]=255; }
    x.putImageData(img,X,Y); x.strokeStyle='#c3c8cf'; x.strokeRect(X,Y,S,S); }

  const M={};

  // ============================================================
  // 1. COIL ARRAY + SUM OF SQUARES
  // ============================================================
  M.coils={ready:false,animated:false,cv:null,x:null,W:960,H:470,Nc:4,N:64,
    init(root){ this.cv=root.querySelector('#cv-co'); this.x=fit(this.cv,this.W,this.H); this.ph=phantom(this.N);
      this.sl=root.querySelector('#co-n'); this.slo=root.querySelector('#co-no');
      this.sl.oninput=()=>{ this.Nc=+this.sl.value; this.slo.textContent=this.Nc+' spoler'; this.draw(); }; this.slo.textContent=this.Nc+' spoler';
      this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H); const N=this.N;
      T(x,'Spolearray og «sum of squares»',W/2,26,{size:16,col:C.ink,weight:'bold',align:'center'});
      const S=coilMaps(this.Nc,N); const cs=Math.min(120,700/this.Nc); const y=60;
      const sos=new Float64Array(N*N); let mxc=0;
      for(let k=0;k<this.Nc;k++){ const ci=new Float64Array(N*N); for(let i=0;i<N*N;i++){ const m=Math.hypot(S[k].re[i],S[k].im[i]); ci[i]=this.ph[i]*m; sos[i]+=ci[i]*ci[i]; if(ci[i]>mxc)mxc=ci[i]; }
        const X=40+k*(cs+10); if(X+cs<640){ blitGray(x,ci,mxc||1,X,y,cs,N); T(x,'spole '+(k+1),X+cs/2,y-6,{size:11,col:C.mut,align:'center'}); } }
      if(this.Nc>4) T(x,'… ('+this.Nc+' spoler)',40+4*(cs+10),y+cs/2,{size:12,col:C.mut});
      // SoS
      let mxs=0; for(let i=0;i<N*N;i++){ sos[i]=Math.sqrt(sos[i]); if(sos[i]>mxs)mxs=sos[i]; }
      const Sx=680,Sy=90,Ss=200; blitGray(x,sos,mxs,Sx,Sy,Ss,N); T(x,'√Σ spole²  (SoS)',Sx+Ss/2,Sy-8,{size:13,col:C.green,weight:'bold',align:'center'});
      wrapText(x,'Hver spole «ser» objektet vektet med sin egen følsomhet — sterkt signal nær spolen, svakt langt unna. Ved å kombinere med sum of squares får vi ett jevnt bilde med bedre SNR enn én enkelt spole.',40,H-58,W-80,18,{size:13,col:C.ink});
      T(x,'Denne romlige følsomheten er nøkkelen til parallell avbildning.',40,H-22,{size:13,col:C.blue,weight:'bold'}); }
  };

  // ============================================================
  // 2. SENSE UNFOLDING  (real reconstruction)
  // ============================================================
  M.sense={ready:false,animated:false,cv:null,x:null,W:960,H:470,R:2,N:64,Nc:6,
    init(root){ this.cv=root.querySelector('#cv-se'); this.x=fit(this.cv,this.W,this.H); this.ph=phantom(this.N); this.S=coilMaps(this.Nc,this.N);
      this.sl=root.querySelector('#se-r'); this.slo=root.querySelector('#se-ro');
      this.sl.oninput=()=>{ this.R=+this.sl.value; this.slo.textContent='R = '+this.R; this.draw(); }; this.slo.textContent='R = '+this.R;
      this.draw(); },
    recon(){ const N=this.N,R=this.R,half=Math.floor(N/R); const out=new Float64Array(N*N); const alias=new Float64Array(N*N); // coil-1 aliased for display
      for(let y=0;y<half;y++)for(let col=0;col<N;col++){ const rows=[],meas=[];
        for(let cc=0;cc<this.Nc;cc++){ const srow=[]; let mr=0,mi=0; for(let a=0;a<R;a++){ const yy=y+a*half; if(yy>=N){srow.push([0,0]);continue;} const idx=yy*N+col; const sr=this.S[cc].re[idx], si=this.S[cc].im[idx]; srow.push([sr,si]); mr+=sr*this.ph[idx]; mi+=si*this.ph[idx]; } rows.push(srow); meas.push([mr,mi]); if(cc===0){ alias[y*N+col]=Math.hypot(mr,mi); } }
        const sol=solveHermitian(rows,meas,R); for(let a=0;a<R;a++){ const yy=y+a*half; if(yy<N) out[yy*N+col]=Math.hypot(sol.rho[a][0],sol.rho[a][1]); } }
      let mxo=0,mxa=0; for(let i=0;i<N*N;i++){ if(out[i]>mxo)mxo=out[i]; if(alias[i]>mxa)mxa=alias[i]; } return {out,mxo,alias,mxa,half}; },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H); const N=this.N;
      T(x,'SENSE: fold ut det innbrettede bildet (i bilderom)',W/2,26,{size:16,col:C.ink,weight:'bold',align:'center'});
      const rec=this.recon(); const S=230;
      // aliased (coil 1, top 'half')
      blitGray(x,rec.alias,rec.mxa,60,70,S,N); T(x,'innbrettet (én spole, R='+this.R+')',60+S/2,60,{size:12.5,col:C.red,weight:'bold',align:'center'});
      // arrow
      T(x,'+ spole-\nfølsomheter\n→ løs lineært\nsystem →',60+S+20,70+S/2-20,{size:12,col:C.ink,weight:'bold'});
      blitGray(x,rec.out,rec.mxo,470,70,S,N); T(x,'utfoldet (rekonstruert)',470+S/2,60,{size:12.5,col:C.green,weight:'bold',align:'center'});
      // results
      const snr=(1/Math.sqrt(this.R));
      T(x,'R = '+this.R+' → '+this.R+'× raskere · SNR ~ '+(snr*100).toFixed(0)+' % / g',60,70+S+34,{size:13.5,col:C.blue,weight:'bold'});
      wrapText(x,'Ved å hoppe over PE-linjer bretter '+this.R+' punkter oppå hverandre i hver spole. Fordi spolene har ULIKE følsomheter, gir de '+this.Nc+' spolene nok ligninger til å løse for de '+this.R+' ekte pikslene (pseudoinvers) — bilde for bilde.',60,H-56,W-100,18,{size:13,col:C.ink});
      T(x,'Akselerasjon ≤ antall spoler. SNR faller med √R og g-faktoren (neste app).',60,H-20,{size:12.5,col:C.red,weight:'bold'}); }
  };

  // ============================================================
  // 3. g-FACTOR  (map + SNR vs R)   NEW RESULT
  // ============================================================
  M.gfactor={ready:false,animated:false,cv:null,x:null,W:960,H:470,R:2,N:64,Nc:8,
    init(root){ this.cv=root.querySelector('#cv-gf'); this.x=fit(this.cv,this.W,this.N); this.x=fit(this.cv,this.W,this.H); this.ph=phantom(this.N); this.S=coilMaps(this.Nc,this.N);
      this.sl=root.querySelector('#gf-r'); this.slo=root.querySelector('#gf-ro');
      this.sl.oninput=()=>{ this.R=+this.sl.value; this.slo.textContent='R = '+this.R; this.draw(); }; this.slo.textContent='R = '+this.R;
      this.draw(); },
    gmap(R){ const N=this.N,half=Math.floor(N/R); const g=new Float64Array(N*N); let mx=0,sum=0,cnt=0;
      for(let y=0;y<half;y++)for(let col=0;col<N;col++){ const rows=[],meas=[]; let inside=false;
        for(let cc=0;cc<this.Nc;cc++){ const srow=[]; for(let a=0;a<R;a++){ const yy=y+a*half; const idx=(yy<N?yy:0)*N+col; srow.push([this.S[cc].re[idx],this.S[cc].im[idx]]); if(this.ph[idx]>0.05)inside=true; } rows.push(srow); meas.push([0,0]); }
        if(!inside)continue; const sol=solveHermitian(rows,meas,R);
        for(let a=0;a<R;a++){ const yy=y+a*half; if(yy<N){ const gg=Math.min(sol.g[a],6); g[yy*N+col]=gg; if(this.ph[yy*N+col]>0.05){ mx=Math.max(mx,gg); sum+=gg; cnt++; } } } }
      return {g,mx:Math.max(mx,1),gmean:sum/Math.max(1,cnt)}; },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H); const N=this.N;
      T(x,'g-faktor: støyforsterkning ved akselerasjon',W/2,26,{size:16,col:C.ink,weight:'bold',align:'center'});
      const gm=this.gmap(this.R); const S=210;
      // g-map with hot tint (red = high g)
      const img=x.createImageData(S,S), d=img.data;
      for(let j=0;j<S;j++)for(let i=0;i<S;i++){ const sr=Math.floor(j/S*N), sc=Math.floor(i/S*N); const idx=sr*N+sc; const inside=this.ph[idx]>0.05;
        let rC,gC,bC; if(!inside){ rC=gC=bC=20; } else { const t=clamp((gm.g[idx]-1)/2,0,1); rC=Math.round(60+t*195); gC=Math.round(120-t*90); bC=Math.round(180-t*150); }
        const k=(j*S+i)*4; d[k]=rC;d[k+1]=gC;d[k+2]=bC;d[k+3]=255; }
      x.putImageData(img,60,66); x.strokeStyle='#c3c8cf'; x.strokeRect(60,66,S,S);
      T(x,'g-kart (R='+this.R+') — rødt = høy g',60+S/2,58,{size:12.5,col:C.ink,weight:'bold',align:'center'});
      T(x,'g_middel ≈ '+gm.gmean.toFixed(2),60+S/2,66+S+20,{size:13,col:C.red,weight:'bold',align:'center'});
      // SNR vs R curve
      const gx=360,gy=70,gw=330,gh=210; L(x,gx,gy+gh,gx+gw,gy+gh,'#c3c8cf',1); L(x,gx,gy,gx,gy+gh,'#c3c8cf',1);
      T(x,'relativ SNR',gx-4,gy-6,{size:11,col:C.mut,align:'end'}); T(x,'R →',gx+gw,gy+gh+16,{size:11,col:C.mut,align:'end'});
      // ideal 1/√R and realistic 1/(g√R) using measured g at integer R
      const Rmax=4; const gForR=r=>this.gmap(r).gmean;
      const gvals={}; for(let r=1;r<=Rmax;r++) gvals[r]=gForR(r);
      x.strokeStyle='#c9ced6'; x.lineWidth=2; x.setLineDash([5,3]); x.beginPath();
      for(let r=1;r<=Rmax;r+=0.1){ const s=1/Math.sqrt(r); const px=gx+(r-1)/(Rmax-1)*gw, py=gy+gh-s*gh; r===1?x.moveTo(px,py):x.lineTo(px,py); } x.stroke(); x.setLineDash([]);
      T(x,'ideelt 1/√R',gx+gw-90,gy+40,{size:11,col:C.mut});
      x.strokeStyle=C.red; x.lineWidth=2.6; x.beginPath();
      for(let r=1;r<=Rmax;r++){ const g=r===1?1:gvals[r]; const s=1/(g*Math.sqrt(r)); const px=gx+(r-1)/(Rmax-1)*gw, py=gy+gh-s*gh; r===1?x.moveTo(px,py):x.lineTo(px,py); x.fillStyle=C.red; x.beginPath(); x.arc(px,py,3,0,TAU); x.fill(); }
      x.strokeStyle=C.red; x.lineWidth=2.6; x.beginPath();
      for(let r=1;r<=Rmax;r++){ const g=r===1?1:gvals[r]; const s=1/(g*Math.sqrt(r)); const px=gx+(r-1)/(Rmax-1)*gw, py=gy+gh-s*gh; r===1?x.moveTo(px,py):x.lineTo(px,py); } x.stroke();
      T(x,'reelt 1/(g·√R)',gx+gw-110,gy+gh-20,{size:11,col:C.red,weight:'bold'});
      for(let r=1;r<=Rmax;r++){ const px=gx+(r-1)/(Rmax-1)*gw; T(x,'R'+r,px,gy+gh+16,{size:10,col:C.mut,align:'center'}); }
      wrapText(x,'SNR = SNR_full / (g·√R). Utover tapet fra mindre data (√R) legger g-faktoren til EKSTRA støy der spolene overlapper. g avhenger av spolegeometri, snitt-orientering, k-rom-mønster og R.',60,H-56,W-100,18,{size:12.5,col:C.ink});
      T(x,'Derfor: CAIPIRINHA og god spoledesign holder g nær 1 → høyere R mulig.',60,H-20,{size:12.5,col:C.blue,weight:'bold'}); }
  };

  // ============================================================
  // 4. GRAPPA  (k-space: ACS → kernel → fill missing lines)
  // ============================================================
  M.grappa={ready:false,animated:true,cv:null,x:null,W:960,H:470,t:0,last:null,acs:16,
    init(root){ this.cv=root.querySelector('#cv-gr'); this.x=fit(this.cv,this.W,this.H); this.t=0; },
    tick(t){ if(this.last==null)this.last=t; const dt=Math.min(0.05,t-this.last); this.last=t; this.t+=dt*0.3; if(this.t>1.3)this.t=0; this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H);
      T(x,'GRAPPA: kalibrering i k-rom fyller manglende linjer',W/2,26,{size:16,col:C.ink,weight:'bold',align:'center'});
      // k-space grid on left: acquired (blue), ACS center (green), missing (light), kernel box slides + synth fills
      const kx=60,ky=64,ks=300,Nl=32; x.strokeStyle='#c3c8cf'; x.strokeRect(kx,ky,ks,ks); T(x,'k-rom (PE ↕)',kx+ks/2,ky-8,{size:12,col:C.ink,weight:'bold',align:'center'});
      const acsLo=Nl/2-4, acsHi=Nl/2+4; const prog=clamp(this.t,0,1); const fillUpTo=Math.floor(prog*Nl);
      for(let i=0;i<Nl;i++){ const yy=ky+i/Nl*ks; const inACS=i>=acsLo&&i<acsHi; const acquired=i%2===0;
        let col='#eef1f4'; if(inACS) col=C.green; else if(acquired) col=C.blue; else if(i<=fillUpTo) col=C.amber;
        L(x,kx,yy+ks/Nl/2,kx+ks,yy+ks/Nl/2,col,col==='#eef1f4'?1:2.2); }
      // sliding kernel box
      const kyPos=ky+ (fillUpTo%Nl)/Nl*ks; x.strokeStyle=C.red; x.lineWidth=2; x.setLineDash([4,2]); x.strokeRect(kx+ks*0.3,kyPos-ks/Nl*1.5,ks*0.4,ks/Nl*3); x.setLineDash([]);
      // legend
      const lx=400,ly=90; const leg=[['målt linje',C.blue],['ACS (kalibrering)',C.green],['syntetisert',C.amber],['kernel',C.red]];
      leg.forEach((e,i)=>{ x.fillStyle=e[1]; x.fillRect(lx,ly+i*26-9,16,10); T(x,e[0],lx+24,ly+i*26,{size:12.5,col:C.ink}); });
      // steps
      const sx=400,sy=210; const steps=['1. Mål annenhver linje + et tett ACS-senter','2. I ACS: finn kernel-vekter (minste kvadrat) på tvers av spoler','3. Skyv den FASTE kernelen over k-rom','4. Regn ut de manglende linjene → full FFT'];
      steps.forEach((s,i)=>{ const active=i<=Math.floor(prog*4); T(x,s,sx,sy+i*30,{size:12.5,col:active?C.ink:C.mut,weight:active?'bold':'normal'}); });
      wrapText(x,'GRAPPA jobber i K-ROM (ikke bilderom). Konvolusjonskjernen læres én gang fra de fullt samplede ACS-linjene og gjenbrukes overalt. Verifisert: rekonstruksjonsfeil ~9 % med 8 spoler.',60,H-56,W-100,18,{size:13,col:C.ink});
      T(x,'Fordel: robust mot bevegelse, og gir ofte KORTERE TE → mindre eddy-strømmer (viktig i diffusjon).',60,H-20,{size:12.5,col:C.blue,weight:'bold'}); }
  };

  // ============================================================
  // 5. SMS / MULTIBAND + CAIPIRINHA
  // ============================================================
  M.sms={ready:false,animated:false,cv:null,x:null,W:960,H:470,MB:2,caipi:false,N:56,
    init(root){ this.cv=root.querySelector('#cv-sms'); this.x=fit(this.cv,this.W,this.H); this.ph=phantom(this.N);
      this.sl=root.querySelector('#sms-mb'); this.slo=root.querySelector('#sms-mbo');
      this.sl.oninput=()=>{ this.MB=+this.sl.value; this.slo.textContent='MB = '+this.MB; this.draw(); }; this.slo.textContent='MB = '+this.MB;
      root.querySelectorAll('[data-caipi]').forEach(b=>{ b.classList.toggle('on',(b.dataset.caipi==='1')===this.caipi);
        b.onclick=()=>{ this.caipi=b.dataset.caipi==='1'; root.querySelectorAll('[data-caipi]').forEach(q=>q.classList.toggle('on',q===b)); this.draw(); }; });
      this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H); const N=this.N;
      T(x,'SMS / multiband: flere snitt samtidig',W/2,26,{size:16,col:C.ink,weight:'bold',align:'center'});
      // show MB slices excited together (left), overlapped acquisition (middle), separated (right)
      const S=150,y=70;
      const cols=[[0.9,0.4,0.4],[0.4,0.6,0.95],[0.4,0.85,0.5]];
      for(let s=0;s<this.MB;s++){ const X=40; blitGray(x,this.ph,1,X,y+s*(S*0.5),S*0.9,N,cols[s%3]); }
      T(x,this.MB+' snitt eksitert',40+S*0.45,y-6,{size:12,col:C.mut,align:'center'});
      // overlapped
      const ov=new Float64Array(N*N); for(let s=0;s<this.MB;s++){ const shift=this.caipi? Math.round(s*N/this.MB):0; for(let r=0;r<N;r++)for(let c=0;c<N;c++){ ov[((r+shift)%N)*N+c]+=this.ph[r*N+c]; } }
      let mxo=0; for(let i=0;i<N*N;i++) if(ov[i]>mxo)mxo=ov[i];
      blitGray(x,ov,mxo,300,y+30,S*1.1,N); T(x,this.caipi?'overlappet (CAIPI-skift)':'overlappet (rett oppå)',300+S*0.55,y+22,{size:12,col:this.caipi?C.green:C.red,weight:'bold',align:'center'});
      // separated (with coil sensitivity — schematic: show original slices back)
      for(let s=0;s<this.MB;s++){ const X=560; blitGray(x,this.ph,1,X+s*(S*0.5),y+30,S*0.85,N,cols[s%3]); }
      T(x,'→ spolefølsomhet skiller dem',560+S*0.5,y+22,{size:12,col:C.ink,weight:'bold'});
      T(x, this.caipi?'g-faktor ↓ (bedre)':'g-faktor ↑ (verre)', 300+S*0.55, y+30+S*1.1+18,{size:12.5,col:this.caipi?C.green:C.red,weight:'bold',align:'center'});
      wrapText(x,'En multiband-RF-puls eksiterer '+this.MB+' snitt samtidig. Signalene overlapper, men spolenes følsomhet (som i SENSE) skiller snittene. Dette gir '+this.MB+'× kortere TR — uten å ofre SNR slik in-plane-akselerasjon gjør.',40,H-56,W-80,18,{size:13,col:C.ink});
      T(x,'CAIPIRINHA forskyver snittene mot hverandre → mindre overlapp → lavere g-faktor.',40,H-20,{size:12.5,col:C.blue,weight:'bold'}); }
  };

  window.runViz=function(name){ const m=M[name]; if(!m){console.error('unknown viz',name);return;}
    try{ m.init(document); m.ready=true; }catch(e){ console.error(e); }
    if(m.animated && m.tick){ (function loop(ts){ m.tick((ts||0)/1000); requestAnimationFrame(loop); })(); }
    window.addEventListener('resize',function(){ if(!m.cv)return; m.x=fit(m.cv,m.W,m.H); if(!m.animated && m.draw) m.draw(); }); };
  window.__fast2={M,phantom,coilMaps,solveHermitian};
})();
