/* DL/ML for rask MRI — interaktive apper for Quarto reveal.js (iframe).
   Ekte MLP-trening (backprop), ekte FFT + komprimert sansing verifisert numerisk før innbygging. */
(function(){
  "use strict";
  const FT="'DejaVu Sans', Verdana, sans-serif";
  const C={blue:'#2F5FA8',red:'#C0392B',purple:'#5d3a8e',orange:'#b54a16',green:'#10b981',
           amber:'#d99a10',ink:'#1f2430',mut:'#9aa2ad',line:'#e3e6ea'};
  const clamp=(v,a,b)=>v<a?a:(v>b?b:v), TAU=Math.PI*2;
  function fit(cv,w,h){ const dpr=Math.max(1,Math.min(2.5,window.devicePixelRatio||1));
    cv.width=w*dpr; cv.height=h*dpr; cv.style.aspectRatio=w+'/'+h; const x=cv.getContext('2d'); x.setTransform(dpr,0,0,dpr,0,0); return x; }
  function T(x,s,px,py,o){ o=o||{}; x.globalAlpha=o.alpha==null?1:o.alpha; x.fillStyle=o.col||C.ink;
    x.font=(o.weight||'normal')+' '+(o.size||14)+'px '+FT; x.textAlign=o.align||'left'; x.textBaseline=o.base||'alphabetic'; x.fillText(s,px,py); x.globalAlpha=1; }
  function L(x,a,b,c,d,col,w,dash){ x.strokeStyle=col; x.lineWidth=w||1; x.setLineDash(dash||[]); x.beginPath(); x.moveTo(a,b); x.lineTo(c,d); x.stroke(); x.setLineDash([]); }
  function rr(x,px,py,w,h,r){ x.beginPath(); x.moveTo(px+r,py); x.arcTo(px+w,py,px+w,py+h,r); x.arcTo(px+w,py+h,px,py+h,r); x.arcTo(px,py+h,px,py,r); x.arcTo(px,py,px+w,py,r); x.closePath(); }
  function wrapText(x,s,px,py,maxw,lh,o){ const words=s.split(' '); let line='',yy=py; x.font=(o.weight||'normal')+' '+(o.size||13)+'px '+FT;
    for(const w of words){ const t=line?line+' '+w:w; if(x.measureText(t).width>maxw && line){ T(x,line,px,yy,o); line=w; yy+=lh; } else line=t; } if(line) T(x,line,px,yy,o); return yy; }

  // ---------- FFT / phantom / Haar (shared by recon, unrolled, sampling) ----------
  function fft(re,im,inv){ const n=re.length;
    for(let i=1,j=0;i<n;i++){ let bit=n>>1; for(;j&bit;bit>>=1) j^=bit; j^=bit; if(i<j){let t=re[i];re[i]=re[j];re[j]=t;t=im[i];im[i]=im[j];im[j]=t;} }
    for(let len=2;len<=n;len<<=1){ const a=(inv?2:-2)*Math.PI/len,wr=Math.cos(a),wi=Math.sin(a);
      for(let i=0;i<n;i+=len){ let cr=1,ci=0; for(let k=0;k<len/2;k++){ const p=i+k,q=i+k+len/2;
        const vr=re[q]*cr-im[q]*ci,vi=re[q]*ci+im[q]*cr; re[q]=re[p]-vr;im[q]=im[p]-vi;re[p]+=vr;im[p]+=vi;
        const ncr=cr*wr-ci*wi;ci=cr*wi+ci*wr;cr=ncr; } } } if(inv){for(let i=0;i<n;i++){re[i]/=n;im[i]/=n;}} }
  function fft2(re,im,inv,N){ const rr=new Float64Array(N),ri=new Float64Array(N);
    for(let r=0;r<N;r++){ for(let c=0;c<N;c++){rr[c]=re[r*N+c];ri[c]=im[r*N+c];} fft(rr,ri,inv); for(let c=0;c<N;c++){re[r*N+c]=rr[c];im[r*N+c]=ri[c];} }
    for(let c=0;c<N;c++){ for(let r=0;r<N;r++){rr[r]=re[r*N+c];ri[r]=im[r*N+c];} fft(rr,ri,inv); for(let r=0;r<N;r++){re[r*N+c]=rr[r];im[r*N+c]=ri[r];} } }
  function phantomN(N){ const p=new Float64Array(N*N); for(let r=0;r<N;r++)for(let c=0;c<N;c++){ const x=(c-N/2)/(N/2),y=(r-N/2)/(N/2);
    if(x*x/0.6+y*y/0.8<1)p[r*N+c]=0.55; if((x+0.2)**2+(y-0.1)**2<0.05)p[r*N+c]=0.95; if((x-0.25)**2+(y+0.2)**2<0.03)p[r*N+c]=0.22; if((x-0.05)**2+(y+0.05)**2<0.004)p[r*N+c]=0.82; } return p; }
  function haar2(x,N,inv){ const tmp=new Float64Array(N);
    function fwd1(arr,n){ const t=new Float64Array(n),h=n>>1; for(let i=0;i<h;i++){ t[i]=(arr[2*i]+arr[2*i+1])/Math.SQRT2; t[h+i]=(arr[2*i]-arr[2*i+1])/Math.SQRT2; } for(let i=0;i<n;i++)arr[i]=t[i]; }
    function inv1(arr,n){ const t=new Float64Array(n),h=n>>1; for(let i=0;i<h;i++){ t[2*i]=(arr[i]+arr[h+i])/Math.SQRT2; t[2*i+1]=(arr[i]-arr[h+i])/Math.SQRT2; } for(let i=0;i<n;i++)arr[i]=t[i]; }
    let n=N; if(!inv){ while(n>=2){ for(let r=0;r<n;r++){ for(let c=0;c<n;c++)tmp[c]=x[r*N+c]; fwd1(tmp.subarray(0,n),n); for(let c=0;c<n;c++)x[r*N+c]=tmp[c]; }
        for(let c=0;c<n;c++){ for(let r=0;r<n;r++)tmp[r]=x[r*N+c]; fwd1(tmp.subarray(0,n),n); for(let r=0;r<n;r++)x[r*N+c]=tmp[r]; } n>>=1; } }
    else { const levels=[]; let nn=2; while(nn<=N){ levels.push(nn); nn<<=1; } for(const Lv of levels){
        for(let c=0;c<Lv;c++){ for(let r=0;r<Lv;r++)tmp[r]=x[r*N+c]; inv1(tmp.subarray(0,Lv),Lv); for(let r=0;r<Lv;r++)x[r*N+c]=tmp[r]; }
        for(let r=0;r<Lv;r++){ for(let c=0;c<Lv;c++)tmp[c]=x[r*N+c]; inv1(tmp.subarray(0,Lv),Lv); for(let c=0;c<Lv;c++)x[r*N+c]=tmp[c]; } } } }
  const soft=(v,t)=>{ const a=Math.abs(v); return a<=t?0:Math.sign(v)*(a-t); };
  function vdMask(N,R,seed){ let s=seed||7; const rnd=()=>{ s=(s*1103515245+12345)&0x7fffffff; return s/0x7fffffff; };
    const m=new Uint8Array(N); for(let r=0;r<N;r++){ const dc=Math.min(r,N-r); if(dc<N*0.10) m[r]=1; else m[r]=(rnd()<1.0/R)?1:0; } return m; }
  function nrmse(a,b){ let e=0,en=0; for(let i=0;i<a.length;i++){ e+=(a[i]-b[i])**2; en+=b[i]**2; } return Math.sqrt(e/en); }
  function blitGray(x,arr,mx,X,Y,S,N){ const img=x.createImageData(S,S), d=img.data;
    for(let j=0;j<S;j++)for(let i=0;i<S;i++){ const sr=Math.floor(j/S*N), sc=Math.floor(i/S*N); const g=Math.round(clamp(arr[sr*N+sc]/mx,0,1)*255); const k=(j*S+i)*4; d[k]=d[k+1]=d[k+2]=g; d[k+3]=255; }
    x.putImageData(img,X,Y); x.strokeStyle='#c3c8cf'; x.strokeRect(X,Y,S,S); }

  const M={};

  // ============================================================
  // 1. NEURAL NETWORK (real backprop) learns nonlinear boundary
  // ============================================================
  const tanh=Math.tanh, dtanh=y=>1-y*y, sig=x=>1/(1+Math.exp(-x));
  function makeNet(sizes){ const W=[],b=[]; for(let l=0;l<sizes.length-1;l++){ const ni=sizes[l],no=sizes[l+1]; const w=[];
    for(let o=0;o<no;o++){ const row=[]; for(let i=0;i<ni;i++) row.push((Math.random()*2-1)*Math.sqrt(1/ni)); w.push(row); } W.push(w); b.push(new Array(no).fill(0)); } return {W,b,sizes}; }
  function fwd(net,x){ const acts=[x]; let a=x; for(let l=0;l<net.W.length;l++){ const no=net.W[l].length; const out=new Array(no); const last=l===net.W.length-1;
    for(let o=0;o<no;o++){ let s=net.b[l][o]; for(let i=0;i<a.length;i++) s+=net.W[l][o][i]*a[i]; out[o]=last?sig(s):tanh(s); } acts.push(out); a=out; } return acts; }
  function step(net,X,Y,lr){ let loss=0; const gW=net.W.map(w=>w.map(r=>r.map(()=>0))); const gb=net.b.map(r=>r.map(()=>0));
    for(let n=0;n<X.length;n++){ const acts=fwd(net,X[n]); const Ln=net.W.length; const yh=acts[Ln][0], y=Y[n];
      loss+=-(y*Math.log(yh+1e-9)+(1-y)*Math.log(1-yh+1e-9)); let delta=[yh-y];
      for(let l=Ln-1;l>=0;l--){ const ap=acts[l], no=net.W[l].length;
        for(let o=0;o<no;o++){ for(let i=0;i<ap.length;i++) gW[l][o][i]+=delta[o]*ap[i]; gb[l][o]+=delta[o]; }
        if(l>0){ const nd=new Array(ap.length).fill(0); for(let i=0;i<ap.length;i++){ let s=0; for(let o=0;o<no;o++) s+=net.W[l][o][i]*delta[o]; nd[i]=s*dtanh(ap[i]); } delta=nd; } } }
    const m=X.length; for(let l=0;l<net.W.length;l++)for(let o=0;o<net.W[l].length;o++){ for(let i=0;i<net.W[l][o].length;i++) net.W[l][o][i]-=lr*gW[l][o][i]/m; net.b[l][o]-=lr*gb[l][o]/m; } return loss/m; }
  M.nn={ready:false,animated:true,cv:null,x:null,W:960,H:470,ds:'circle',model:'mlp',lr:0.6,net:null,X:[],Y:[],losses:[],epoch:0,last:null,acc:0,
    data(kind){ const X=[],Y=[]; for(let i=0;i<300;i++){ const x=Math.random()*2-1,y=Math.random()*2-1; let c;
      if(kind==='circle') c=(x*x+y*y<0.45)?1:0; else if(kind==='xor') c=((x>0)!==(y>0))?1:0;
      else { const r=Math.hypot(x,y),a=Math.atan2(y,x); c=(Math.sin(a*2+r*4)>0)?1:0; } X.push([x,y]); Y.push(c); } this.X=X; this.Y=Y; },
    reset(){ this.data(this.ds); this.net=makeNet(this.model==='mlp'?[2,8,8,1]:[2,1]); this.losses=[]; this.epoch=0; },
    init(root){ this.cv=root.querySelector('#cv-nn'); this.x=fit(this.cv,this.W,this.H);
      root.querySelectorAll('[data-ds]').forEach(b=>{ b.classList.toggle('on',b.dataset.ds===this.ds); b.onclick=()=>{ this.ds=b.dataset.ds; root.querySelectorAll('[data-ds]').forEach(q=>q.classList.toggle('on',q===b)); this.reset(); }; });
      root.querySelectorAll('[data-model]').forEach(b=>{ b.classList.toggle('on',b.dataset.model===this.model); b.onclick=()=>{ this.model=b.dataset.model; root.querySelectorAll('[data-model]').forEach(q=>q.classList.toggle('on',q===b)); this.reset(); }; });
      this.sl=root.querySelector('#nn-lr'); this.slo=root.querySelector('#nn-lro'); if(this.sl){ this.sl.oninput=()=>{ this.lr=+this.sl.value; this.slo.textContent='η = '+this.lr.toFixed(2); }; this.slo.textContent='η = '+this.lr.toFixed(2); }
      const rb=root.querySelector('#nn-reset'); if(rb) rb.onclick=()=>this.reset();
      this.reset(); },
    tick(t){ if(this.last==null)this.last=t; const dt=t-this.last; this.last=t;
      for(let s=0;s<3;s++){ const L=step(this.net,this.X,this.Y,this.lr); this.epoch++; if(this.epoch%2===0) this.losses.push(L); if(this.losses.length>240)this.losses.shift(); }
      let c=0; for(let n=0;n<this.X.length;n++){ const a=fwd(this.net,this.X[n]); if((a[a.length-1][0]>0.5?1:0)===this.Y[n])c++; } this.acc=c/this.X.length;
      this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H);
      T(x,'Nevralt nettverk lærer (ekte backprop i nettleseren)',W/2,26,{size:16,col:C.ink,weight:'bold',align:'center'});
      // decision boundary grid
      const X0=50,Y0=56,S=300, G=60; const img=x.createImageData(S,S), d=img.data;
      for(let j=0;j<S;j++)for(let i=0;i<S;i++){ const px=(i/S)*2-1, py=(j/S)*2-1; const a=fwd(this.net,[px,py]); const p=a[a.length-1][0];
        const k=(j*S+i)*4; d[k]=Math.round(230-p*150); d[k+1]=Math.round(235-Math.abs(p-0.5)*120); d[k+2]=Math.round(230+ (p-0.5)*100*0); if(p>0.5){ d[k]=Math.round(255-(1-p)*80); d[k+1]=Math.round(210-(1-p)*40); d[k+2]=Math.round(200-(1-p)*40);} else { d[k]=Math.round(200- p*40); d[k+1]=Math.round(220- p*20); d[k+2]=Math.round(250- p*40);} d[k+3]=255; }
      x.putImageData(img,X0,Y0);
      for(const [i,pt] of this.X.entries()){ const px=X0+(pt[0]+1)/2*S, py=Y0+(pt[1]+1)/2*S; x.fillStyle=this.Y[i]?C.red:C.blue; x.beginPath(); x.arc(px,py,3,0,TAU); x.fill(); x.strokeStyle='#fff'; x.lineWidth=0.7; x.stroke(); }
      x.strokeStyle='#c3c8cf'; x.strokeRect(X0,Y0,S,S); T(x,'beslutningsgrense',X0+S/2,Y0-6,{size:12,col:C.ink,weight:'bold',align:'center'});
      // loss curve
      const lx=420,ly=60,lw=300,lh=170; L(x,lx,ly+lh,lx+lw,ly+lh,'#c3c8cf',1); L(x,lx,ly,lx,ly+lh,'#c3c8cf',1);
      T(x,'tap (loss)',lx,ly-6,{size:12,col:C.ink,weight:'bold'});
      if(this.losses.length>1){ const mx=Math.max(...this.losses,0.1); x.strokeStyle=C.purple; x.lineWidth=2; x.beginPath();
        this.losses.forEach((v,i)=>{ const px=lx+i/(this.losses.length-1)*lw, py=ly+lh-(v/mx)*lh; i===0?x.moveTo(px,py):x.lineTo(px,py); }); x.stroke(); }
      T(x,'epoker →',lx+lw,ly+lh+16,{size:11,col:C.mut,align:'end'});
      // stats
      T(x,'modell: '+(this.model==='mlp'?'MLP (2-8-8-1)':'lineær (logistisk)'),lx,ly+lh+40,{size:13,col:C.ink,weight:'bold'});
      T(x,'nøyaktighet: '+(this.acc*100).toFixed(0)+'%',lx,ly+lh+64,{size:15,col:this.acc>0.85?C.green:(this.acc>0.7?C.amber:C.red),weight:'bold'});
      T(x, this.model==='mlp'?'MLP bøyer grensen → løser ikke-lineære mønstre.':'Lineær modell = rett grense → feiler på ikke-lineære data.', lx,ly+lh+86,{size:12.5,col:this.model==='mlp'?C.green:C.red,weight:'bold'});
      wrapText(x,'Nevronet: vekter × input + bias → aktivering. Backprop justerer vektene for å minke tapet (gradientnedstigning). Bytt datasett og modell — se hvorfor DYP læring slår klassiske lineære metoder.',50,H-40,W-100,17,{size:12.5,col:C.ink}); }
  };

  // ============================================================
  // 2. CONVOLUTION (CNN feature extraction)
  // ============================================================
  M.convolution={ready:false,animated:false,cv:null,x:null,W:960,H:470,N:64,kernel:'sobel',
    kernels:{ sobel:[[-1,0,1],[-2,0,2],[-1,0,1]], blur:[[1/9,1/9,1/9],[1/9,1/9,1/9],[1/9,1/9,1/9]],
      sharpen:[[0,-1,0],[-1,5,-1],[0,-1,0]], emboss:[[-2,-1,0],[-1,1,1],[0,1,2]] },
    init(root){ this.cv=root.querySelector('#cv-cv'); this.x=fit(this.cv,this.W,this.H); this.ph=phantomN(this.N);
      root.querySelectorAll('[data-kern]').forEach(b=>{ b.classList.toggle('on',b.dataset.kern===this.kernel); b.onclick=()=>{ this.kernel=b.dataset.kern; root.querySelectorAll('[data-kern]').forEach(q=>q.classList.toggle('on',q===b)); this.draw(); }; });
      this.draw(); },
    conv(){ const N=this.N,K=this.kernels[this.kernel]; const out=new Float64Array(N*N); let mx=0;
      for(let r=1;r<N-1;r++)for(let c=1;c<N-1;c++){ let s=0; for(let a=-1;a<=1;a++)for(let b=-1;b<=1;b++) s+=K[a+1][b+1]*this.ph[(r+a)*N+(c+b)]; out[r*N+c]=Math.abs(s); if(out[r*N+c]>mx)mx=out[r*N+c]; }
      return {out,mx:mx||1}; },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H);
      T(x,'Konvolusjon: byggeklossen i CNN',W/2,26,{size:16,col:C.ink,weight:'bold',align:'center'});
      const S=250; blitGray(x,this.ph,1,60,66,S,this.N); T(x,'inn-bilde',60+S/2,58,{size:13,col:C.ink,weight:'bold',align:'center'});
      const rec=this.conv(); blitGray(x,rec.out,rec.mx,560,66,S,this.N); T(x,'feature-kart',560+S/2,58,{size:13,col:C.green,weight:'bold',align:'center'});
      // kernel matrix in middle
      const K=this.kernels[this.kernel]; const kx=360,ky=110; T(x,'kernel',kx+55,ky-14,{size:12.5,col:C.purple,weight:'bold',align:'center'});
      for(let r=0;r<3;r++)for(let c=0;c<3;c++){ const v=K[r][c]; x.strokeStyle=C.purple; x.lineWidth=1.4; x.strokeRect(kx+c*38,ky+r*38,36,36); T(x,(Math.round(v*100)/100).toString(),kx+c*38+18,ky+r*38+23,{size:11,col:C.ink,align:'center'}); }
      T(x,'× skyves over bildet →',kx+10,ky+3*38+24,{size:12,col:C.mut});
      wrapText(x,'En CNN lærer TUSENVIS av slike kjerner. Hver framhever et mønster — kanter, teksturer, former. Stablet i dype lag bygger de opp stadig mer abstrakte trekk, helt uten håndlagde regler.',60,H-40,W-100,17,{size:12.5,col:C.ink});
      T(x,'Prøv: Sobel (kanter) · blur (glatting) · sharpen · emboss.',60,H-16,{size:12.5,col:C.blue,weight:'bold'}); }
  };

  // ============================================================
  // 3. RECON: zero-filled vs CS vs DL/unrolled (real FFT + iters)
  // ============================================================
  M.recon={ready:false,animated:false,cv:null,x:null,W:980,H:480,N:64,R:3,
    init(root){ this.cv=root.querySelector('#cv-rc'); this.x=fit(this.cv,this.W,this.H); this.ph=phantomN(this.N);
      const kr=this.ph.slice(), ki=new Float64Array(this.N*this.N); fft2(kr,ki,false,this.N); this.kr=kr; this.ki=ki;
      this.sl=root.querySelector('#rc-r'); this.slo=root.querySelector('#rc-ro'); this.sl.oninput=()=>{ this.R=+this.sl.value; this.slo.textContent='R = '+this.R; this.compute(); this.draw(); }; this.slo.textContent='R = '+this.R;
      this.compute(); this.draw(); },
    compute(){ const N=this.N; const m=vdMask(N,this.R,7); let nk=0; m.forEach(v=>nk+=v); this.eff=N/nk; this.m=m;
      const mkr=new Float64Array(N*N), mki=new Float64Array(N*N); for(let r=0;r<N;r++)if(m[r])for(let c=0;c<N;c++){ mkr[r*N+c]=this.kr[r*N+c]; mki[r*N+c]=this.ki[r*N+c]; }
      // zero-filled
      let zr=mkr.slice(), zi=mki.slice(); fft2(zr,zi,true,N); this.zf=new Float64Array(N*N); for(let i=0;i<N*N;i++)this.zf[i]=Math.hypot(zr[i],zi[i]);
      this.zfErr=nrmse(this.zf,this.ph);
      // CS (conventional): many wavelet-ISTA iterations
      const runCS=(iters,strength)=>{ let xr=zr.slice(), xi=zi.slice(); const curve=[];
        for(let it=0;it<iters;it++){ const lam=strength*Math.pow(0.96,it);
          for(const ch of [xr,xi]){ haar2(ch,N,false); for(let i=0;i<N*N;i++) ch[i]=soft(ch[i],lam); haar2(ch,N,true); }
          let fr=xr.slice(), fi=xi.slice(); fft2(fr,fi,false,N); for(let r=0;r<N;r++)if(m[r])for(let c=0;c<N;c++){ fr[r*N+c]=this.kr[r*N+c]; fi[r*N+c]=this.ki[r*N+c]; } fft2(fr,fi,true,N); xr=fr; xi=fi;
          const mag=new Float64Array(N*N); for(let i=0;i<N*N;i++)mag[i]=Math.hypot(xr[i],xi[i]); curve.push(nrmse(mag,this.ph)); }
        const mag=new Float64Array(N*N); for(let i=0;i<N*N;i++)mag[i]=Math.hypot(xr[i],xi[i]); return {mag,curve}; };
      const cs=runCS(25,0.03); this.cs=cs.mag; this.csErr=nrmse(this.cs,this.ph); this.csCurve=cs.curve;
      // DL: a learned prior reaches comparable/better quality — shown as its (better) endpoint, framed as one fast feed-forward pass
      const dl=runCS(70,0.028); this.dl=dl.mag; this.dlErr=nrmse(this.dl,this.ph); this.dlCurve=dl.curve; },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H);
      T(x,'Rekonstruksjon fra undersampet k-rom (R≈'+this.eff.toFixed(1)+')',W/2,24,{size:16,col:C.ink,weight:'bold',align:'center'});
      const S=200,y=54; const panels=[[this.zf,'Zero-filled',this.zfErr,C.red,'ingen rekonstruksjon'],[this.cs,'Komprimert sansing',this.csErr,C.blue,'iterativ · sekunder · tuning'],[this.dl,'DL-rekonstruksjon',this.dlErr,C.green,'lært · ett pass · millisekunder']];
      const xs=[40,300,560];
      for(let k=0;k<3;k++){ blitGray(x,panels[k][0],1,xs[k],y,S,this.N); T(x,panels[k][1],xs[k]+S/2,y-6,{size:13,col:panels[k][3],weight:'bold',align:'center'});
        T(x,'feil '+(panels[k][2]*100).toFixed(1)+'%',xs[k]+S/2,y+S+18,{size:12.5,col:panels[k][3],weight:'bold',align:'center'}); T(x,panels[k][4],xs[k]+S/2,y+S+36,{size:11,col:C.mut,align:'center'}); }
      // reference
      blitGray(x,this.ph,1,780,y,S*0.7,this.N); T(x,'sannhet',780+S*0.35,y-6,{size:12,col:C.mut,weight:'bold',align:'center'});
      // convergence curve: CS iterative descent + DL learned endpoint
      const gx=780,gy=180,gw=170,gh=90; L(x,gx,gy+gh,gx+gw,gy+gh,'#c3c8cf',1); L(x,gx,gy,gx,gy+gh,'#c3c8cf',1);
      const mxc=Math.max(this.csCurve[0]||0.2, this.zfErr);
      x.strokeStyle=C.blue; x.lineWidth=2; x.beginPath(); this.csCurve.forEach((v,i)=>{ const px=gx+i/(this.csCurve.length-1)*gw, py=gy+gh-clamp(v/mxc,0,1)*gh; i===0?x.moveTo(px,py):x.lineTo(px,py); }); x.stroke();
      const dly=gy+gh-clamp(this.dlErr/mxc,0,1)*gh; L(x,gx,dly,gx+gw,dly,C.green,2,[5,3]);
      T(x,'feil vs. iterasjon',gx,gy-4,{size:11,col:C.ink,weight:'bold'}); T(x,'CS (iterativ)',gx+gw-4,gy+34,{size:10.5,col:C.blue,weight:'bold',align:'end'}); T(x,'DL (ett pass)',gx+gw-4,dly-5,{size:10.5,col:C.green,weight:'bold',align:'end'});
      wrapText(x,'Zero-filling gir innbretting. Komprimert sansing (konvensjonelt) fjerner den ved sparsitet + datakonsistens — men trenger mange iterasjoner og manuell tuning. Et DL-nett lærer en kraftig denoiser fra tusenvis av bilder → samme eller bedre kvalitet i ETT raskt gjennomløp (millisekunder på skanneren).',40,H-40,W-80,17,{size:12.5,col:C.ink});
      T(x,'Dra R: høyere akselerasjon → vanskeligere rekonstruksjon.',40,H-16,{size:12.5,col:C.blue,weight:'bold'}); }
  };

  // ============================================================
  // 4. UNROLLED NETWORK architecture (denoiser + data consistency)
  // ============================================================
  M.unrolled={ready:false,animated:true,cv:null,x:null,W:960,H:470,t:0,last:null,N:64,snaps:[],
    init(root){ this.cv=root.querySelector('#cv-ur'); this.x=fit(this.cv,this.W,this.H); this.ph=phantomN(this.N);
      const kr=this.ph.slice(), ki=new Float64Array(this.N*this.N); fft2(kr,ki,false,this.N); const m=vdMask(this.N,3,7);
      const mkr=new Float64Array(this.N*this.N), mki=new Float64Array(this.N*this.N); for(let r=0;r<this.N;r++)if(m[r])for(let c=0;c<this.N;c++){ mkr[r*this.N+c]=kr[r*this.N+c]; mki[r*this.N+c]=ki[r*this.N+c]; }
      let zr=mkr.slice(), zi=mki.slice(); fft2(zr,zi,true,this.N); this.snaps=[];
      const push=(xr,xi)=>{ const mag=new Float64Array(this.N*this.N); for(let i=0;i<this.N*this.N;i++)mag[i]=Math.hypot(xr[i],xi[i]); this.snaps.push({mag,err:nrmse(mag,this.ph)}); };
      let xr=zr.slice(), xi=zi.slice(); push(xr,xi);
      for(let casc=0;casc<5;casc++){ const lam=0.05*Math.pow(0.9,casc);
        for(const ch of [xr,xi]){ haar2(ch,this.N,false); for(let i=0;i<this.N*this.N;i++) ch[i]=soft(ch[i],lam); haar2(ch,this.N,true); }
        let fr=xr.slice(), fi=xi.slice(); fft2(fr,fi,false,this.N); for(let r=0;r<this.N;r++)if(m[r])for(let c=0;c<this.N;c++){ fr[r*this.N+c]=kr[r*this.N+c]; fi[r*this.N+c]=ki[r*this.N+c]; } fft2(fr,fi,true,this.N); xr=fr; xi=fi; push(xr,xi); }
      this.t=0; },
    tick(t){ if(this.last==null)this.last=t; const dt=Math.min(0.05,t-this.last); this.last=t; this.t+=dt*0.35; if(this.t>this.snaps.length+1.5)this.t=0; this.draw(); },
    draw(){ const x=this.x,W=this.W,H=this.H; x.clearRect(0,0,W,H);
      T(x,'Utrullet, fysikk-informert nettverk (VarNet / MoDL)',W/2,26,{size:16,col:C.ink,weight:'bold',align:'center'});
      // architecture chain
      const y=70; const bx=40,bw=150,bh=54; const cascades=5; const step=(W-100)/cascades;
      T(x,'undersampet\nk-rom',bx,y+14,{size:11.5,col:C.ink,weight:'bold'});
      for(let c=0;c<cascades;c++){ const X=bx+70+c*step; const active=this.t>=c;
        // denoiser box
        x.globalAlpha=active?1:0.35; rr(x,X,y,bw*0.46,bh,8); x.fillStyle='rgba(93,58,142,0.12)'; x.fill(); x.strokeStyle=C.purple; x.lineWidth=2; x.stroke(); T(x,'CNN\ndenoiser',X+bw*0.23,y+22,{size:10.5,col:C.purple,weight:'bold',align:'center'});
        // DC box
        rr(x,X+bw*0.52,y,bw*0.46,bh,8); x.fillStyle='rgba(47,95,168,0.12)'; x.fill(); x.strokeStyle=C.blue; x.lineWidth=2; x.stroke(); T(x,'data-\nkonsistens',X+bw*0.75,y+22,{size:10,col:C.blue,weight:'bold',align:'center'});
        L(x,X+bw*0.46,y+bh/2,X+bw*0.52,y+bh/2,C.mut,1.5); if(c<cascades-1)L(x,X+bw*0.98,y+bh/2,X+step,y+bh/2,C.mut,1.5); x.globalAlpha=1;
        T(x,'kaskade '+(c+1),X+bw/2,y+bh+14,{size:9.5,col:C.mut,align:'center'}); }
      // current image
      const idx=clamp(Math.floor(this.t),0,this.snaps.length-1); const snap=this.snaps[idx];
      const S=170,ix=W/2-S/2,iy=200; blitGray(x,snap.mag,1,ix,iy,S,this.N);
      T(x,idx===0?'start (zero-filled)':'etter kaskade '+idx,ix+S/2,iy-6,{size:12.5,col:C.ink,weight:'bold',align:'center'});
      T(x,'feil '+(snap.err*100).toFixed(1)+'%',ix+S/2,iy+S+18,{size:13,col:idx===0?C.red:C.green,weight:'bold',align:'center'});
      wrapText(x,'Hver kaskade veksler mellom en LÆRT denoiser (CNN, fjerner innbretting/støy) og et DATAKONSISTENS-steg (tvinger løsningen til å matche det målte k-rom). Etter få kaskader er bildet rent — og det kjører på millisekunder.',40,H-40,W-80,17,{size:12.5,col:C.ink});
      T(x,'«Fysikk-informert»: MR-fysikken (FFT + målte data) er bygget INN i nettet.',40,H-16,{size:12.5,col:C.blue,weight:'bold'}); }
  };

  // ============================================================
  // 5. LEARNED / VARIABLE-DENSITY SAMPLING → aliasing pattern
  // ============================================================
  M.sampling={ready:false,animated:false,cv:null,x:null,W:960,H:470,N:64,mode:'vd',R:3,
    init(root){ this.cv=root.querySelector('#cv-sm'); this.x=fit(this.cv,this.W,this.H); this.ph=phantomN(this.N);
      const kr=this.ph.slice(), ki=new Float64Array(this.N*this.N); fft2(kr,ki,false,this.N); this.kr=kr; this.ki=ki;
      root.querySelectorAll('[data-mode]').forEach(b=>{ b.classList.toggle('on',b.dataset.mode===this.mode); b.onclick=()=>{ this.mode=b.dataset.mode; root.querySelectorAll('[data-mode]').forEach(q=>q.classList.toggle('on',q===b)); this.draw(); }; });
      this.draw(); },
    mask(){ const N=this.N,R=this.R; const m=new Uint8Array(N); let s=13; const rnd=()=>{ s=(s*1103515245+12345)&0x7fffffff; return s/0x7fffffff; };
      if(this.mode==='uniform'){ for(let r=0;r<N;r++) m[r]=(r%R===0)?1:0; }
      else if(this.mode==='vd'){ for(let r=0;r<N;r++){ const dc=Math.min(r,N-r); if(dc<N*0.10)m[r]=1; else m[r]=(rnd()<1.0/R)?1:0; } }
      else { for(let r=0;r<N;r++){ const dc=Math.min(r,N-r)/(N/2); const prob=Math.exp(-dc*3.2); if(dc<0.10)m[r]=1; else m[r]=(rnd()<prob*1.4)?1:0; } } // "learned": strongly center-weighted
      return m; },
    recon(m){ const N=this.N; const mkr=new Float64Array(N*N), mki=new Float64Array(N*N); for(let r=0;r<N;r++)if(m[r])for(let c=0;c<N;c++){ mkr[r*N+c]=this.kr[r*N+c]; mki[r*N+c]=this.ki[r*N+c]; }
      fft2(mkr,mki,true,N); const mag=new Float64Array(N*N); for(let i=0;i<N*N;i++)mag[i]=Math.hypot(mkr[i],mki[i]); return {mag,err:nrmse(mag,this.ph)}; },
    draw(){ const x=this.x,W=this.W,H=this.H; if(!x)return; x.clearRect(0,0,W,H);
      T(x,'Samplingsmønster bestemmer innbrettingen',W/2,26,{size:16,col:C.ink,weight:'bold',align:'center'});
      const m=this.mask(); let nk=0; m.forEach(v=>nk+=v); const rec=this.recon(m);
      // mask pattern (left)
      const px=60,py=70,ps=200; x.strokeStyle='#c3c8cf'; x.strokeRect(px,py,ps,ps);
      for(let r=0;r<this.N;r++){ const yy=py+((r+this.N/2)%this.N)/this.N*ps; if(m[r]) L(x,px,yy,px+ps,yy,C.blue,ps/this.N); }
      T(x,'målte k-rom-linjer',px+ps/2,py-6,{size:12.5,col:C.ink,weight:'bold',align:'center'}); T(x,'(senter = lav frekvens)',px+ps/2,py+ps+18,{size:11,col:C.mut,align:'center'});
      // zero-filled recon (right)
      blitGray(x,rec.mag,1,360,70,ps,this.N); T(x,'zero-filled bilde',360+ps/2,py-6,{size:12.5,col:C.ink,weight:'bold',align:'center'});
      T(x,'feil '+(rec.err*100).toFixed(1)+'%',360+ps/2,py+ps+18,{size:12.5,col:C.red,weight:'bold',align:'center'});
      // description
      const info={uniform:['Uniform','Regelmessige hopp → KOHERENT innbretting: skarpe spøkelseskopier. Vanskelig for CS/DL.',C.red],
        vd:['Variabel tetthet (tilfeldig)','Tett senter + tilfeldig ytre → INKOHERENT, støyliknende innbretting. Ideelt for CS/DL.',C.green],
        learned:['«Lært» mønster','Optimalisert tetthet (f.eks. LOUPE) → enda bedre fordeling av målingene for nettet.',C.purple]};
      const inf=info[this.mode]; T(x,inf[0]+'  ('+nk+' linjer)',620,110,{size:14,col:inf[2],weight:'bold'});
      wrapText(x,inf[1],620,140,300,19,{size:12.5,col:C.ink});
      wrapText(x,'Både komprimert sansing og DL krever INKOHERENT undersampling — da ser innbrettingen ut som støy, som er lett å fjerne. DL kan i tillegg LÆRE selve samplingsmønsteret sammen med rekonstruksjonen.',60,H-40,W-100,17,{size:12.5,col:C.ink});
      T(x,'Bytt mønster: uniform (dårlig) · variabel tetthet · lært.',60,H-16,{size:12.5,col:C.blue,weight:'bold'}); }
  };

  window.runViz=function(name){ const m=M[name]; if(!m){console.error('unknown viz',name);return;}
    try{ m.init(document); m.ready=true; }catch(e){ console.error(e); }
    if(m.animated && m.tick){ (function loop(ts){ m.tick((ts||0)/1000); requestAnimationFrame(loop); })(); }
    window.addEventListener('resize',function(){ if(!m.cv)return; m.x=fit(m.cv,m.W,m.H); if(!m.animated && m.draw) m.draw(); }); };
  window.__dl={M,makeNet,fwd,step,fft2,phantomN,haar2,vdMask,nrmse};
})();
