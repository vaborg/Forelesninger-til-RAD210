using Plots
using Printf

# ==================================================================
#  Gradient-echo MRI: spin dynamics (left) + sequence diagram (right)
# ==================================================================

# ----------------------- physical parameters ----------------------
const NSPIN = 16                                   # spins along x (freq.-enc. dir.)
const XS    = collect(range(-0.8, 0.8, length = NSPIN))
const L     = 0.45                                # magnetisation vector length
const ω0    = 2π * 0.8                            # Larmor angular frequency
const KMAX  = 3π                                  # max gradient moment (edge phase)
const T2S   = 4.0                                 # T2* decay constant

# ----------------------- sequence timing (a.u.) -------------------
const T_RF   = (0.0, 1.0)   # 90° RF pulse
const T_NEG  = (1.5, 2.5)   # dephasing lobe  (−G)
const T_POS  = (2.5, 4.5)   # refocusing lobe (+G)
const T_ECHO = 3.5          # gradient echo: net gradient moment = 0
const T_END  = 5.0
const NETX   = -1.45        # anchor of the net-M arrow (black)

# spin colours: blue (x<0) → grey (x=0) → red (x>0)
const SPIN_C = ["#053061","#2166ac","#4393c3","#92c5de","#666666",
                "#f4a582","#d6604d","#b2182b","#67000d","#053061","#2166ac","#4393c3","#92c5de","#666666",
                "#f4a582","#d6604d","#b2182b","#67000d","#053061","#2166ac","#4393c3","#92c5de","#666666",
                "#f4a582","#d6604d","#b2182b","#67000d"]

# gradient moment  m(t) = ∫ G(t') dt'
function gmoment(t)
    t <  T_NEG[1] && return 0.0
    t <  T_NEG[2] && return -KMAX*(t - T_NEG[1])/(T_NEG[2] - T_NEG[1])
    t <  T_POS[2] && return -KMAX + KMAX*(t - T_POS[1])   # =0 exactly at t=3.5
    return KMAX
end

stage(t) =
    t ≤ 1.00 ? "Excitation: 90° RF tips M into the transverse plane" :
    t < 1.50 ? "Free precession" :
    t < 2.50 ? "Dephasing lobe (−G): spins fan out" :
    t < 3.45 ? "Refocusing lobe (+G): spins rephase…" :
    t < 3.56 ? "*** GRADIENT ECHO — maximum signal ***" :
    t < 4.50 ? "Refocusing lobe (+G): spins fan out again" :
               "End of sequence"

# ========================== LEFT PANEL ============================
function spin_panel(t)
    θtip = (π/2) * clamp(t, 0.0, 1.0)      # RF flip angle 0 → 90°
    dec  = exp(-max(t - 1.0, 0.0)/T2S)     # T2* envelope
    m    = gmoment(t)                      # current gradient moment

    p = plot3d(legend = false,
               xlim = (-1.95, 1.35), ylim = (-0.62, 0.62), zlim = (-0.25, 0.62),
               xlabel = "x", ylabel = "y", zlabel = "z",
               camera = (30 + 6*sin(π*t/T_END), 16))   # gentle camera drift

    # faint reference rings = precession trajectories
    θc = range(0, 2π, length = 60)
    for (i, xi) in enumerate(XS)
        plot3d!(p, xi .+ L*cos.(θc), L*sin.(θc), zeros(length(θc)),
                lw = 0.8, color = SPIN_C[i], alpha = 0.25)
    end
    plot3d!(p, [-1.95, 1.35], [0,0], [0,0], lw = 1, color = :grey70)      # x axis
    plot3d!(p, [NETX, NETX], [0,0], [0,0.55], lw = 1, ls = :dash, color = :grey70) # z ref

    # individual spins
    Mnet = zeros(3)
    for (i, xi) in enumerate(XS)
        if t ≤ 1.0                                  # RF: tip from +z to xy
            d = L .* (0.0, sin(θtip), cos(θtip))
        else                                        # precession + gradient phase
            α = ω0*(t - 1.0) + (xi/0.8)*m
            d = L*dec .* (sin(α), cos(α), 0.0)
        end
        Mnet .+= d
        plot3d!(p, [xi, xi+d[1]], [0, d[2]], [0, d[3]], lw = 3, color = SPIN_C[i])
        scatter3d!(p, [xi+d[1]], [d[2]], [d[3]], ms = 4, color = SPIN_C[i])
    end
    Mnet ./= NSPIN

    # net magnetisation (black arrow ∝ measured signal)
    plot3d!(p, [NETX, NETX+Mnet[1]], [0, Mnet[2]], [0, Mnet[3]], lw = 5, color = :black)
    scatter3d!(p, [NETX+Mnet[1]], [Mnet[2]], [Mnet[3]], ms = 6, color = :black)

    sig = hypot(Mnet[1], Mnet[2]) / L
    plot!(p, title = @sprintf("%s\n t = %4.2f     signal |Mxy| = %4.2f", stage(t), t, sig),
          titlefontsize = 10)
    return p
end

# ========================== RIGHT PANEL ===========================
function sequence_panel(t)
    RFY = 1.6   # baseline of the RF channel
    p = plot(legend = false,
             xlim = (-0.95, 5.05), ylim = (-1.95, 2.62),
             xticks = 0:5, yticks = [], xlabel = "time (a.u.)",
             title = "Pulse-sequence diagram", titlefontsize = 11)

    hline!(p, [0.0], color = :grey60, lw = 1)      # Gx channel baseline
    hline!(p, [RFY], color = :grey60, lw = 1)      # RF channel baseline

    # brightness of the currently active element
    αrf  = (t ≤ 1.05)      ? 0.95 : 0.30
    αneg = (1.5 ≤ t ≤ 2.5) ? 0.90 : 0.30
    αpos = (2.5 ≤ t ≤ 4.5) ? 0.90 : 0.30

    # RF channel: sinc-shaped 90° pulse
    τ = range(0, 1, length = 200);  u = (τ .- 0.5).*6
    plot!(p, τ, RFY .+ 0.8.*sinc.(u), fillrange = RFY,
          fillcolor = :red, fillalpha = αrf, lw = 1.5, color = :red)

    # frequency-encoding gradient: dephase (−) then rephase (+) lobe
    plot!(p, [T_NEG...], [-1.0,-1.0], fillrange = 0,
          fillcolor = :royalblue, fillalpha = αneg, lw = 1.5, color = :royalblue)
    plot!(p, [T_POS...], [ 1.0, 1.0], fillrange = 0,
          fillcolor = :seagreen,  fillalpha = αpos, lw = 1.5, color = :seagreen)
    plot!(p, [0,1.5,1.5,2.5,2.5,4.5,4.5,5], [0,0,-1,-1,1,1,0,0],
          lw = 2, color = :gray35)

    vline!(p, [T_ECHO], ls = :dash, lw = 1.2, color = :grey50)   # echo time
    vline!(p, [t], lw = 1.6, color = :black, alpha = 0.6)        # running cursor

    annotate!(p, -0.50,  RFY,       text("RF", 11, :center))
    annotate!(p, -0.50,  0.0,       text("Gx", 11, :center))
    annotate!(p,  0.50,  RFY+0.95,  text("90°", 10, :red, :center))
    annotate!(p,  2.00, -1.30,      text("dephase", 9, :royalblue, :center))
    annotate!(p,  3.50,  1.28,      text("rephase", 9, :seagreen, :center))
    annotate!(p,  3.50, -1.60,      text("TE (echo)", 9, :grey40, :center))
    return p
end

# =========================== ANIMATION ============================
times = vcat(range(0.00, 1.00, length = 11),   # RF pulse
             range(1.15, 1.45, length = 4),    # gap
             range(1.50, 2.50, length = 13),   # dephasing lobe
             range(2.55, 4.45, length = 25),   # refocusing lobe (contains t=3.5!)
             range(4.60, 5.00, length = 5))    # tail
times = sort!(vcat(times, fill(T_ECHO, 4)))    # freeze a few frames at the echo

anim = Animation()
for t in times
    plot(spin_panel(t), sequence_panel(t), layout = (1, 2), size = (1300, 800), thickness_scaling = 1.3)
    frame(anim)
end

gif(anim, "gradient_echo.gif", fps = 15)
