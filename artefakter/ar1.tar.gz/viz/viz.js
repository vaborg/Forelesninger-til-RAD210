/* MR-artefakter — interaktiv simulator for Quarto reveal.js (iframe).
   Ett modul (artefakt) med velger; hvert artefakt vises som Ren → Med artefakt → Korrigert.
   FFT og alle artefakt-signaturer verifisert numerisk før innbygging. */
(function(){
  "use strict";
  const FT="'DejaVu Sans', Verdana, sans-serif";
  const C={blue:'#2F5FA8',red:'#C0392B',purple:'#5d3a8e',orange:'#b54a16',green:'#10b981',
           amber:'#d99a10',ink:'#1f2430',mut:'#9aa2ad',line:'#e3e6ea'};
  const clamp=(v,a,b)=>v<a?a:(v>b?b:v), TAU=Math.PI*2, N=128;

  // ---- verified FFT ----
  function fft(re,im,inv){ const n=re.length;
    for(let i=1,j=0;i<n;i++){ let bit=n>>1; for(;j&bit;bit>>=1) j^=bit; j^=bit; if(i<j){let t=re[i];re[i]=re[j];re[j]=t;t=im[i];im[i]=im[j];im[j]=t;} }
    for(let len=2;len<=n;len<<=1){ const a=(inv?2:-2)*Math.PI/len,wr=Math.cos(a),wi=Math.sin(a);
      for(let i=0;i<n;i+=len){ let cr=1,ci=0; for(let k=0;k<len/2;k++){ const p=i+k,qq=i+k+len/2;
        const vr=re[qq]*cr-im[qq]*ci,vi=re[qq]*ci+im[qq]*cr; re[qq]=re[p]-vr;im[qq]=im[p]-vi;re[p]+=vr;im[p]+=vi;
        const ncr=cr*wr-ci*wi;ci=cr*wi+ci*wr;cr=ncr; } } } if(inv){for(let i=0;i<n;i++){re[i]/=n;im[i]/=n;}} }
  function fft2(re,im,inv){ const rr=new Float64Array(N),ri=new Float64Array(N);
    for(let y=0;y<N;y++){const o=y*N;for(let x=0;x<N;x++){rr[x]=re[o+x];ri[x]=im[o+x];}fft(rr,ri,inv);for(let x=0;x<N;x++){re[o+x]=rr[x];im[o+x]=ri[x];}}
    const cr=new Float64Array(N),ci=new Float64Array(N);
    for(let x=0;x<N;x++){for(let y=0;y<N;y++){cr[y]=re[y*N+x];ci[y]=im[y*N+x];}fft(cr,ci,inv);for(let y=0;y<N;y++){re[y*N+x]=cr[y];im[y*N+x]=ci[y];}} }
  function toK(img){ const kr=img.slice(),ki=new Float64Array(N*N); fft2(kr,ki,false); return {kr,ki}; }
  function fromK(kr,ki){ const a=kr.slice(),b=ki.slice(); fft2(a,b,true); const o=new Float64Array(N*N); for(let i=0;i<N*N;i++)o[i]=Math.hypot(a[i],b[i]); return o; }

  // ---- phantom (water + fat) ----
  const ell=(x,y,cx,cy,a,b)=>((x-cx)**2)/(a*a)+((y-cy)**2)/(b*b)<=1;
  function phantom(){ const water=new Float64Array(N*N), fat=new Float64Array(N*N);
    for(let py=0;py<N;py++){ const y=(py/(N-1))*2-1; for(let px=0;px<N;px++){ const x=(px/(N-1))*2-1;
      const rOut=Math.hypot(x/0.82,y/0.96);
      if(rOut<=1 && rOut>0.90) fat[py*N+px]=0.95;
      else if(ell(x,y,0,0,0.74,0.88)){ let v=0.5;
        if(ell(x,y,0,-0.02,0.58,0.70)) v=0.62;
        if(ell(x,y,-0.16,-0.06,0.07,0.20)||ell(x,y,0.16,-0.06,0.07,0.20)) v=0.15;
        if(ell(x,y,0.26,0.22,0.075,0.075)) v=0.95;
        if(ell(x,y,-0.05,0.42,0.30,0.10)) v=0.55;
        water[py*N+px]=v; }
      else if(rOut<=0.90 && rOut>0.84) water[py*N+px]=0.12;
    } } return {water,fat}; }
  const {water,fat}=phantom();
  const clean=new Float64Array(N*N); for(let i=0;i<N*N;i++) clean[i]=water[i]+fat[i];
  const CMAX=Math.max(...clean)||1;

  // ---- geometric helpers ----
  function shiftX(img,d){ const o=new Float64Array(N*N),s=Math.round(d); for(let y=0;y<N;y++)for(let x=0;x<N;x++){const sx=x-s;o[y*N+x]=(sx>=0&&sx<N)?img[y*N+sx]:0;} return o; }
  function warpRadial(img,c){ const o=new Float64Array(N*N); for(let py=0;py<N;py++)for(let px=0;px<N;px++){
    const x=(px-N/2)/(N/2),y=(py-N/2)/(N/2),r2=x*x+y*y,f=1+c*r2; const sx=x/f*(N/2)+N/2,sy=y/f*(N/2)+N/2;
    const ix=Math.round(sx),iy=Math.round(sy); o[py*N+px]=(ix>=0&&ix<N&&iy>=0&&iy<N)?img[iy*N+ix]:0; } return o; }
  function shear(img,s){ const o=new Float64Array(N*N); for(let py=0;py<N;py++)for(let px=0;px<N;px++){
    const sx=Math.round(px - s*(py-N/2)); o[py*N+px]=(sx>=0&&sx<N)?img[py*N+sx]:0; } return o; }
  function withGrid(img){ const o=img.slice(); for(let i=0;i<N;i+=16){ for(let k=0;k<N;k++){ o[i*N+k]=Math.max(o[i*N+k],0.85); o[k*N+i]=Math.max(o[k*N+i],0.85);} } return o; }

  // ---- susceptibility field ----
  function suscField(){ const f=new Float64Array(N*N); const cx=0.28,cy=-0.18,sig=0.14;
    for(let py=0;py<N;py++){const y=(py/(N-1))*2-1;for(let px=0;px<N;px++){const x=(px/(N-1))*2-1;
      f[py*N+px]=Math.exp(-(((x-cx)**2+(y-cy)**2)/(2*sig*sig)));}} return f; }
  const SF=suscField();
  function suscImg(sev,SE){ const shiftScale=SE?2.0:12.0*sev; const o=new Float64Array(N*N);
    for(let py=0;py<N;py++)for(let px=0;px<N;px++){ const d=Math.round(shiftScale*SF[py*N+px]); const sx=px-d;
      let v=(sx>=0&&sx<N)?clean[py*N+sx]:0;
      if(!SE){ // GRE dropout ~ local field gradient
        const gx=(SF[py*N+Math.min(N-1,px+1)]-SF[py*N+Math.max(0,px-1)]); const gy=(SF[Math.min(N-1,py+1)*N+px]-SF[Math.max(0,py-1)*N+px]);
        const g=Math.hypot(gx,gy)*60*sev; v*=Math.exp(-g*g); }
      o[py*N+px]=v; } return o; }

  // ---- artefact definitions ----
  const ART={
    motion:{ name:'Bevegelse / ghosting', sev:'Bevegelsesamplitude',
      mech:'Periodisk bevegelse (pust, puls) gir faseendringer mellom fasekodingslinjene → diskrete spøkelser (ghosts) langs fasekodingsretningen.',
      fix:'Korreksjon: gating/pustestopp, signalmidling, bevegelseskorreksjon, radiær/PROPELLER-opptak.',
      corrupt(s){ const {kr,ki}=toK(clean); const a=new Float64Array(N*N),b=new Float64Array(N*N);
        for(let y=0;y<N;y++){ const th=s*2.2*Math.cos(TAU*16*y/N); const c=Math.cos(th),sn=Math.sin(th);
          for(let x=0;x<N;x++){ const re=kr[y*N+x],im=ki[y*N+x]; a[y*N+x]=re*c-im*sn; b[y*N+x]=re*sn+im*c; } } return fromK(a,b); },
      corrected(){ return clean; } },
    aliasing:{ name:'Innbretting (aliasing)', sev:'FoV-reduksjon',
      mech:'Synsfeltet (FoV) er mindre enn objektet — for stor Δk i fasekoding → objektet «bretter inn» over seg selv.',
      fix:'Korreksjon: øk FoV, faseoversampling, eller bytt fasekodingsretning.',
      corrupt(s){ const R=1+Math.round(s*2.4); const {kr,ki}=toK(clean); const a=kr.slice(),b=ki.slice();
        for(let y=0;y<N;y++) if(y%R!==0){ for(let x=0;x<N;x++){a[y*N+x]=0;b[y*N+x]=0;} } return fromK(a,b); },
      corrected(){ return clean; } },
    gibbs:{ name:'Trunkering / Gibbs-ringing', sev:'k-rom-avkortning',
      mech:'Endelig matrise = k-rom kuttes → ringmønster (parallelle striper) ved skarpe kanter. Kan etterligne patologi (f.eks. syringomyeli i ryggmargen).',
      fix:'Korreksjon: større matrise (mer k-rom), eller apodisering/filter (svak uskarphet).',
      corrupt(s){ return gibbsRecon(0.42-0.30*s,false); },
      corrected(s){ return gibbsRecon(0.42-0.30*s,true); } },
    chemshift:{ name:'Kjemisk skift', sev:'1 / båndbredde',
      mech:'Fett og vann resonerer ~3,5 ppm fra hverandre → fettsignalet forskyves i frekvenskodingsretningen (mørk/lys kant der fett møter vann).',
      fix:'Korreksjon: høyere mottaksbåndbredde, fettmetning, eller bytt readout-retning.',
      corrupt(s){ const d=Math.round(1+s*8); const f=shiftX(fat,d); const o=new Float64Array(N*N); for(let i=0;i<N*N;i++)o[i]=water[i]+f[i]; return o; },
      corrected(){ return clean; } },
    susc:{ name:'Susceptibilitet (metall/luft)', sev:'Feltforstyrrelse',
      mech:'Metall eller luft-vev-grenser forstyrrer B0 → geometrisk forvrengning i frekvenskoding + signaltap/opphopning (verst i gradient-ekko).',
      fix:'Korreksjon: spinnekko framfor gradient-ekko, høyere båndbredde, kort TE, tynnere snitt, VAT/SEMAC/MAVRIC.',
      corrupt(s){ return suscImg(s,false); },
      corrected(s){ return suscImg(s,true); } },
    rf:{ name:'RF-forstyrrelse (zipper/spike)', sev:'Forstyrrelsesnivå',
      mech:'Ett defekt k-rom-punkt eller smal-bånds RF-lekkasje = én romlig frekvens lagt over hele bildet → «sildebein» (herringbone) eller glidelås-stripe.',
      fix:'Korreksjon: lukk Faraday-døren, fjern RF-kilde/elektronikk, eller detekter og fjern spiken i k-rom.',
      corrupt(s){ const {kr,ki}=toK(clean); const a=kr.slice(),b=ki.slice(); const mx=Math.max(...a.map(Math.abs));
        a[22*N+34]+=s*0.5*mx; b[22*N+34]+=s*0.3*mx; return fromK(a,b); },
      corrected(){ return clean; } },
    shading:{ name:'B1-skygge / spolefølsomhet', sev:'Skyggestyrke',
      mech:'Ujevnt RF-felt (B1) eller overflatespolens følsomhet gir en glatt intensitetsgradient — lyst nær spolen, mørkt lenger unna.',
      fix:'Korreksjon: bias-feltkorreksjon (N4), body-coil-normalisering, PURE/SCIC-intensitetsutjevning.',
      corrupt(s){ const o=new Float64Array(N*N); for(let y=0;y<N;y++)for(let x=0;x<N;x++){ const b=1+s*0.9*((x/N)-0.5)*2; o[y*N+x]=clean[y*N+x]*b; } return o; },
      corrected(){ return clean; } },
    gradient:{ name:'Gradient-ulinearitet', sev:'Forvrengning',
      mech:'Gradientene er ulineære nær FoV-kanten → geometrisk forvrengning (tønne/pute). Rette linjer bøyer seg, mest ytterst.',
      fix:'Korreksjon: gradientforvrengnings-korreksjon (kalibrert), og hold objektet nær isosenter.',
      grid:true,
      corrupt(s){ return warpRadial(withGrid(clean),0.45*s); },
      corrected(){ return withGrid(clean); },
      base(){ return withGrid(clean); } },
    eddy:{ name:'Virvelstrømmer (eddy currents)', sev:'Skjærforvrengning',
      mech:'Raske gradientveksler induserer virvelstrømmer (den andre siden av EM-induksjon) → forskyvning og skjær mellom bilder, særlig i diffusjon.',
      fix:'Korreksjon: skjermede gradienter, pre-emphasis, dobbelt-refokusert spinnekko, affin bilderegistrering.',
      grid:true,
      corrupt(s){ return shear(withGrid(clean),s*0.35); },
      corrected(){ return withGrid(clean); },
      base(){ return withGrid(clean); } }
  };
  function gibbsRecon(frac,apod){ const {kr,ki}=toK(clean); const a=kr.slice(),b=ki.slice(); const half=Math.max(6,Math.floor(N*frac/2));
    for(let y=0;y<N;y++)for(let x=0;x<N;x++){ const fx=(x<N/2?x:x-N),fy=(y<N/2?y:y-N); const keep=Math.abs(fx)<=half&&Math.abs(fy)<=half;
      if(!keep){a[y*N+x]=0;b[y*N+x]=0;} else if(apod){ const w=0.54+0.46*Math.cos(Math.PI*Math.max(Math.abs(fx),Math.abs(fy))/half); a[y*N+x]*=w;b[y*N+x]*=w; } }
    return fromK(a,b); }
  const ORDER=['motion','aliasing','gibbs','chemshift','susc','rf','shading','gradient','eddy'];

  // ---- render helpers ----
  function fit(cv,w,h){ const dpr=Math.max(1,Math.min(2.5,window.devicePixelRatio||1));
    cv.width=w*dpr; cv.height=h*dpr; cv.style.aspectRatio=w+'/'+h; const x=cv.getContext('2d'); x.setTransform(dpr,0,0,dpr,0,0); return x; }
  function T(x,s,px,py,o){ o=o||{}; x.globalAlpha=o.alpha==null?1:o.alpha; x.fillStyle=o.col||C.ink;
    x.font=(o.weight||'normal')+' '+(o.size||14)+'px '+FT; x.textAlign=o.align||'left'; x.textBaseline=o.base||'alphabetic'; x.fillText(s,px,py); x.globalAlpha=1; }
  function wrapText(x,s,px,py,maxw,lh,o){ const words=s.split(' '); let line='',yy=py;
    for(const w of words){ const test=line?line+' '+w:w; if(x.measureText? false:false){} 
      x.font=(o.weight||'normal')+' '+(o.size||13)+'px '+FT;
      if(x.measureText(test).width>maxw && line){ T(x,line,px,yy,o); line=w; yy+=lh; } else line=test; }
    if(line) T(x,line,px,yy,o); return yy; }

  const M={};
  M.artefact={ready:false,animated:false,cv:null,x:null,W:980,H:470,art:'motion',sev:0.6,
    off:null,octx:null,
    init(root){ this.cv=root.querySelector('#cv-art'); this.x=fit(this.cv,this.W,this.H);
      this.off=document.createElement('canvas'); this.off.width=N; this.off.height=N; this.octx=this.off.getContext('2d');
      if(window.__artDefault && ART[window.__artDefault]) this.art=window.__artDefault;
      root.querySelectorAll('[data-art]').forEach(b=>{ b.classList.toggle('on',b.dataset.art===this.art);
        b.onclick=()=>{ this.art=b.dataset.art; root.querySelectorAll('[data-art]').forEach(q=>q.classList.toggle('on',q===b)); this.update(); }; });
      this.sl=root.querySelector('#art-sev'); this.slo=root.querySelector('#art-sevo');
      if(this.sl){ this.sl.oninput=()=>{ this.sev=+this.sl.value/100; this.slo.textContent=this.sl.value+' %'; this.update(); }; this.slo.textContent=this.sl.value+' %'; this.sev=+this.sl.value/100; }
      this.update(); },
    update(){ const A=ART[this.art]; this.cleanImg=A.base?A.base():clean;
      this.corrupt=A.corrupt(this.sev); this.corrected=A.corrected(this.sev); this.draw(); },
    blit(img,dx,dy,size){ const id=this.octx.createImageData(N,N);
      for(let i=0;i<N*N;i++){ const v=clamp(img[i]/CMAX,0,1); const g=Math.pow(v,0.9)*255|0; id.data[i*4]=g;id.data[i*4+1]=g;id.data[i*4+2]=g;id.data[i*4+3]=255; }
      this.octx.putImageData(id,0,0); this.x.imageSmoothingEnabled=true; this.x.drawImage(this.off,dx,dy,size,size); },
    draw(){ const x=this.x,W=this.W,H=this.H,A=ART[this.art]; if(!x)return; x.clearRect(0,0,W,H);
      const size=282, y0=54, gap=28, x0=36; const xs=[x0, x0+size+gap, x0+2*(size+gap)];
      const labs=[['Ren',C.mut],['Med artefakt',C.red],['Korrigert',C.green]];
      const imgs=[this.cleanImg,this.corrupt,this.corrected];
      T(x,A.name,W/2,30,{size:17,col:C.ink,weight:'bold',align:'center'});
      for(let p=0;p<3;p++){ this.blit(imgs[p],xs[p],y0,size);
        x.strokeStyle=p===1?C.red:p===2?C.green:'#c3c8cf'; x.lineWidth=p?2:1.4; x.strokeRect(xs[p],y0,size,size);
        T(x,labs[p][0],xs[p]+size/2,y0-10,{size:14,col:labs[p][1],weight:'bold',align:'center'}); }
      // arrows
      const ay=y0+size/2; [[xs[0]+size,xs[1]],[xs[1]+size,xs[2]]].forEach((seg,i)=>{ x.strokeStyle=C.mut;x.lineWidth=2;
        x.beginPath();x.moveTo(seg[0]+4,ay);x.lineTo(seg[1]-4,ay);x.stroke();
        x.fillStyle=C.mut;x.beginPath();x.moveTo(seg[1]-4,ay);x.lineTo(seg[1]-13,ay-6);x.lineTo(seg[1]-13,ay+6);x.closePath();x.fill();
        T(x,i?'korriger':'artefakt',(seg[0]+seg[1])/2,ay-9,{size:11,col:C.mut,align:'center',weight:'bold'}); });
      // caption: mechanism + fix
      const cy=y0+size+26; wrapText(x,A.mech,x0,cy,W-72,18,{size:13,col:C.ink});
      wrapText(x,A.fix,x0,cy+42,W-72,18,{size:13,col:C.blue,weight:'bold'}); }
  };

  window.runViz=function(name){ const m=M[name]; if(!m){console.error('unknown viz',name);return;}
    try{ m.init(document); m.ready=true; }catch(e){ console.error(e); }
    window.addEventListener('resize',function(){ if(!m.cv)return; m.x=fit(m.cv,m.W,m.H); if(m.draw)m.draw(); }); };
  window.__art={M,ART,ORDER,clean,corrupt:()=>M.artefact.corrupt};
})();
